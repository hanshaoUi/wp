# Local Illustrator SDK

Download the Illustrator SDK from Adobe:

```text
https://console.adobe.io/downloads/ai
```

If the download page is blank or the button does nothing:

- Sign in with the Adobe ID that owns or administers the Creative Cloud account.
- Try Microsoft Edge or another browser.
- Clear `adobe.com` and `console.adobe.io` cookies, then sign in again.
- Disable popup blockers, ad blockers, privacy extensions, and script blockers for Adobe sites.
- If this is an enterprise/team account, ask the Adobe system administrator to download it or grant Developer Console download access.

This directory is the local SDK vault for Illustrator AIP development. SDK files
are proprietary Adobe files, so Git ignores everything here except this README.
Keep original downloaded ZIP/DMG packages under `_archives/mac/` and
`_archives/win/` after extraction.

If you only keep one SDK, put the extracted Adobe Illustrator SDK here:

```text
tools/illustrator-aip/sdk/AdobeIllustratorSDK/
```

If you keep multiple SDK versions, use this layout:

```text
tools/illustrator-aip/sdk/mac_Adobe Illustrator 2026 SDK/
tools/illustrator-aip/sdk/mac_Adobe Illustrator 2025 SDK/
tools/illustrator-aip/sdk/mac_Adobe Illustrator 2024 SDK/
tools/illustrator-aip/sdk/mac_Adobe Illustrator 2023 SDK/
tools/illustrator-aip/sdk/mac_Adobe Illustrator 2022 SDK/
tools/illustrator-aip/sdk/mac_Adobe Illustrator 2021 SDK/
tools/illustrator-aip/sdk/mac_Adobe Illustrator 2020 SDK/
tools/illustrator-aip/sdk/win_Adobe Illustrator 2026 SDK/
tools/illustrator-aip/sdk/win_Adobe Illustrator 2025 SDK/
tools/illustrator-aip/sdk/win_Adobe Illustrator 2024 SDK/
tools/illustrator-aip/sdk/win_Adobe Illustrator 2023 SDK/
tools/illustrator-aip/sdk/win_Adobe Illustrator 2022 SDK/
tools/illustrator-aip/sdk/win_Adobe Illustrator 2021 SDK/
tools/illustrator-aip/sdk/win_Adobe Illustrator 2020 SDK/
```

The AIP build scripts auto-detect the SDK folders from 2026 down to 2020, or you
can point to any SDK explicitly with `ILLUSTRATOR_SDK_ROOT`.

Build every Windows AIP variant from the local Windows SDK folders:

```powershell
npm run build:aip:windows:all
```

Build every macOS AIP variant from the local macOS SDK folders on macOS:

```sh
npm run build:aip:macos:all
```

To build and run the shared smart-group algorithm unit test (no SDK required):

```sh
cmake -S tools/illustrator-aip \
  -B tools/illustrator-aip/build-check
cmake --build tools/illustrator-aip/build-check
ctest --test-dir tools/illustrator-aip/build-check --output-on-failure
```
