# HopeFlow 工具箱 Windows 安装说明

## 安装（推荐）

1. 解压发布包。
2. 完全退出 Adobe Illustrator。
3. 双击 `HopeFlow-Installer.bat`。
4. 等待安装完成提示。
5. 重启 Illustrator，打开 `窗口 > 扩展 > HopeFlow 工具箱`。
   画板 / 对象 / 收藏 / 脚本子面板也在同一菜单中。

安装器会自动完成：

- 检查插件包是否完整。
- 写入当前用户的 CEP 调试加载开关（PlayerDebugMode）。
- 安装或覆盖旧版本插件，并将旧版本备份到系统临时目录。
- 按检测到的 Illustrator 年份安装对应的智能编组 AIP（2020–2026）。

## 命令行用法

`HopeFlow-Installer.bat` 支持参数直通：

```bat
HopeFlow-Installer.bat            安装/更新
HopeFlow-Installer.bat -Check     仅检查安装包
HopeFlow-Installer.bat -Uninstall 卸载
```

从源码根目录运行时，如缺少 `dist/index.html`，安装器会先执行 `npm ci` 和 `npm run build` 再安装。

## 卸载

运行 `HopeFlow-Installer.bat -Uninstall`，或手动删除：

```text
%APPDATA%\Adobe\CEP\extensions\com.hopeflow.toolbox
```

## 打包注意

发布包必须包含以下文件或目录：

- `CSXS/manifest.xml`
- `dist/index.html`
- `src/scripts/_runtime/bootstrap.jsx`
- `HopeFlow-Installer.bat`
- `tools/installers/windows-installer.ps1`
- `tools/illustrator-aip/windows/<年份>/HopeFlow.aip`

如果缺少 `dist/index.html`，先在开发机运行：

```bash
npm run build
```

## 生成 Windows 发布包

开发机运行：

```bash
npm run package:windows
```

会在 `release/` 下生成 `HopeFlow-Toolbox-<版本>-Windows.zip` 与安装器 exe。
