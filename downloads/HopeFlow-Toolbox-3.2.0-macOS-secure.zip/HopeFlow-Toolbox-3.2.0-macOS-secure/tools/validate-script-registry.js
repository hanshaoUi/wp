const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const registryDir = path.join(root, 'src', 'registry', 'scripts');
const panelRegistryPath = path.join(root, 'src', 'panel', 'panels', 'registry.tsx');

const panelSource = fs.readFileSync(panelRegistryPath, 'utf8');
const panelIds = new Set();
for (const match of panelSource.matchAll(/['"]([^'"]+)['"]\s*:/g)) {
  panelIds.add(match[1]);
}

const knownPanelIds = new Set([
  'export-large-scale',
  'split-overlap-artboards',
  'ai-enhance',
  'image2-draw',
  'open-pdf',
  'data-merge',
  'text-style-rules',
  'export-artboard-size-table',
  'ai-color-generator',
  'create-guides',
  'batch-draw-rectangles',
  'prepress-crop-marks',
  'ai-draw',
]);

const entries = [];
for (const file of fs.readdirSync(registryDir).filter((name) => name.endsWith('.ts'))) {
  const source = fs.readFileSync(path.join(registryDir, file), 'utf8');
  const objectMatches = source.match(/\{[\s\S]*?\n\s*\}/g) || [];
  for (const objectSource of objectMatches) {
    const id = objectSource.match(/id:\s*['"]([^'"]+)['"]/);
    const category = objectSource.match(/category:\s*['"]([^'"]+)['"]/);
    if (id && category) entries.push({ id: id[1], category: category[1] });
  }
}

const problems = [];
for (const entry of entries) {
  const isPanel = knownPanelIds.has(entry.id);
  const jsxPath = path.join(root, 'src', 'scripts', entry.category, `${entry.id}.jsx`);
  if (isPanel && !panelIds.has(entry.id)) {
    problems.push(`${entry.id}: marked as panel but missing from panel registry`);
  }
  if (!isPanel && !fs.existsSync(jsxPath)) {
    problems.push(`${entry.id}: JSX file not found at ${path.relative(root, jsxPath)}`);
  }
}

if (problems.length) {
  console.error(`Script registry validation failed (${problems.length} issue${problems.length === 1 ? '' : 's'}):`);
  for (const problem of problems) console.error(`- ${problem}`);
  process.exit(1);
}

console.log(`Script registry validation passed: ${entries.length} tools checked.`);
