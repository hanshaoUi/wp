# Nesting Native Prototype

Standalone C++ helper for the nesting core used by `src/scripts/nesting/nesting-optimize.jsx`.

It handles:

- multiple sort strategies
- configurable rotation candidates
- true-shape polygon placement with segment collision checks
- polygon spacing checks based on edge distance
- MaxRects free-rectangle split and prune
- placement output by original selection index

Build:

```powershell
cmake -S tools/nesting-native -B tools/nesting-native/build -DCMAKE_BUILD_TYPE=Release
cmake --build tools/nesting-native/build --config Release
```

Run:

```powershell
tools/nesting-native/build/Release/nesting_native.exe input.json output.json
```

Input shape:

```json
{
  "sheetWidth": 3401.57,
  "sheetHeight": 6859.84,
  "spacing": 14.17,
  "allowRotation": true,
  "useTrueShape": true,
  "rotationStep": 15,
  "placementStep": 22.68,
  "parts": [
    {
      "index": 0,
      "width": 200,
      "height": 100,
      "area": 15000,
      "perimeter": 600,
      "maxSide": 200,
      "minSide": 100,
      "polygon": [[0, 0], [200, 0], [150, 100], [0, 100]]
    }
  ]
}
```

When `useTrueShape` is false, the helper falls back to rectangle MaxRects using `width` and `height`.
