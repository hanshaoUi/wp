#include <algorithm>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <sstream>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>

struct Point {
    double x = 0.0;
    double y = 0.0;
};

struct Part {
    int index = 0;
    double width = 0.0;
    double height = 0.0;
    double area = 0.0;
    double perimeter = 0.0;
    double maxSide = 0.0;
    double minSide = 0.0;
    std::vector<Point> polygon;
};

struct Rect {
    double x = 0.0;
    double y = 0.0;
    double width = 0.0;
    double height = 0.0;
};

struct PolyBounds {
    double minX = 0.0;
    double minY = 0.0;
    double maxX = 0.0;
    double maxY = 0.0;
};

static PolyBounds boundsFromPolygon(const std::vector<Point>& points) {
    PolyBounds bounds;
    if (points.empty()) return bounds;
    bounds.minX = bounds.maxX = points[0].x;
    bounds.minY = bounds.maxY = points[0].y;
    for (const auto& p : points) {
        bounds.minX = std::min(bounds.minX, p.x);
        bounds.minY = std::min(bounds.minY, p.y);
        bounds.maxX = std::max(bounds.maxX, p.x);
        bounds.maxY = std::max(bounds.maxY, p.y);
    }
    return bounds;
}

static double rawPolygonArea(const std::vector<Point>& points) {
    if (points.size() < 3) return 0.0;
    double area = 0.0;
    for (size_t i = 0, j = points.size() - 1; i < points.size(); j = i++) {
        area += points[j].x * points[i].y - points[i].x * points[j].y;
    }
    return std::abs(area * 0.5);
}

struct Sheet {
    std::vector<Rect> freeRects;
};

struct Placement {
    Part part;
    double x = 0.0;
    double y = 0.0;
    double rotation = 0.0;
    int sheetIndex = 0;
};

struct Input {
    double sheetWidth = 0.0;
    double sheetHeight = 0.0;
    double spacing = 0.0;
    bool allowRotation = true;
    bool useTrueShape = false;
    double rotationStep = 15.0;
    double placementStep = 20.0;
    std::vector<Part> parts;
};

struct Result {
    std::vector<Placement> placements;
    int sheetCount = 0;
    double utilization = 0.0;
};

class Json {
public:
    explicit Json(std::string text) : s_(std::move(text)) {}

    Input parseRoot() {
        Input input;
        expect('{');
        while (!consume('}')) {
            std::string key = parseString();
            expect(':');
            if (key == "sheetWidth") input.sheetWidth = parseNumber();
            else if (key == "sheetHeight") input.sheetHeight = parseNumber();
            else if (key == "spacing") input.spacing = parseNumber();
            else if (key == "allowRotation") input.allowRotation = parseBool();
            else if (key == "useTrueShape") input.useTrueShape = parseBool();
            else if (key == "rotationStep") input.rotationStep = parseNumber();
            else if (key == "placementStep") input.placementStep = parseNumber();
            else if (key == "parts") parseParts(input.parts);
            else skipValue();
            consume(',');
        }
        return input;
    }

private:
    std::string s_;
    size_t i_ = 0;

    void ws() {
        if (i_ == 0 && s_.size() >= 3
            && static_cast<unsigned char>(s_[0]) == 0xEF
            && static_cast<unsigned char>(s_[1]) == 0xBB
            && static_cast<unsigned char>(s_[2]) == 0xBF) {
            i_ = 3;
        }
        while (i_ < s_.size() && (s_[i_] == ' ' || s_[i_] == '\n' || s_[i_] == '\r' || s_[i_] == '\t')) ++i_;
    }

    bool consume(char c) {
        ws();
        if (i_ < s_.size() && s_[i_] == c) {
            ++i_;
            return true;
        }
        return false;
    }

    void expect(char c) {
        if (!consume(c)) throw std::runtime_error(std::string("Expected '") + c + "'");
    }

    std::string parseString() {
        ws();
        expect('"');
        std::string out;
        while (i_ < s_.size()) {
            char c = s_[i_++];
            if (c == '"') break;
            if (c == '\\' && i_ < s_.size()) {
                char e = s_[i_++];
                if (e == '"' || e == '\\' || e == '/') out.push_back(e);
                else if (e == 'n') out.push_back('\n');
                else if (e == 'r') out.push_back('\r');
                else if (e == 't') out.push_back('\t');
                else out.push_back(e);
            } else {
                out.push_back(c);
            }
        }
        return out;
    }

    double parseNumber() {
        ws();
        size_t start = i_;
        if (i_ < s_.size() && (s_[i_] == '-' || s_[i_] == '+')) ++i_;
        while (i_ < s_.size() && std::isdigit(static_cast<unsigned char>(s_[i_]))) ++i_;
        if (i_ < s_.size() && s_[i_] == '.') {
            ++i_;
            while (i_ < s_.size() && std::isdigit(static_cast<unsigned char>(s_[i_]))) ++i_;
        }
        if (i_ < s_.size() && (s_[i_] == 'e' || s_[i_] == 'E')) {
            ++i_;
            if (i_ < s_.size() && (s_[i_] == '-' || s_[i_] == '+')) ++i_;
            while (i_ < s_.size() && std::isdigit(static_cast<unsigned char>(s_[i_]))) ++i_;
        }
        return std::stod(s_.substr(start, i_ - start));
    }

    bool parseBool() {
        ws();
        if (s_.compare(i_, 4, "true") == 0) {
            i_ += 4;
            return true;
        }
        if (s_.compare(i_, 5, "false") == 0) {
            i_ += 5;
            return false;
        }
        throw std::runtime_error("Expected boolean");
    }

    void parseParts(std::vector<Part>& parts) {
        expect('[');
        while (!consume(']')) {
            Part part;
            expect('{');
            while (!consume('}')) {
                std::string key = parseString();
                expect(':');
                if (key == "polygon" || key == "points") {
                    parsePolygon(part.polygon);
                } else if (key == "index" || key == "width" || key == "height" || key == "area"
                    || key == "perimeter" || key == "maxSide" || key == "minSide") {
                    double value = parseNumber();
                    if (key == "index") part.index = static_cast<int>(value);
                    else if (key == "width") part.width = value;
                    else if (key == "height") part.height = value;
                    else if (key == "area") part.area = value;
                    else if (key == "perimeter") part.perimeter = value;
                    else if (key == "maxSide") part.maxSide = value;
                    else if (key == "minSide") part.minSide = value;
                } else {
                    skipValue();
                }
                consume(',');
            }
            if ((part.width <= 0.0 || part.height <= 0.0) && part.polygon.size() >= 3) {
                PolyBounds bounds = boundsFromPolygon(part.polygon);
                part.width = bounds.maxX - bounds.minX;
                part.height = bounds.maxY - bounds.minY;
            }
            if (part.area <= 0.0 && part.polygon.size() >= 3) part.area = rawPolygonArea(part.polygon);
            if (part.area <= 0.0) part.area = part.width * part.height;
            if (part.perimeter <= 0.0) part.perimeter = 2.0 * (part.width + part.height);
            if (part.maxSide <= 0.0) part.maxSide = std::max(part.width, part.height);
            if (part.minSide <= 0.0) part.minSide = std::min(part.width, part.height);
            parts.push_back(part);
            consume(',');
        }
    }

    void parsePolygon(std::vector<Point>& points) {
        expect('[');
        while (!consume(']')) {
            expect('[');
            double x = parseNumber();
            expect(',');
            double y = parseNumber();
            expect(']');
            points.push_back({x, y});
            consume(',');
        }
    }

    void skipValue() {
        ws();
        if (i_ >= s_.size()) return;
        if (s_[i_] == '"') {
            parseString();
            return;
        }
        if (s_[i_] == '{' || s_[i_] == '[') {
            char open = s_[i_];
            char close = open == '{' ? '}' : ']';
            int depth = 0;
            do {
                if (s_[i_] == '"') parseString();
                else {
                    if (s_[i_] == open) ++depth;
                    if (s_[i_] == close) --depth;
                    ++i_;
                }
            } while (i_ < s_.size() && depth > 0);
            return;
        }
        while (i_ < s_.size() && s_[i_] != ',' && s_[i_] != '}' && s_[i_] != ']') ++i_;
    }
};

static Sheet createSheet(double width, double height) {
    return Sheet{{Rect{0.0, 0.0, width, height}}};
}

static std::vector<Point> rectPolygon(double width, double height) {
    return {{0.0, 0.0}, {width, 0.0}, {width, height}, {0.0, height}};
}

static std::vector<Point> normalizePolygon(const std::vector<Point>& points) {
    if (points.size() < 3) return {};
    PolyBounds bounds = boundsFromPolygon(points);
    std::vector<Point> out;
    out.reserve(points.size());
    for (const auto& p : points) out.push_back({p.x - bounds.minX, p.y - bounds.minY});
    return out;
}

static std::vector<Point> rotatePolygon(const std::vector<Point>& points, double angle) {
    double radians = angle * 3.14159265358979323846 / 180.0;
    double c = std::cos(radians);
    double s = std::sin(radians);
    std::vector<Point> out;
    out.reserve(points.size());
    for (const auto& p : points) out.push_back({p.x * c - p.y * s, p.x * s + p.y * c});
    return normalizePolygon(out);
}

static std::vector<Point> translatePolygon(const std::vector<Point>& points, double x, double y) {
    std::vector<Point> out;
    out.reserve(points.size());
    for (const auto& p : points) out.push_back({p.x + x, p.y + y});
    return out;
}

static double polygonArea(const std::vector<Point>& points) {
    return rawPolygonArea(points);
}

static bool pointInPolygon(const Point& p, const std::vector<Point>& poly) {
    bool inside = false;
    for (size_t i = 0, j = poly.size() - 1; i < poly.size(); j = i++) {
        const auto& a = poly[i];
        const auto& b = poly[j];
        if (((a.y > p.y) != (b.y > p.y)) && (p.x < (b.x - a.x) * (p.y - a.y) / (b.y - a.y) + a.x)) inside = !inside;
    }
    return inside;
}

static int orientation(const Point& p, const Point& q, const Point& r) {
    double v = (q.y - p.y) * (r.x - q.x) - (q.x - p.x) * (r.y - q.y);
    if (std::abs(v) < 0.001) return 0;
    return v > 0.0 ? 1 : 2;
}

static bool onSegment(const Point& p, const Point& q, const Point& r) {
    return q.x <= std::max(p.x, r.x) + 0.001 && q.x + 0.001 >= std::min(p.x, r.x)
        && q.y <= std::max(p.y, r.y) + 0.001 && q.y + 0.001 >= std::min(p.y, r.y);
}

static bool segmentsIntersect(const Point& a, const Point& b, const Point& c, const Point& d) {
    int o1 = orientation(a, b, c);
    int o2 = orientation(a, b, d);
    int o3 = orientation(c, d, a);
    int o4 = orientation(c, d, b);
    if (o1 != o2 && o3 != o4) return true;
    if (o1 == 0 && onSegment(a, c, b)) return true;
    if (o2 == 0 && onSegment(a, d, b)) return true;
    if (o3 == 0 && onSegment(c, a, d)) return true;
    if (o4 == 0 && onSegment(c, b, d)) return true;
    return false;
}

static bool polygonsOverlap(const std::vector<Point>& a, const std::vector<Point>& b) {
    if (a.size() < 3 || b.size() < 3) return false;
    PolyBounds ab = boundsFromPolygon(a);
    PolyBounds bb = boundsFromPolygon(b);
    if (ab.maxX <= bb.minX || bb.maxX <= ab.minX || ab.maxY <= bb.minY || bb.maxY <= ab.minY) return false;
    for (size_t i = 0; i < a.size(); ++i) {
        const Point& a1 = a[i];
        const Point& a2 = a[(i + 1) % a.size()];
        for (size_t j = 0; j < b.size(); ++j) {
            if (segmentsIntersect(a1, a2, b[j], b[(j + 1) % b.size()])) return true;
        }
    }
    return pointInPolygon(a[0], b) || pointInPolygon(b[0], a);
}

static double distanceSquared(const Point& a, const Point& b) {
    double dx = a.x - b.x;
    double dy = a.y - b.y;
    return dx * dx + dy * dy;
}

static double pointSegmentDistanceSquared(const Point& p, const Point& a, const Point& b) {
    double dx = b.x - a.x;
    double dy = b.y - a.y;
    double len2 = dx * dx + dy * dy;
    if (len2 <= 0.000001) return distanceSquared(p, a);
    double t = ((p.x - a.x) * dx + (p.y - a.y) * dy) / len2;
    t = std::max(0.0, std::min(1.0, t));
    Point projected{a.x + t * dx, a.y + t * dy};
    return distanceSquared(p, projected);
}

static double segmentDistanceSquared(const Point& a, const Point& b, const Point& c, const Point& d) {
    if (segmentsIntersect(a, b, c, d)) return 0.0;
    return std::min(
        std::min(pointSegmentDistanceSquared(a, c, d), pointSegmentDistanceSquared(b, c, d)),
        std::min(pointSegmentDistanceSquared(c, a, b), pointSegmentDistanceSquared(d, a, b)));
}

static bool polygonsWithinSpacing(const std::vector<Point>& a, const std::vector<Point>& b, double spacing) {
    if (spacing <= 0.0) return false;
    double spacing2 = spacing * spacing;
    for (size_t i = 0; i < a.size(); ++i) {
        const Point& a1 = a[i];
        const Point& a2 = a[(i + 1) % a.size()];
        for (size_t j = 0; j < b.size(); ++j) {
            if (segmentDistanceSquared(a1, a2, b[j], b[(j + 1) % b.size()]) < spacing2 - 0.001) return true;
        }
    }
    return false;
}

struct PlacedPolygon {
    std::vector<Point> polygon;
    PolyBounds bounds;
};

static bool canPlacePolygon(const std::vector<Point>& polygon, const PolyBounds& bounds, const std::vector<PlacedPolygon>& placed,
    double sheetW, double sheetH, double spacing) {
    if (bounds.minX < -0.01 || bounds.minY < -0.01 || bounds.maxX > sheetW + 0.01 || bounds.maxY > sheetH + 0.01) return false;
    PolyBounds inflated{bounds.minX - spacing, bounds.minY - spacing, bounds.maxX + spacing, bounds.maxY + spacing};
    for (const auto& other : placed) {
        if (inflated.maxX <= other.bounds.minX || other.bounds.maxX <= inflated.minX
            || inflated.maxY <= other.bounds.minY || other.bounds.maxY <= inflated.minY) {
            continue;
        }
        if (polygonsOverlap(polygon, other.polygon)) return false;
        if (polygonsWithinSpacing(polygon, other.polygon, spacing)) return false;
    }
    return true;
}

static Rect rotatedSize(const Part& part, double angle) {
    double radians = angle * 3.14159265358979323846 / 180.0;
    double c = std::abs(std::cos(radians));
    double s = std::abs(std::sin(radians));
    return Rect{0.0, 0.0, part.width * c + part.height * s, part.width * s + part.height * c};
}

static bool contained(const Rect& a, const Rect& b) {
    return a.x >= b.x - 0.01 && a.y >= b.y - 0.01
        && a.x + a.width <= b.x + b.width + 0.01
        && a.y + a.height <= b.y + b.height + 0.01;
}

static void pruneFreeRects(std::vector<Rect>& freeRects) {
    for (int i = static_cast<int>(freeRects.size()) - 1; i >= 0; --i) {
        for (int j = static_cast<int>(freeRects.size()) - 1; j >= 0; --j) {
            if (i != j && i < static_cast<int>(freeRects.size()) && j < static_cast<int>(freeRects.size())) {
                if (contained(freeRects[static_cast<size_t>(i)], freeRects[static_cast<size_t>(j)])) {
                    freeRects.erase(freeRects.begin() + i);
                    break;
                }
            }
        }
    }
}

static void splitFreeRects(Sheet& sheet, double x, double y, double w, double h) {
    auto& freeRects = sheet.freeRects;
    std::vector<Rect> newRects;
    for (int i = static_cast<int>(freeRects.size()) - 1; i >= 0; --i) {
        Rect rect = freeRects[static_cast<size_t>(i)];
        if (x >= rect.x + rect.width || x + w <= rect.x || y >= rect.y + rect.height || y + h <= rect.y) {
            continue;
        }
        freeRects.erase(freeRects.begin() + i);
        if (x > rect.x) newRects.push_back({rect.x, rect.y, x - rect.x, rect.height});
        if (x + w < rect.x + rect.width) newRects.push_back({x + w, rect.y, rect.x + rect.width - x - w, rect.height});
        if (y > rect.y) newRects.push_back({rect.x, rect.y, rect.width, y - rect.y});
        if (y + h < rect.y + rect.height) newRects.push_back({rect.x, y + h, rect.width, rect.y + rect.height - y - h});
    }
    for (const auto& rect : newRects) {
        if (rect.width > 1.0 && rect.height > 1.0) freeRects.push_back(rect);
    }
    pruneFreeRects(freeRects);
}

static int findBestRect(const std::vector<Rect>& freeRects, double w, double h, double& score) {
    int best = -1;
    score = std::numeric_limits<double>::infinity();
    for (int i = 0; i < static_cast<int>(freeRects.size()); ++i) {
        const auto& rect = freeRects[static_cast<size_t>(i)];
        if (rect.width >= w - 0.01 && rect.height >= h - 0.01) {
            double shortSide = std::min(rect.height - h, rect.width - w);
            double candidate = rect.y * 1000000.0 + rect.x * 1000.0 + shortSide;
            if (candidate < score) {
                score = candidate;
                best = i;
            }
        }
    }
    return best;
}

static Result runMaxRects(const std::vector<Part>& parts, double sheetW, double sheetH, double spacing, const std::vector<double>& angles) {
    Result result;
    std::vector<Sheet> sheets{createSheet(sheetW, sheetH)};
    double totalArea = 0.0;

    for (const auto& part : parts) {
        totalArea += part.area;
        int bestSheet = -1;
        int bestRect = -1;
        double bestRotation = 0.0;
        double bestScore = std::numeric_limits<double>::infinity();

        for (int si = 0; si < static_cast<int>(sheets.size()); ++si) {
            for (double angle : angles) {
                Rect size = rotatedSize(part, angle);
                double tw = size.width + spacing;
                double th = size.height + spacing;
                if (tw > sheetW + 0.01 || th > sheetH + 0.01) continue;
                double rectScore = 0.0;
                int rectIndex = findBestRect(sheets[static_cast<size_t>(si)].freeRects, tw, th, rectScore);
                if (rectIndex >= 0) {
                    double score = si * 100000000.0 + rectScore;
                    if (score < bestScore) {
                        bestScore = score;
                        bestSheet = si;
                        bestRect = rectIndex;
                        bestRotation = angle;
                    }
                }
            }
        }

        if (bestSheet < 0) {
            bestSheet = static_cast<int>(sheets.size());
            sheets.push_back(createSheet(sheetW, sheetH));
            for (double angle : angles) {
                Rect size = rotatedSize(part, angle);
                if (size.width + spacing <= sheetW && size.height + spacing <= sheetH) {
                    bestRect = 0;
                    bestRotation = angle;
                    break;
                }
            }
        }

        if (bestRect >= 0) {
            Rect chosen = sheets[static_cast<size_t>(bestSheet)].freeRects[static_cast<size_t>(bestRect)];
            Rect size = rotatedSize(part, bestRotation);
            result.placements.push_back({part, chosen.x, chosen.y, bestRotation, bestSheet});
            splitFreeRects(sheets[static_cast<size_t>(bestSheet)], chosen.x, chosen.y, size.width + spacing, size.height + spacing);
        }
    }

    result.sheetCount = static_cast<int>(sheets.size());
    result.utilization = result.sheetCount > 0 ? totalArea / (result.sheetCount * sheetW * sheetH) : 0.0;
    return result;
}

static Result runTrueShapeNesting(const std::vector<Part>& parts, double sheetW, double sheetH, double spacing,
    const std::vector<double>& angles, double placementStep) {
    struct TrueShapeSheet {
        std::vector<PlacedPolygon> placed;
    };

    Result result;
    std::vector<TrueShapeSheet> sheets(1);
    double totalArea = 0.0;
    double step = std::max(2.0, placementStep > 0.0 ? placementStep : std::max(10.0, spacing));
    double estimatedGrid = std::ceil(sheetW / step) * std::ceil(sheetH / step);
    if (estimatedGrid > 3000.0) step = std::sqrt((sheetW * sheetH) / 3000.0);

    for (size_t pi = 0; pi < parts.size(); ++pi) {
        const Part& part = parts[pi];
        totalArea += part.area > 0.0 ? part.area : polygonArea(part.polygon);
        bool found = false;
        Placement best;
        std::vector<Point> bestPolygon;
        PolyBounds bestBounds;
        std::vector<Point> basePolygon = part.polygon.size() >= 3 ? normalizePolygon(part.polygon) : rectPolygon(part.width, part.height);

        for (int si = 0; si < static_cast<int>(sheets.size()) && !found; ++si) {
            for (double angle : angles) {
                std::vector<Point> rotated = rotatePolygon(basePolygon, angle);
                if (rotated.size() < 3) continue;
                PolyBounds rb = boundsFromPolygon(rotated);
                double rw = rb.maxX - rb.minX;
                double rh = rb.maxY - rb.minY;
                if (rw > sheetW + 0.01 || rh > sheetH + 0.01) continue;

                std::vector<Point> candidates{{0.0, 0.0}};
                for (const auto& placed : sheets[static_cast<size_t>(si)].placed) {
                    candidates.push_back({placed.bounds.maxX + spacing, placed.bounds.minY});
                    candidates.push_back({placed.bounds.minX, placed.bounds.maxY + spacing});
                    candidates.push_back({placed.bounds.maxX + spacing, placed.bounds.maxY + spacing});
                }
                for (double y = 0.0; y <= sheetH - rh + 0.01; y += step) {
                    for (double x = 0.0; x <= sheetW - rw + 0.01; x += step) {
                        candidates.push_back({x, y});
                    }
                }
                std::sort(candidates.begin(), candidates.end(), [](const Point& a, const Point& b) {
                    if (std::abs(a.y - b.y) > 0.001) return a.y < b.y;
                    return a.x < b.x;
                });

                for (const auto& pos : candidates) {
                    std::vector<Point> moved = translatePolygon(rotated, pos.x, pos.y);
                    PolyBounds mb = boundsFromPolygon(moved);
                    if (canPlacePolygon(moved, mb, sheets[static_cast<size_t>(si)].placed, sheetW, sheetH, spacing)) {
                        best = Placement{part, pos.x, pos.y, angle, si};
                        bestPolygon = std::move(moved);
                        bestBounds = mb;
                        found = true;
                        break;
                    }
                }
                if (found) break;
            }
        }

        if (!found) {
            if (sheets.size() > parts.size()) continue;
            sheets.push_back(TrueShapeSheet{});
            --pi;
            continue;
        }

        sheets[static_cast<size_t>(best.sheetIndex)].placed.push_back({bestPolygon, bestBounds});
        result.placements.push_back(best);
    }

    result.sheetCount = static_cast<int>(sheets.size());
    result.utilization = result.sheetCount > 0 ? totalArea / (result.sheetCount * sheetW * sheetH) : 0.0;
    return result;
}

static std::vector<double> makeAngles(bool allowRotation, double step) {
    if (!allowRotation) return {0.0};
    double safeStep = std::max(1.0, std::min(90.0, std::abs(step)));
    std::vector<double> angles;
    for (double a = 0.0; a < 360.0 - 0.001; a += safeStep) angles.push_back(a);
    return angles.empty() ? std::vector<double>{0.0} : angles;
}

static Result optimize(const Input& input) {
    if (input.sheetWidth <= 0.0 || input.sheetHeight <= 0.0) throw std::runtime_error("Invalid sheet size");
    std::vector<double> angles = makeAngles(input.allowRotation, input.rotationStep);
    std::vector<Part> parts = input.parts;

    // 5 种排序策略互相独立 —— 并行计算，各写自己的结果槽，最后取最优。
    const int kStrategies = 5;
    std::vector<Result> results(static_cast<size_t>(kStrategies));

    auto runStrategy = [&](int strategy) {
        std::vector<Part> sorted = parts;
        std::stable_sort(sorted.begin(), sorted.end(), [strategy](const Part& a, const Part& b) {
            if (strategy == 0) return a.area > b.area;
            if (strategy == 1) return a.maxSide > b.maxSide;
            if (strategy == 2) return a.height > b.height;
            if (strategy == 3) return a.width > b.width;
            return a.perimeter > b.perimeter;
        });
        results[static_cast<size_t>(strategy)] = input.useTrueShape
            ? runTrueShapeNesting(sorted, input.sheetWidth, input.sheetHeight, input.spacing, angles, input.placementStep)
            : runMaxRects(sorted, input.sheetWidth, input.sheetHeight, input.spacing, angles);
    };

    unsigned int hw = std::thread::hardware_concurrency();
    if (hw <= 1) {
        for (int s = 0; s < kStrategies; ++s) runStrategy(s);
    } else {
        std::vector<std::thread> pool;
        pool.reserve(static_cast<size_t>(kStrategies));
        for (int s = 0; s < kStrategies; ++s) pool.emplace_back(runStrategy, s);
        for (auto& t : pool) t.join();
    }

    Result best;
    int bestSheetCount = std::numeric_limits<int>::max();
    double bestUtilization = 0.0;
    for (int s = 0; s < kStrategies; ++s) {
        const Result& result = results[static_cast<size_t>(s)];
        bool better = result.sheetCount < bestSheetCount
            || (result.sheetCount == bestSheetCount && result.utilization > bestUtilization);
        if (better) {
            best = result;
            bestSheetCount = best.sheetCount;
            bestUtilization = best.utilization;
        }
    }
    return best;
}

static std::string readFile(const std::string& path) {
    std::ifstream in(path, std::ios::binary);
    if (!in) throw std::runtime_error("Cannot open input file");
    std::ostringstream ss;
    ss << in.rdbuf();
    return ss.str();
}

static void writeJsonString(std::ostream& out, const std::string& s) {
    out << '"';
    for (char c : s) {
        if (c == '"' || c == '\\') out << '\\' << c;
        else if (c == '\n') out << "\\n";
        else if (c == '\r') out << "\\r";
        else out << c;
    }
    out << '"';
}

static void writeOutput(const std::string& path, const Result& result) {
    std::ofstream out(path, std::ios::binary);
    if (!out) throw std::runtime_error("Cannot open output file");
    out << std::fixed << std::setprecision(3);
    out << "{\"success\":true,\"sheetCount\":" << result.sheetCount
        << ",\"utilization\":" << result.utilization
        << ",\"placements\":[";
    for (size_t i = 0; i < result.placements.size(); ++i) {
        const auto& p = result.placements[i];
        if (i) out << ',';
        out << "{\"index\":" << p.part.index
            << ",\"x\":" << p.x
            << ",\"y\":" << p.y
            << ",\"rotation\":" << p.rotation
            << ",\"sheetIndex\":" << p.sheetIndex
            << "}";
    }
    out << "]}";
}

static int runSelfTest() {
    Input input;
    input.sheetWidth = 300.0;
    input.sheetHeight = 200.0;
    input.spacing = 5.0;
    input.allowRotation = true;
    input.parts = {
        {0, 140.0, 90.0, 12600.0, 460.0, 140.0, 90.0},
        {1, 140.0, 90.0, 12600.0, 460.0, 140.0, 90.0},
        {2, 180.0, 60.0, 10800.0, 480.0, 180.0, 60.0}
    };
    Result result = optimize(input);
    if (result.placements.size() != 3) throw std::runtime_error("Expected all parts to be placed");
    if (result.sheetCount < 1) throw std::runtime_error("Expected at least one sheet");
    for (const auto& p : result.placements) {
        if (p.x < -0.01 || p.y < -0.01) throw std::runtime_error("Placement outside sheet");
    }

    Input trueShape;
    trueShape.sheetWidth = 180.0;
    trueShape.sheetHeight = 120.0;
    trueShape.spacing = 4.0;
    trueShape.allowRotation = true;
    trueShape.useTrueShape = true;
    trueShape.rotationStep = 15.0;
    trueShape.placementStep = 6.0;
    Part star;
    star.index = 0;
    star.width = 70.0;
    star.height = 70.0;
    star.polygon = {{35.0, 0.0}, {45.0, 25.0}, {70.0, 25.0}, {50.0, 42.0}, {58.0, 70.0},
        {35.0, 53.0}, {12.0, 70.0}, {20.0, 42.0}, {0.0, 25.0}, {25.0, 25.0}};
    star.area = polygonArea(star.polygon);
    star.perimeter = 280.0;
    star.maxSide = 70.0;
    star.minSide = 70.0;
    Part triangle;
    triangle.index = 1;
    triangle.width = 50.0;
    triangle.height = 50.0;
    triangle.polygon = {{25.0, 0.0}, {50.0, 50.0}, {0.0, 50.0}};
    triangle.area = polygonArea(triangle.polygon);
    triangle.perimeter = 170.0;
    triangle.maxSide = 50.0;
    triangle.minSide = 50.0;
    trueShape.parts = {star, triangle, star, triangle};
    Result trueShapeResult = optimize(trueShape);
    if (trueShapeResult.placements.size() != 4) throw std::runtime_error("Expected true-shape parts to be placed");
    for (const auto& p : trueShapeResult.placements) {
        if (p.rotation < -0.01 || p.rotation >= 360.0) throw std::runtime_error("Invalid true-shape rotation");
    }

    std::cout << "nesting_native self-test passed\n";
    return 0;
}

int main(int argc, char** argv) {
    if (argc == 2 && std::string(argv[1]) == "--self-test") {
        try {
            return runSelfTest();
        } catch (const std::exception& e) {
            std::cerr << e.what() << "\n";
            return 1;
        }
    }
    if (argc < 3) {
        std::cerr << "Usage: nesting_native <input.json> <output.json>\n";
        return 2;
    }
    try {
        Input input = Json(readFile(argv[1])).parseRoot();
        Result result = optimize(input);
        writeOutput(argv[2], result);
        return 0;
    } catch (const std::exception& e) {
        std::ofstream out(argv[2], std::ios::binary);
        if (out) {
            out << "{\"success\":false,\"error\":";
            writeJsonString(out, e.what());
            out << "}";
        }
        std::cerr << e.what() << "\n";
        return 1;
    }
}
