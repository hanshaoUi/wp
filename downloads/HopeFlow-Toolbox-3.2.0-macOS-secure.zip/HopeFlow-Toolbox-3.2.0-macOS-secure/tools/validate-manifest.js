#!/usr/bin/env node
/**
 * 校验多扩展配置一致性：
 *   CSXS/manifest.xml 的扩展 ID ↔ route-handoff EXT_IDS ↔ .debug 调试端口
 * 用法：node tools/validate-manifest.js
 */
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');

function idsFromManifest() {
  const xml = fs.readFileSync(path.join(root, 'CSXS', 'manifest.xml'), 'utf8');
  const list = new Set();
  const section = xml.split('<ExtensionList>')[1].split('</ExtensionList>')[0];
  for (const m of section.matchAll(/Extension Id="([^"]+)"/g)) list.add(m[1]);
  // DispatchInfoList 也要有对应条目
  const dispatch = new Set();
  const dsec = xml.split('<DispatchInfoList>')[1] || '';
  for (const m of dsec.matchAll(/Extension Id="([^"]+)"/g)) dispatch.add(m[1]);
  return { list, dispatch };
}

function idsFromCode() {
  const src = fs.readFileSync(path.join(root, 'src', 'services', 'route-handoff.ts'), 'utf8');
  const section = src.split('export const EXT_IDS')[1].split('} as const')[0];
  const ids = new Set();
  for (const m of section.matchAll(/'(com\.hopeflow\.[a-z.]+)'/g)) ids.add(m[1]);
  return ids;
}

function idsFromDebug() {
  const file = path.join(root, '.debug');
  const ids = new Map();
  if (!fs.existsSync(file)) return ids;
  const xml = fs.readFileSync(file, 'utf8');
  for (const m of xml.matchAll(/Extension Id="([^"]+)">[\s\S]*?Port="(\d+)"/g)) ids.set(m[1], m[2]);
  return ids;
}

const problems = [];
const { list: manifestIds, dispatch } = idsFromManifest();
const codeIds = idsFromCode();
const debugIds = idsFromDebug();

for (const id of manifestIds) {
  if (!dispatch.has(id)) problems.push(`manifest ExtensionList 有 ${id} 但 DispatchInfoList 缺失`);
  if (!codeIds.has(id)) problems.push(`manifest 有 ${id} 但 route-handoff EXT_IDS 缺失`);
  if (!debugIds.has(id)) problems.push(`manifest 有 ${id} 但 .debug 缺调试端口`);
}
for (const id of codeIds) {
  if (!manifestIds.has(id)) problems.push(`EXT_IDS 有 ${id} 但 manifest 缺失`);
}
const ports = [...debugIds.values()];
if (new Set(ports).size !== ports.length) problems.push('.debug 存在重复端口');

if (problems.length) {
  console.error(`Manifest 校验失败 (${problems.length}):`);
  problems.forEach((p) => console.error('  ✗ ' + p));
  process.exit(1);
}
console.log(`Manifest 校验通过: ${manifestIds.size} 个扩展 (manifest/EXT_IDS/.debug 一致)`);
