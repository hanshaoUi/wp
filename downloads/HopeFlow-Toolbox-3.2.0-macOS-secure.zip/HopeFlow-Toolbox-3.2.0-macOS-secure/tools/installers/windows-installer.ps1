param(
    [switch]$Gui,
    [switch]$Cli,
    [switch]$Uninstall,
    [switch]$Check,
    [switch]$Dev
)

$ErrorActionPreference = 'Stop'

$ExtensionId = 'com.hopeflow.toolbox'
$ExtensionFolderName = 'HopeFlow Toolbox'
$RootDir = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$UserCepRoot = Join-Path $env:APPDATA 'Adobe\CEP\extensions'
$InstallDir = Join-Path $UserCepRoot $ExtensionId
$BackupRoot = Join-Path $env:TEMP 'HopeFlowToolboxBackups'
$NativeAipName = 'HopeFlow.aip'
$NativeAipWindowsRelativeRoot = 'tools\illustrator-aip\windows'
$GraphicReliefNativeRelativePath = 'tools\graphic-relief-native\build\Release\graphic_relief_native.exe'
$NativeAipExtraFolder = ([string][char]0x589E) + ([string][char]0x6548) + ([string][char]0x5DE5) + ([string][char]0x5177)
$MinIllustratorVersion = [version]'23.0'
$MaxIllustratorVersion = [version]'99.9'

function Write-Step {
    param([string]$Message)
    Write-Host "[HopeFlow] $Message"
}

function Convert-ToVersion {
    param([string]$Value)

    if ([string]::IsNullOrWhiteSpace($Value)) {
        return $null
    }

    $match = [regex]::Match($Value, '\d+(\.\d+){0,3}')
    if (-not $match.Success) {
        return $null
    }

    try {
        return [version]$match.Value
    } catch {
        return $null
    }
}

function Get-IllustratorInstallations {
    $items = New-Object System.Collections.Generic.List[object]
    $seen = @{}

    function Add-IllustratorCandidate {
        param([string]$Path)

        if ([string]::IsNullOrWhiteSpace($Path)) {
            return
        }

        $resolved = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($Path)
        if (-not (Test-Path -LiteralPath $resolved -PathType Leaf)) {
            return
        }

        $key = $resolved.ToLowerInvariant()
        if ($seen.ContainsKey($key)) {
            return
        }
        $seen[$key] = $true

        $file = Get-Item -LiteralPath $resolved
        $version = Convert-ToVersion $file.VersionInfo.ProductVersion
        if ($null -eq $version) {
            $version = Convert-ToVersion $file.VersionInfo.FileVersion
        }

        $items.Add([pscustomobject]@{
            Name = $file.VersionInfo.ProductName
            Version = $version
            ProductVersion = $file.VersionInfo.ProductVersion
            Path = $resolved
            Compatible = ($null -ne $version -and $version -ge $MinIllustratorVersion -and $version -le $MaxIllustratorVersion)
        }) | Out-Null
    }

    $programRoots = @(
        ${env:ProgramFiles},
        ${env:ProgramFiles(x86)}
    ) | Where-Object { -not [string]::IsNullOrWhiteSpace($_) }

    foreach ($root in $programRoots) {
        $adobeRoot = Join-Path $root 'Adobe'
        if (Test-Path -LiteralPath $adobeRoot) {
            Get-ChildItem -LiteralPath $adobeRoot -Directory -Filter 'Adobe Illustrator*' -ErrorAction SilentlyContinue | ForEach-Object {
                Add-IllustratorCandidate (Join-Path $_.FullName 'Support Files\Contents\Windows\Illustrator.exe')
            }
        }
    }

    $appPathKeys = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\Illustrator.exe',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\Illustrator.exe',
        'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\Illustrator.exe'
    )

    foreach ($key in $appPathKeys) {
        if (Test-Path $key) {
            try {
                $defaultPath = (Get-ItemProperty -Path $key).'(default)'
                Add-IllustratorCandidate $defaultPath
            } catch {
            }
        }
    }

    $uninstallRoots = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall',
        'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall'
    )

    foreach ($root in $uninstallRoots) {
        if (-not (Test-Path $root)) {
            continue
        }

        Get-ChildItem -Path $root -ErrorAction SilentlyContinue | ForEach-Object {
            try {
                $entry = Get-ItemProperty -Path $_.PSPath
                if ($entry.DisplayName -like 'Adobe Illustrator*' -and $entry.InstallLocation) {
                    Add-IllustratorCandidate (Join-Path $entry.InstallLocation 'Support Files\Contents\Windows\Illustrator.exe')
                    Add-IllustratorCandidate (Join-Path $entry.InstallLocation 'Illustrator.exe')
                }
            } catch {
            }
        }
    }

    return @($items | Sort-Object -Property @{ Expression = { if ($_.Version) { $_.Version } else { [version]'0.0' } }; Descending = $true }, Path)
}

function Get-IllustratorSummary {
    $installations = @(Get-IllustratorInstallations)
    if ($installations.Count -eq 0) {
        return 'Illustrator: not detected. Supported versions: 23.0 or later.'
    }

    $lines = @('Detected Illustrator:')
    foreach ($item in $installations) {
        $versionText = if ($item.Version) { $item.Version.ToString() } elseif ($item.ProductVersion) { $item.ProductVersion } else { 'unknown version' }
        $state = if ($item.Compatible) { 'compatible' } else { 'incompatible' }
        $lines += "- $versionText ($state)"
    }
    return ($lines -join "`r`n")
}

function Test-CompatibleIllustrator {
    $installations = @(Get-IllustratorInstallations)
    return ($installations | Where-Object { $_.Compatible } | Select-Object -First 1) -ne $null
}

function Get-IllustratorSettingsRoots {
    $roots = @()
    $adobeRoaming = Join-Path $env:APPDATA 'Adobe'
    if (Test-Path -LiteralPath $adobeRoaming) {
        $roots = @(Get-ChildItem -LiteralPath $adobeRoaming -Directory -Filter 'Adobe Illustrator*Settings' -ErrorAction SilentlyContinue)
    }
    return @($roots | Sort-Object FullName -Unique)
}

function Get-IllustratorYearFromPath {
    param([string]$Path)

    $majorMatch = [regex]::Match($Path, 'Adobe Illustrator (\d{2}) Settings')
    if ($majorMatch.Success) {
        return (1996 + [int]$majorMatch.Groups[1].Value).ToString()
    }

    $yearMatch = [regex]::Match($Path, 'Adobe Illustrator (\d{4})')
    if ($yearMatch.Success) {
        return $yearMatch.Groups[1].Value
    }

    return $null
}

function Get-NewestVersionedNativeAip {
    # 无匹配年份时回退到 windows/ 下最新年份的 AIP（不再依赖 tools\illustrator-aip 根目录的散置副本）
    $root = Join-Path $RootDir $NativeAipWindowsRelativeRoot
    if (-not (Test-Path -LiteralPath $root -PathType Container)) {
        return $null
    }
    $candidates = @(Get-ChildItem -LiteralPath $root -Directory -ErrorAction SilentlyContinue |
        Sort-Object Name -Descending |
        ForEach-Object { Join-Path $_.FullName $NativeAipName } |
        Where-Object { Test-Path -LiteralPath $_ -PathType Leaf })
    if ($candidates.Count -gt 0) {
        return $candidates[0]
    }
    return $null
}

function Get-NativeAipSourceForYear {
    param([string]$Year)

    if ($Year) {
        $versioned = Join-Path $RootDir (Join-Path (Join-Path $NativeAipWindowsRelativeRoot $Year) $NativeAipName)
        if (Test-Path -LiteralPath $versioned -PathType Leaf) {
            return $versioned
        }
    }

    return (Get-NewestVersionedNativeAip)
}

function Get-NativeAipInstallTargets {
    $targets = New-Object System.Collections.Generic.List[object]
    $seen = @{}
    foreach ($settingsRoot in Get-IllustratorSettingsRoots) {
        $year = Get-IllustratorYearFromPath $settingsRoot.FullName
        $localeRoots = @(Get-ChildItem -LiteralPath $settingsRoot.FullName -Directory -ErrorAction SilentlyContinue)
        foreach ($localeRoot in $localeRoots) {
            $x64Root = Join-Path $localeRoot.FullName 'x64'
            if (-not (Test-Path -LiteralPath $x64Root -PathType Container)) {
                continue
            }

            foreach ($folderName in @('Plug-ins', $NativeAipExtraFolder)) {
                $target = Join-Path (Join-Path $x64Root $folderName) $NativeAipName
                $key = $target.ToLowerInvariant()
                if ($seen.ContainsKey($key)) {
                    continue
                }
                $seen[$key] = $true
                $targets.Add([pscustomobject]@{
                    Path = $target
                    Year = $year
                    Source = Get-NativeAipSourceForYear $year
                }) | Out-Null
            }
        }
    }
    return @($targets | Sort-Object Path)
}

function Remove-StaleNativeAipCopies {
    foreach ($settingsRoot in Get-IllustratorSettingsRoots) {
        $localeRoots = @(Get-ChildItem -LiteralPath $settingsRoot.FullName -Directory -ErrorAction SilentlyContinue)
        foreach ($localeRoot in $localeRoots) {
            $x64Root = Join-Path $localeRoot.FullName 'x64'
            if (-not (Test-Path -LiteralPath $x64Root -PathType Container)) {
                continue
            }

            $allowedRoots = @(
                (Join-Path $x64Root 'Plug-ins'),
                (Join-Path $x64Root $NativeAipExtraFolder)
            ) | ForEach-Object { $_.ToLowerInvariant() }

            $copies = @(Get-ChildItem -LiteralPath $x64Root -Recurse -Filter $NativeAipName -File -ErrorAction SilentlyContinue)
            foreach ($copy in $copies) {
                $parent = (Split-Path -Parent $copy.FullName).ToLowerInvariant()
                if ($allowedRoots -contains $parent) {
                    continue
                }
                Remove-Item -LiteralPath $copy.FullName -Force -ErrorAction SilentlyContinue
            }
        }
    }
}

function Test-PluginPackage {
    $required = @(
        'CSXS\manifest.xml',
        'dist\index.html',
        'ai-engine\src\server.py',
        'ai-engine\requirements.txt',
        'src\scripts\_runtime\bootstrap.jsx',
        $GraphicReliefNativeRelativePath
    )

    $missing = @()
    foreach ($item in $required) {
        $path = Join-Path $RootDir $item
        if (-not (Test-Path -LiteralPath $path)) {
            $missing += $item
        }
    }

    if (-not (Get-NewestVersionedNativeAip)) {
        $missing += "$NativeAipWindowsRelativeRoot\<year>\$NativeAipName"
    }

    if ($missing.Count -gt 0) {
        throw "The package is incomplete. Missing: $($missing -join ', '). Run npm run build before packaging, or use a complete release zip."
    }
}

function Test-SourceCheckout {
    $markers = @(
        'package.json',
        'package-lock.json',
        'build\webpack.config.js',
        'src\panel',
        'src\scripts\_runtime\bootstrap.jsx'
    )

    foreach ($item in $markers) {
        if (-not (Test-Path -LiteralPath (Join-Path $RootDir $item))) {
            return $false
        }
    }

    return $true
}

function Build-FromSource {
    if (-not (Test-SourceCheckout)) {
        throw 'The package is incomplete and this does not look like a full source checkout. Use a complete release zip, or run from the project root.'
    }

    $npm = Get-Command npm -ErrorAction SilentlyContinue
    if (-not $npm) {
        throw 'The package is incomplete and npm was not found. Install Node.js/npm, or use a complete release zip.'
    }

    Push-Location $RootDir
    try {
        if (-not (Test-Path -LiteralPath (Join-Path $RootDir 'node_modules'))) {
            Write-Step 'Installing npm dependencies...'
            npm ci
            if ($LASTEXITCODE -ne 0) {
                throw "npm ci failed with exit code $LASTEXITCODE."
            }
        }

        Write-Step 'Building panel from source...'
        npm run build
        if ($LASTEXITCODE -ne 0) {
            throw "npm run build failed with exit code $LASTEXITCODE."
        }

        Build-GraphicReliefNativeHelper
    } finally {
        Pop-Location
    }
}

function Build-GraphicReliefNativeHelper {
    $cmake = Get-Command cmake -ErrorAction SilentlyContinue
    if (-not $cmake) {
        throw 'Graphic relief native helper is missing and cmake was not found. Install CMake, or use a complete release zip.'
    }

    $sourceDir = Join-Path $RootDir 'tools\graphic-relief-native'
    $buildDir = Join-Path $sourceDir 'build'
    if (-not (Test-Path -LiteralPath (Join-Path $sourceDir 'CMakeLists.txt'))) {
        throw 'Graphic relief native helper source is missing. Use a complete release zip, or run from a full source checkout.'
    }

    Write-Step 'Building graphic relief native helper...'
    & cmake -S $sourceDir -B $buildDir -DCMAKE_BUILD_TYPE=Release
    if ($LASTEXITCODE -ne 0) {
        throw "Failed to configure graphic relief native helper. cmake exited with $LASTEXITCODE."
    }

    & cmake --build $buildDir --config Release
    if ($LASTEXITCODE -ne 0) {
        throw "Failed to build graphic relief native helper. cmake build exited with $LASTEXITCODE."
    }
}

function Ensure-PluginPackage {
    try {
        Test-PluginPackage
        return
    } catch {
        $packageError = $_.Exception.Message
        if (-not $Dev -and -not (Test-SourceCheckout)) {
            throw $packageError
        }
    }

    Write-Step 'Package build output is missing. Building from local source checkout...'
    Build-FromSource
    Test-PluginPackage
}

function Enable-CepDebugMode {
    for ($version = 9; $version -le 16; $version++) {
        $path = "HKCU:\Software\Adobe\CSXS.$version"
        if (-not (Test-Path $path)) {
            New-Item -Path $path -Force | Out-Null
        }
        New-ItemProperty -Path $path -Name 'PlayerDebugMode' -Value '1' -PropertyType String -Force | Out-Null
    }
}

function Remove-InstalledExtension {
    if (-not (Test-Path -LiteralPath $InstallDir)) {
        return
    }

    if (-not (Test-Path -LiteralPath $BackupRoot)) {
        New-Item -ItemType Directory -Path $BackupRoot -Force | Out-Null
    }

    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    $backupDir = Join-Path $BackupRoot "$ExtensionId-$stamp"

    try {
        Move-Item -LiteralPath $InstallDir -Destination $backupDir -Force
    } catch {
        Remove-Item -LiteralPath $InstallDir -Recurse -Force
    }
}

function Copy-PluginFiles {
    if (-not (Test-Path -LiteralPath $UserCepRoot)) {
        New-Item -ItemType Directory -Path $UserCepRoot -Force | Out-Null
    }

    Remove-InstalledExtension
    New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null

    $exclude = @(
        '.git',
        '.claude',
        '.vscode',
        '_local-archive',
        'node_modules',
        'release',
        '__pycache__',
        'hopeflow-docs'
    )

    $robocopyArgs = @(
        "`"$RootDir`"",
        "`"$InstallDir`"",
        '/E',
        '/NFL',
        '/NDL',
        '/NJH',
        '/NJS',
        '/NP',
        '/XD'
    )

    foreach ($item in $exclude) {
        $robocopyArgs += "`"$(Join-Path $RootDir $item)`""
    }

    $robocopyCommand = 'robocopy.exe ' + ($robocopyArgs -join ' ')
    cmd.exe /c $robocopyCommand | Out-Null
    $code = $LASTEXITCODE
    if ($code -ge 8) {
        throw "Failed to copy plugin files. Robocopy exit code: $code"
    }
}

function Ensure-GraphicReliefNativeHelper {
    $helperSource = Join-Path $RootDir $GraphicReliefNativeRelativePath
    if (-not (Test-Path -LiteralPath $helperSource -PathType Leaf)) {
        if (-not $Dev -and -not (Test-SourceCheckout)) {
            throw "The package is incomplete. Missing graphic relief native helper: $GraphicReliefNativeRelativePath"
        }

        Build-GraphicReliefNativeHelper
        if (-not (Test-Path -LiteralPath $helperSource -PathType Leaf)) {
            throw "Graphic relief native helper build did not produce $GraphicReliefNativeRelativePath"
        }
    }

    $helperTarget = Join-Path $InstallDir $GraphicReliefNativeRelativePath
    $helperTargetDir = Split-Path -Parent $helperTarget
    if (-not (Test-Path -LiteralPath $helperTargetDir)) {
        New-Item -ItemType Directory -Path $helperTargetDir -Force | Out-Null
    }

    Copy-Item -LiteralPath $helperSource -Destination $helperTarget -Force
}

function Install-NativeAip {
    $fallbackSource = Get-NewestVersionedNativeAip
    if (-not $fallbackSource) {
        throw "The package is incomplete. Missing native AIP under: $NativeAipWindowsRelativeRoot\<year>\$NativeAipName"
    }

    Remove-StaleNativeAipCopies

    $targets = @(Get-NativeAipInstallTargets)
    if ($targets.Count -eq 0) {
        throw 'No Illustrator user Plug-ins directories were found. Launch Illustrator once to create the settings folders, then retry.'
    }

    foreach ($target in $targets) {
        $source = $target.Source
        if (-not (Test-Path -LiteralPath $source -PathType Leaf)) {
            $source = $fallbackSource
        }
        $parent = Split-Path -Parent $target.Path
        if (-not (Test-Path -LiteralPath $parent)) {
            New-Item -ItemType Directory -Path $parent -Force | Out-Null
        }
        Copy-Item -LiteralPath $source -Destination $target.Path -Force
        $yearText = if ($target.Year) { "Illustrator $($target.Year)" } else { 'unknown Illustrator version' }
        Write-Step "Native AIP installed to: $($target.Path) ($yearText)"
    }
}

function Uninstall-NativeAip {
    Remove-StaleNativeAipCopies
    foreach ($target in Get-NativeAipInstallTargets) {
        if (Test-Path -LiteralPath $target.Path -PathType Leaf) {
            Remove-Item -LiteralPath $target.Path -Force
        }
    }
}

function Install-HopeFlow {
    Write-Step 'Checking package...'
    Ensure-PluginPackage

    Write-Step 'Checking Illustrator...'
    Write-Step (Get-IllustratorSummary)
    if (-not (Test-CompatibleIllustrator)) {
        throw 'No compatible Adobe Illustrator installation was detected. HopeFlow Toolbox requires Illustrator 23.0 or later.'
    }

    Write-Step 'Enabling CEP debug mode...'
    Enable-CepDebugMode

    Write-Step 'Copying extension files...'
    Copy-PluginFiles
    Ensure-GraphicReliefNativeHelper

    Write-Step 'Installing native AIP...'
    Install-NativeAip

    Write-Step "Installed to: $InstallDir"
}

function Uninstall-HopeFlow {
    Uninstall-NativeAip

    if (Test-Path -LiteralPath $InstallDir) {
        Remove-Item -LiteralPath $InstallDir -Recurse -Force
    }
}

try {
    if ($Check) {
        Ensure-PluginPackage
        Write-Step 'Package check passed.'
    } elseif ($Uninstall) {
        Uninstall-HopeFlow
    } else {
        Install-HopeFlow
    }
} catch {
    Write-Host "[ERROR] $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
