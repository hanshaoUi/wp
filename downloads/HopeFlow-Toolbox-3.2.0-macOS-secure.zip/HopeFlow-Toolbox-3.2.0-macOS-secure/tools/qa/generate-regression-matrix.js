#!/usr/bin/env node
/**
 * 从 src/registry/scripts/*.ts 生成 docs/qa/regression-matrix.md 的骨架。
 * 已有矩阵中人工勾选的结果不会被覆盖：如目标文件存在，勾选状态（[x]/[!]）按 (分类,id,版本) 键继承。
 * 用法：node tools/qa/generate-regression-matrix.js
 */
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..', '..');
const registryDir = path.join(root, 'src', 'registry', 'scripts');
const outPath = path.join(root, 'docs', 'qa', 'regression-matrix.md');

// 目标验证版本列。本机当前仅 2026；2020/2023 为代表性最小/中间版本，在可用机器上补测。
const VERSIONS = ['2026', '2023', '2020'];

const rows = [];
for (const file of fs.readdirSync(registryDir).filter((n) => n.endsWith('.ts'))) {
  const src = fs.readFileSync(path.join(registryDir, file), 'utf8');
  for (const obj of src.match(/\{[\s\S]*?\n\s*\}/g) || []) {
    const id = obj.match(/id:\s*['"]([^'"]+)['"]/);
    const name = obj.match(/name:\s*['"]([^'"]+)['"]/);
    const cat = obj.match(/category:\s*['"]([^'"]+)['"]/);
    if (id && cat) rows.push({ cat: cat[1], id: id[1], name: name ? name[1] : '' });
  }
}
rows.sort((a, b) => a.cat.localeCompare(b.cat) || a.id.localeCompare(b.id));

// 继承已有勾选
const prior = new Map();
if (fs.existsSync(outPath)) {
  const old = fs.readFileSync(outPath, 'utf8');
  for (const line of old.split('\n')) {
    const m = line.match(/^\| `([^`]+)` \|[^|]*\|(.*)\|$/);
    if (!m) continue;
    const cells = m[2].split('|').map((s) => s.trim());
    prior.set(m[1], cells);
  }
}

const extraFlows = [
  ['favorites-builtin', '收藏夹：收藏/取消内置功能并从收藏执行'],
  ['favorites-custom', '收藏夹：收藏自定义脚本并从收藏执行'],
  ['favorites-folders', '收藏夹：新建/重命名/删除/排序收藏夹'],
  ['custom-script-run', '自定义脚本：上传/文件夹脚本执行 (.jsx/.js/.jsxbin)'],
  ['recents', '最近使用：内置+自定义混合记录与执行'],
  ['panel-independent-open', '独立窗口：功能在 Modeless/Dialog 宿主中打开并执行'],
  ['settings-sync', '设置：多窗口间设置变更同步'],
  ['theme-sync', '主题：宿主亮/暗切换跟随'],
];

let md = `# 回归验证矩阵（自动生成骨架，人工勾选结果）

> 生成：\`node tools/qa/generate-regression-matrix.js\`（重跑不会丢失已勾选结果）。
> 标记：\`[ ]\` 未测；\`[x]\` 通过；\`[!]\` 失败（在下方"问题记录"登记）；\`[-]\` 不适用。
> 本机当前仅装 Illustrator 2026；2023/2020 列在可用环境补测。JSX 行为跨版本稳定，全版本 2020–2026 仅对 AIP 路由功能强制。

`;

let currentCat = '';
for (const r of rows) {
  if (r.cat !== currentCat) {
    currentCat = r.cat;
    md += `\n## ${currentCat}\n\n| 功能 ID | 名称 | ${VERSIONS.join(' | ')} |\n|---|---|${VERSIONS.map(() => '---').join('|')}|\n`;
  }
  const cells = prior.get(r.id) || VERSIONS.map(() => '[ ]');
  md += `| \`${r.id}\` | ${r.name} | ${VERSIONS.map((_, i) => cells[i] || '[ ]').join(' | ')} |\n`;
}

md += `\n## 跨功能流程\n\n| 流程 ID | 描述 | ${VERSIONS.join(' | ')} |\n|---|---|${VERSIONS.map(() => '---').join('|')}|\n`;
for (const [id, desc] of extraFlows) {
  const cells = prior.get(id) || VERSIONS.map(() => '[ ]');
  md += `| \`${id}\` | ${desc} | ${VERSIONS.map((_, i) => cells[i] || '[ ]').join(' | ')} |\n`;
}

md += `\n## 问题记录\n\n| 日期 | 功能 ID | 版本 | 现象 | 状态 |\n|---|---|---|---|---|\n`;

// 保留已有问题记录
if (fs.existsSync(outPath)) {
  const old = fs.readFileSync(outPath, 'utf8');
  const sec = old.split('## 问题记录')[1];
  if (sec) {
    const lines = sec.split('\n').filter((l) => /^\| \d{4}-/.test(l));
    md += lines.join('\n') + (lines.length ? '\n' : '');
  }
}

fs.mkdirSync(path.dirname(outPath), { recursive: true });
fs.writeFileSync(outPath, md);
console.log(`Wrote ${outPath}: ${rows.length} scripts x ${VERSIONS.length} versions + ${extraFlows.length} flows`);
