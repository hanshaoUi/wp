#!/usr/bin/env node
/**
 * 连接运行中的参考面板 CEP 面板（调试端口）提取 UI 度量。
 *
 * 前置：
 *  1. 参考面板的 CEP .debug 已配置调试端口（默认 8180）
 *  2. Illustrator 打开着参考面板面板（且已登录）
 *
 * 用法：node tools/qa/measure-reference-panel.js [port]   # 默认 8180（主面板）
 * 输出：JSON 度量报告（stdout），人工整理进 docs/design/panel-design-reference.md
 */
const path = require('path');
const { execSync } = require('child_process');

const port = process.argv[2] || '8180';

// 复用仓库依赖里没有 ws；用系统 node 的 fetch + 简易 ws 帧实现太复杂，
// 直接借助 puppeteer-core 的 CDP 连接能力（项目 devDependencies 已有）。
const puppeteer = require('puppeteer-core');

const MEASURE_SNIPPET = `(() => {
  const pick = (el, props) => {
    if (!el) return null;
    const cs = getComputedStyle(el);
    const out = {};
    props.forEach((p) => (out[p] = cs.getPropertyValue(p)));
    const r = el.getBoundingClientRect();
    out._rect = { x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height) };
    out._cls = String(el.className).slice(0, 60);
    return out;
  };
  const q = (sel) => document.querySelector(sel);
  const qa = (sel) => [...document.querySelectorAll(sel)];

  // 布局候选：最左窄条导航 / 主内容区
  const allDivs = qa('div').filter((d) => d.getBoundingClientRect().height > 300);
  const leftRail = allDivs
    .filter((d) => { const r = d.getBoundingClientRect(); return r.x < 8 && r.width > 16 && r.width < 80; })
    .sort((a, b) => a.getBoundingClientRect().width - b.getBoundingClientRect().width)[0];

  const railIcons = leftRail ? [...leftRail.querySelectorAll('svg, i, img, [class*=icon]')].slice(0, 4).map((el) => pick(el, ['width', 'height', 'color', 'font-size'])) : [];
  const railItems = leftRail ? [...leftRail.children].slice(0, 6).map((el) => pick(el, ['height', 'padding', 'margin', 'background-color'])) : [];

  const buttons = qa('button, [class*=btn]').slice(0, 12).map((b) => ({
    txt: (b.textContent || '').trim().slice(0, 12),
    s: pick(b, ['height', 'padding', 'font-size', 'background-color', 'color', 'border', 'border-radius']),
  }));
  const inputs = qa('input').slice(0, 6).map((i) => pick(i, ['height', 'padding', 'font-size', 'background-color', 'color', 'border', 'border-radius']));
  const sectionTitles = qa('div, span, h1, h2, h3, label')
    .filter((el) => { const cs = getComputedStyle(el); return (cs.borderLeftWidth !== '0px' && cs.borderLeftColor.includes('255, 125')) || cs.color === 'rgb(255, 125, 0)'; })
    .slice(0, 6)
    .map((el) => ({ txt: (el.textContent || '').trim().slice(0, 14), s: pick(el, ['font-size', 'font-weight', 'color', 'border-left', 'padding', 'margin']) }));

  return JSON.stringify({
    url: location.href.replace(/\\?t=\\d+/, ''),
    hash: location.hash,
    viewport: { w: innerWidth, h: innerHeight },
    body: pick(document.body, ['background-color', 'color', 'font-family', 'font-size']),
    leftRail: pick(leftRail, ['width', 'background-color', 'border-right', 'padding']),
    railItems, railIcons, buttons, inputs, sectionTitles,
  }, null, 1);
})()`;

(async () => {
  const browser = await puppeteer.connect({ browserURL: `http://localhost:${port}`, defaultViewport: null });
  try {
    const pages = await browser.pages();
    if (!pages.length) throw new Error('无可调试页面');
    const page = pages[0];
    const result = await page.evaluate((s) => eval(s), MEASURE_SNIPPET);
    console.log(result);
  } finally {
    browser.disconnect();
  }
})().catch((e) => {
  console.error(`连接失败（端口 ${port}）: ${e.message}`);
  console.error('请确认 Illustrator 正在运行且参考面板面板处于打开状态。');
  process.exit(1);
});
