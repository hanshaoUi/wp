#!/usr/bin/env node
/**
 * 浏览器 mock 模式冒烟测试（不需要 Illustrator）。
 *
 * 前置：dev server 已运行（npm run dev，端口 8080）。
 * 用法：node tools/qa/smoke-browser.js [--url http://127.0.0.1:8080]
 *
 * 检查项：
 *  1. 面板在纯浏览器（mock bridge）中渲染无页面错误
 *  2. 每个分类可点击进入，且该分类注册表中每个脚本的显示名都出现在页面上
 *  3. 全程无未捕获异常 / React ErrorBoundary 文案
 *
 * 使用系统 Chrome（puppeteer-core，无需下载浏览器）。
 */
const fs = require('fs');
const path = require('path');
const puppeteer = require('puppeteer-core');

const root = path.resolve(__dirname, '..', '..');
const URL_ARG = process.argv.indexOf('--url');
const BASE_URL = URL_ARG > -1 ? process.argv[URL_ARG + 1] : 'http://127.0.0.1:8080';

const CHROME_PATHS = [
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  '/Applications/Chromium.app/Contents/MacOS/Chromium',
  process.env.CHROME_PATH,
].filter(Boolean);

// 从注册表源码提取 分类id -> [脚本显示名]
function loadRegistry() {
  const registryDir = path.join(root, 'src', 'registry', 'scripts');
  const byCat = {};
  for (const file of fs.readdirSync(registryDir).filter((n) => n.endsWith('.ts'))) {
    const src = fs.readFileSync(path.join(registryDir, file), 'utf8');
    for (const obj of src.match(/\{[\s\S]*?\n\s*\}/g) || []) {
      const id = obj.match(/id:\s*['"]([^'"]+)['"]/);
      const name = obj.match(/name:\s*['"]([^'"]+)['"]/);
      const cat = obj.match(/category:\s*['"]([^'"]+)['"]/);
      if (id && cat && name) (byCat[cat[1]] = byCat[cat[1]] || []).push({ id: id[1], name: name[1] });
    }
  }
  return byCat;
}

// 分类 id -> 侧边栏显示名（与 src/registry/categories.ts 保持一致）
function loadCategoryNames() {
  const src = fs.readFileSync(path.join(root, 'src', 'registry', 'categories.ts'), 'utf8');
  const map = {};
  for (const m of src.matchAll(/id:\s*'([^']+)',\s*\n\s*name:\s*'([^']+)'/g)) map[m[1]] = m[2];
  return map;
}

async function main() {
  const chromePath = CHROME_PATHS.find((p) => fs.existsSync(p));
  if (!chromePath) throw new Error('未找到 Chrome，可设置 CHROME_PATH 环境变量');

  const registry = loadRegistry();
  const catNames = loadCategoryNames();
  const failures = [];
  const pageErrors = [];

  const browser = await puppeteer.launch({ executablePath: chromePath, headless: 'new' });
  try {
    const page = await browser.newPage();
    await page.setViewport({ width: 360, height: 800 });
    page.on('pageerror', (e) => pageErrors.push(String(e.message || e)));
    page.on('console', (msg) => {
      // 资源加载失败单独经 response 监听按同源过滤；外部请求（更新检查等）在 mock 模式失败属预期
      if (msg.type() === 'error' && !/browser-mock|net::|favicon|Failed to load resource/.test(msg.text())) {
        pageErrors.push('console.error: ' + msg.text());
      }
    });
    page.on('response', (res) => {
      if (res.status() >= 400 && res.url().startsWith(BASE_URL) && !/favicon/.test(res.url())) {
        pageErrors.push(`同源资源 ${res.status()}: ${res.url()}`);
      }
    });

    await page.goto(BASE_URL, { waitUntil: 'networkidle2', timeout: 30000 });
    await page.waitForFunction(() => {
      const r = document.getElementById('root');
      return r && r.children.length > 0;
    }, { timeout: 15000 });
    console.log('✓ 面板渲染成功 (mock 模式)');

    for (const [catId, scripts] of Object.entries(registry)) {
      const label = catNames[catId];
      if (!label) { failures.push(`分类 ${catId} 在 categories.ts 中无显示名`); continue; }

      const clicked = await page.evaluate((lbl) => {
        const btn = [...document.querySelectorAll('button')].find((b) => (b.textContent || '').trim().startsWith(lbl));
        if (btn) { btn.click(); return true; }
        return false;
      }, label);
      if (!clicked) { failures.push(`侧边栏找不到分类按钮: ${label} (${catId})`); continue; }

      await new Promise((r) => setTimeout(r, 400));

      const bodyText = await page.evaluate(() => document.body.innerText);
      // 快捷操作分类：6 个工具已合并进 4 张图标为主的紧凑卡（对齐·旋转/分布/镜像/对象），
      // 不再单独显示脚本名。
      const MERGED_IN_ALIGNMENT = new Set(['align-to-artboard', 'distribute-spacing', 'swap-objects', 'mirror-object', 'rotate-object', 'convert-to-outlines', 'lock-unlock']);
      if (catId === 'alignment') {
        for (const sec of ['对齐 · 旋转', '线性排列', '交换', '镜像', '对象']) {
          if (!bodyText.includes(sec)) failures.push(`分类 快捷操作: 缺少合并卡片「${sec}」`);
        }
      }
      const isMerged = (s) =>
        (catId === 'alignment' && MERGED_IN_ALIGNMENT.has(s.id));
      const missing = scripts.filter((s) => !bodyText.includes(s.name) && !isMerged(s));
      if (missing.length) {
        failures.push(`分类 ${label}: 缺少脚本卡片 ${missing.map((m) => m.id).join(', ')}`);
      } else {
        console.log(`✓ ${label} (${catId}): 全部渲染`);
      }
      if (/出现了一些问题|Something went wrong|ErrorBoundary/.test(bodyText)) {
        failures.push(`分类 ${label}: 页面出现错误边界文案`);
      }
    }

    // 特殊分类（无注册表脚本）也点一遍
    for (const special of ['最近使用', '收藏夹', '素材库', '脚本管理器', '设置']) {
      const clicked = await page.evaluate((lbl) => {
        const btn = [...document.querySelectorAll('button')].find((b) => (b.textContent || '').trim().startsWith(lbl));
        if (btn) { btn.click(); return true; }
        return false;
      }, special);
      await new Promise((r) => setTimeout(r, 300));
      if (!clicked) failures.push(`侧边栏找不到: ${special}`);
      else {
        const hasError = await page.evaluate(() => /出现了一些问题|Something went wrong/.test(document.body.innerText));
        if (hasError) failures.push(`${special}: 页面出现错误边界文案`);
        else console.log(`✓ ${special}: 打开正常`);
      }
    }

    // 多扩展根：每个扩展窗口（?ext=）都应无错渲染
    const EXT_ROOTS = ['artboard', 'object', 'favorites', 'scripts', 'dialog', 'modeless'];
    for (const ext of EXT_ROOTS) {
      await page.goto(`${BASE_URL}/?ext=${ext}`, { waitUntil: 'networkidle2', timeout: 30000 });
      try {
        await page.waitForFunction(() => {
          const r = document.getElementById('root');
          return r && r.children.length > 0;
        }, { timeout: 10000 });
        const bodyText = await page.evaluate(() => document.body.innerText);
        if (/出现了一些问题|Something went wrong/.test(bodyText)) {
          failures.push(`扩展根 ?ext=${ext}: 错误边界文案`);
        } else {
          console.log(`✓ 扩展根 ?ext=${ext}: 渲染正常`);
        }
      } catch (e) {
        failures.push(`扩展根 ?ext=${ext}: 渲染超时`);
      }
    }
  } finally {
    await browser.close();
  }

  if (pageErrors.length) {
    console.log('\n页面错误:');
    [...new Set(pageErrors)].slice(0, 10).forEach((e) => console.log('  ✗ ' + e));
  }
  if (failures.length || pageErrors.length) {
    console.log(`\n冒烟失败: ${failures.length} 项断言失败, ${pageErrors.length} 个页面错误`);
    failures.forEach((f) => console.log('  ✗ ' + f));
    process.exit(1);
  }
  console.log('\n冒烟全部通过 ✓');
}

main().catch((e) => { console.error(e); process.exit(1); });
