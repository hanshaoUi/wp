const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '../..');
const formNames = ['FillingerForm', 'RandomusForm', 'RichGlitchForm', 'ArcTwisterForm'];
const scriptNames = ['fillinger', 'randomus', 'rich-glitch', 'arc-twister'];
const failures = [];

for (const name of formNames) {
  const source = fs.readFileSync(path.join(root, 'src/panel/components/custom-forms', `${name}.tsx`), 'utf8');
  if (!source.includes('useDocumentPreview')) failures.push(`${name}: missing preview controller`);
  if (!source.includes('PreviewActionRow')) failures.push(`${name}: missing preview actions`);
  if (!source.includes('liveOnChange: true')) failures.push(`${name}: missing live refresh after preview starts`);
}

const richGlitchForm = fs.readFileSync(path.join(root, 'src/panel/components/custom-forms/RichGlitchForm.tsx'), 'utf8');
if ((richGlitchForm.match(/<SliderRow/g) || []).length !== 2) failures.push('RichGlitchForm: offset X and Y must use sliders');
if (!richGlitchForm.includes('label="偏移 X"') || !richGlitchForm.includes('label="偏移 Y"')) failures.push('RichGlitchForm: both offset sliders must remain labeled');
if ((richGlitchForm.match(/min=\{-100\}/g) || []).length !== 2 || (richGlitchForm.match(/max=\{100\}/g) || []).length !== 2) failures.push('RichGlitchForm: offset sliders must preserve the original -100..100 pt range');

const randomusForm = fs.readFileSync(path.join(root, 'src/panel/components/custom-forms/RandomusForm.tsx'), 'utf8');
if ((randomusForm.match(/<RandomSection title=/g) || []).length !== 4) failures.push('RandomusForm: four transform controls must use progressive-disclosure sections');
if (randomusForm.includes('sectionChips') || randomusForm.includes('<Chip')) failures.push('RandomusForm: repeated pill-button groups must be removed');
if (!randomusForm.includes('<Segment') || (randomusForm.match(/<ColorModeRow/g) || []).length !== 2) failures.push('RandomusForm: fill and stroke color modes must use two segmented controls');
if (!randomusForm.includes("label: '不变'") || !randomusForm.includes("label: '随机色'") || !randomusForm.includes("label: '色板'")) failures.push('RandomusForm: color modes must expose unchanged, random color, and swatch choices');
if (!randomusForm.includes('同一颜色应用到全部对象')) failures.push('RandomusForm: shared-color option must remain available with clearer wording');

const previewController = fs.readFileSync(path.join(root, 'src/panel/components/custom-forms/useDocumentPreview.ts'), 'utf8');
if (!previewController.includes('!activeRef.current')) failures.push('useDocumentPreview: must not run before preview is enabled');
if (!previewController.includes('clearOnly: true')) failures.push('useDocumentPreview: missing cancel cleanup');
if (!previewController.includes('clearPendingPreview')) failures.push('useDocumentPreview: missing pending debounce cancellation');
if (!previewController.includes('chainRef.current.then(async () =>')) failures.push('useDocumentPreview: missing queued unmount cleanup');

const scriptCard = fs.readFileSync(path.join(root, 'src/panel/components/ScriptCard.tsx'), 'utf8');
const transactionGuardCount = (scriptCard.match(/const checksCurrentSelection = overrideParams\.shouldUndo !== true && overrideParams\.clearOnly !== true;/g) || []).length;
if (transactionGuardCount !== 2) failures.push('Given a preview cleared selection, when refresh/cancel/apply runs, then both runners must bypass stale selection preflight');
const guardedSelectionCount = (scriptCard.match(/requirements\.includes\('selection'\) && checksCurrentSelection/g) || []).length;
if (guardedSelectionCount !== 2) failures.push('Given shouldUndo, when access is checked, then JSX cleanup must run before selection validation');

const runtimeUtils = fs.readFileSync(path.join(root, 'src/scripts/_runtime/utils.jsx'), 'utf8');
if (!runtimeUtils.includes('beginIsolatedPreview')) failures.push('Preview runtime: missing isolated preview creation');
if (!runtimeUtils.includes('clearIsolatedPreview')) failures.push('Preview runtime: missing ownership-based preview cleanup');
if (!runtimeUtils.includes('stateDocumentIsValid')) failures.push('Preview runtime: stale document references must be discarded safely');

for (const name of scriptNames) {
  const source = fs.readFileSync(path.join(root, 'src/scripts/effects', `${name}.jsx`), 'utf8');
  if (!source.includes('shouldUndo')) failures.push(`${name}.jsx: missing undo-before-preview`);
  if (!source.includes('clearOnly')) failures.push(`${name}.jsx: missing preview cleanup`);
  if (!source.includes('preview')) failures.push(`${name}.jsx: missing preview mode`);
  if (/catch \(undoError\) \{\}/.test(source)) failures.push(`${name}.jsx: silently ignores preview undo failure`);
  if (!source.includes('beginIsolatedPreview')) failures.push(`${name}.jsx: preview must run on owned duplicates`);
  if (!source.includes('clearIsolatedPreview')) failures.push(`${name}.jsx: preview cleanup must remove only owned content`);
}

const richGlitch = fs.readFileSync(path.join(root, 'src/scripts/effects/rich-glitch.jsx'), 'utf8');
if (!richGlitch.includes('objs[z].duplicate')) failures.push('RichGlitch: multi-level duplication must use the current object index');
if (!richGlitch.includes("direction: (__container.selection.index === 0 ? 'x' : 'y')")) failures.push('RichGlitch: horizontal and vertical localized labels must map by selection index');

const randomus = fs.readFileSync(path.join(root, 'src/scripts/effects/randomus.jsx'), 'utf8');
if (!randomus.includes('historyDocumentMatches')) failures.push('Randomus: stale history from a closed document must not throw Object is invalid');

if (failures.length) {
  process.stderr.write(`${failures.join('\n')}\n`);
  process.exit(1);
}

process.stdout.write('Effects preview contract passed for 4 tools.\n');
