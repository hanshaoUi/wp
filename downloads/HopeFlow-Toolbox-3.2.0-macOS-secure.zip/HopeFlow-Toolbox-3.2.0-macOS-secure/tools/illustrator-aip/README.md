# Illustrator Native AIP

This directory contains the Illustrator AIP assets for HopeFlow smart grouping.

```text
tools/illustrator-aip/
  HopeFlow.aip       Windows AIP binary used by Windows packages
  windows/YYYY/                Windows AIP binaries built per SDK year
  macos/YYYY/                  macOS AIP bundles built per SDK year
  macos/HopeFlow.aip Latest macOS AIP bundle built by the macOS script
  src/core/                    Shared smart-group algorithm (platform-agnostic)
  src/windows/                 Windows panel-event plugin glue
  src/macos/                   macOS panel-event plugin glue
  tests/                       Unit test for the shared algorithm core
  build-windows-aip.ps1        Windows build script
  build-macos-aip.sh           macOS build script
  sdk/                         Local Adobe Illustrator SDK vault, ignored by Git
```

This AIP runs entirely inside Illustrator. It receives smart-group
requests from the CEP panel, computes grouping relationships from current
selection or active-layer items, then creates real Illustrator groups through
SDK suites so the operation remains undoable.

## Supported versions

- The CEP panel manifest supports Illustrator `ILST [23.0,99.9]` with CSXS `9.0`.
- The native AIP binaries are platform-specific. Windows is validated locally; macOS is source-ready and must be compiled on macOS/Xcode.
- Versioned AIP binaries can be stored at `windows/YYYY/HopeFlow.aip` and `macos/YYYY/HopeFlow.aip`.
- Installers prefer the AIP matching the detected Illustrator year, then fall back to the root Windows AIP.
- The build scripts can auto-detect local Illustrator SDK folders for 2020-2026. Compatibility with newer Illustrator versions depends on Adobe's AIP ABI compatibility and must be verified before release.
- Installers scan common user Plug-ins / 增效工具 folders for Illustrator 2020-2026 and install the Windows AIP to every detected target.

Download the Illustrator SDK from Adobe:

```text
https://console.adobe.io/downloads/ai
```

Expected SDK layout:

```text
tools/illustrator-aip/sdk/AdobeIllustratorSDK/
```

Recommended layout when keeping multiple SDK versions:

```text
tools/illustrator-aip/sdk/mac_Adobe Illustrator 2026 SDK/
tools/illustrator-aip/sdk/mac_Adobe Illustrator 2025 SDK/
tools/illustrator-aip/sdk/mac_Adobe Illustrator 2024 SDK/
tools/illustrator-aip/sdk/mac_Adobe Illustrator 2023 SDK/
tools/illustrator-aip/sdk/mac_Adobe Illustrator 2022 SDK/
tools/illustrator-aip/sdk/mac_Adobe Illustrator 2021 SDK/
tools/illustrator-aip/sdk/mac_Adobe Illustrator 2020 SDK/
tools/illustrator-aip/sdk/win_Adobe Illustrator 2026 SDK/
tools/illustrator-aip/sdk/win_Adobe Illustrator 2025 SDK/
tools/illustrator-aip/sdk/win_Adobe Illustrator 2024 SDK/
tools/illustrator-aip/sdk/win_Adobe Illustrator 2023 SDK/
tools/illustrator-aip/sdk/win_Adobe Illustrator 2022 SDK/
tools/illustrator-aip/sdk/win_Adobe Illustrator 2021 SDK/
tools/illustrator-aip/sdk/win_Adobe Illustrator 2020 SDK/
```

The SDK files are proprietary and should stay local.

Build Windows AIP variants on Windows:

```powershell
npm run build:aip:windows:all
npm run package:windows:aip
```

Build macOS AIP variants on macOS:

```sh
npm run build:aip:macos:all
./install.sh --build-aip --all-aip
```

See `SMART_GROUP_AIP_IMPLEMENTATION.md` for the runtime architecture, safety
rules, and macOS porting notes.
