#include "data_merge_core.hpp"

#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>

using hopeflow::data_merge::DataMergeRequest;
using hopeflow::data_merge::JsonValue;
using hopeflow::data_merge::MappingType;
using hopeflow::data_merge::escapeJson;
using hopeflow::data_merge::generateFileName;
using hopeflow::data_merge::indexOfHeader;
using hopeflow::data_merge::parseDataMergeRequest;
using hopeflow::data_merge::parseJson;

namespace {

void require(bool condition, const char* message) {
  if (!condition) {
    std::cerr << message << '\n';
    std::exit(1);
  }
}

}  // namespace

int main() {
  // --- JSON parser basics ---
  {
    JsonValue root;
    std::string error;
    require(parseJson("{\"a\":1,\"b\":\"x\",\"c\":[1,2,3],\"d\":true}", root, error),
            "basic object should parse");
    require(root.get("a").asNumber() == 1.0, "number field");
    require(root.get("b").asString() == "x", "string field");
    require(root.get("c").arrayValue.size() == 3, "array length");
    require(root.get("d").asBool() == true, "bool field");
    require(root.get("missing").isNull(), "absent field is null");
  }

  // --- Unicode escape + nested structures (Chinese payload) ---
  {
    JsonValue root;
    std::string error;
    // "名字" as \u escapes, plus a raw UTF-8 value.
    require(parseJson("{\"headers\":[\"\\u540d\\u5b57\"],\"rowData\":[\"张三\"]}", root, error),
            "unicode payload should parse");
    require(root.get("headers").arrayValue[0].asString() == std::string("\xe5\x90\x8d\xe5\xad\x97"),
            "\\u escape decodes to UTF-8 名字");
    require(root.get("rowData").arrayValue[0].asString() == "张三", "raw UTF-8 preserved");
  }

  // --- Full request parse ---
  {
    const std::string payload =
        "{\"run\":true,\"mode\":\"exportSingle\","
        "\"headers\":[\"name\",\"pic\"],"
        "\"rowData\":[\"Alice\",\"/imgs/a.png\"],"
        "\"rowIndex\":4,"
        "\"mappings\":[{\"column\":\"name\",\"type\":\"TEXTUAL\",\"targetName\":\"nameField\",\"targetIndex\":0},"
        "{\"column\":\"pic\",\"type\":\"IMAGE\",\"targetName\":\"\",\"targetIndex\":2}],"
        "\"exportSettings\":{\"format\":\"pdf\",\"outputFolder\":\"/out\",\"fileNamePattern\":\"{#}-{name}\",\"dpi\":300},"
        "\"csvDir\":\"/csv\"}";
    DataMergeRequest request;
    std::string error;
    require(parseDataMergeRequest(payload, request, error), "full request should parse");
    require(request.run, "run flag");
    require(request.mode == "exportSingle", "mode");
    require(request.headers.size() == 2, "headers count");
    require(request.rowData.size() == 2, "row cells");
    require(request.rowIndex == 4, "row index");
    require(request.mappings.size() == 2, "mapping count");
    require(request.mappings[0].type == MappingType::Textual, "textual mapping type");
    require(request.mappings[1].type == MappingType::Image, "image mapping type");
    require(request.mappings[1].targetIndex == 2, "image target index");
    require(request.exportSettings.format == "PDF", "format upper-cased");
    require(request.exportSettings.outputFolder == "/out", "output folder");
    require(request.exportSettings.dpi == 300, "dpi");
  }

  // --- Missing output folder is rejected ---
  {
    DataMergeRequest request;
    std::string error;
    require(!parseDataMergeRequest("{\"exportSettings\":{\"format\":\"PDF\"}}", request, error),
            "missing output folder should fail");
    require(!error.empty(), "error message present");
  }

  // --- Filename generation mirrors data-merge.jsx ---
  {
    std::vector<std::string> headers = {"name", "id"};
    std::vector<std::string> row = {"Bob/Ann", "007"};
    require(generateFileName("{#}", row, headers, 0) == "1", "{#} -> rowIndex+1");
    require(generateFileName("{#}-{id}", row, headers, 9) == "10-007", "header substitution");
    require(generateFileName("{name}", row, headers, 0) == "Bob_Ann", "illegal slash sanitized");
  }

  // --- indexOfHeader / escapeJson ---
  {
    std::vector<std::string> headers = {"a", "b", "c"};
    require(indexOfHeader(headers, "b") == 1, "indexOfHeader hit");
    require(indexOfHeader(headers, "z") == -1, "indexOfHeader miss");
    require(escapeJson("a\"b\\c\n") == "a\\\"b\\\\c\\n", "escapeJson");
  }

  std::cout << "data_merge_core_test passed\n";
  return 0;
}
