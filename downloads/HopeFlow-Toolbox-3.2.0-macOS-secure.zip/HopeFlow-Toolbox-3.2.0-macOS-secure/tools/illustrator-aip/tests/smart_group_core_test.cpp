#include "smart_group_core.hpp"

#include <cstdlib>
#include <iostream>
#include <vector>

using hopeflow::smart_group::Bounds;
using hopeflow::smart_group::Item;
using hopeflow::smart_group::Options;
using hopeflow::smart_group::boundsIntersect;
using hopeflow::smart_group::findIntersectingGroups;

namespace {

void require(bool condition, const char* message) {
  if (!condition) {
    std::cerr << message << '\n';
    std::exit(1);
  }
}

}  // namespace

int main() {
  require(boundsIntersect({0, 10, 10, 0}, {9, 12, 20, 2}, 0), "overlap should intersect");
  require(!boundsIntersect({0, 10, 10, 0}, {11, 12, 20, 2}, 0), "gap should not intersect");
  require(boundsIntersect({0, 10, 10, 0}, {11, 12, 20, 2}, 1), "tolerance should bridge gap");

  std::vector<Item> items = {
      {101, {0, 10, 10, 0}},
      {102, {9, 12, 20, 2}},
      {103, {100, 110, 120, 90}},
      {104, {119, 111, 130, 95}},
      {105, {300, 310, 320, 290}},
  };

  Options options;
  auto result = findIntersectingGroups(items, options);

  require(result.groups.size() == 2, "expected two intersecting groups");
  require(result.groups[0].size() == 2, "first group should contain two items");
  require(result.groups[1].size() == 2, "second group should contain two items");
  require(result.stats.comparisons > 0, "expected at least one comparison");

  Options batch;
  batch.executionMode = "batch";
  batch.maxGroups = 1;
  auto batchResult = findIntersectingGroups(items, batch);
  require(batchResult.groups.size() == 1, "batch should limit group count");

  return 0;
}

