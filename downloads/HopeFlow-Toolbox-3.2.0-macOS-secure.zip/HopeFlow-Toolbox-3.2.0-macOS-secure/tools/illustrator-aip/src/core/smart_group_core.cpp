#include "smart_group_core.hpp"

#include <algorithm>
#include <numeric>

namespace hopeflow {
namespace smart_group {
namespace {

struct Meta {
  std::size_t index = 0;
  std::size_t id = 0;
  Bounds bounds;
  Bounds scanBounds;
};

class UnionFind {
 public:
  explicit UnionFind(std::size_t size) : parent_(size), rank_(size, 0) {
    std::iota(parent_.begin(), parent_.end(), 0);
  }

  std::size_t find(std::size_t value) {
    if (parent_[value] != value) {
      parent_[value] = find(parent_[value]);
    }
    return parent_[value];
  }

  void unite(std::size_t a, std::size_t b) {
    std::size_t rootA = find(a);
    std::size_t rootB = find(b);
    if (rootA == rootB) {
      return;
    }
    if (rank_[rootA] < rank_[rootB]) {
      parent_[rootA] = rootB;
    } else if (rank_[rootA] > rank_[rootB]) {
      parent_[rootB] = rootA;
    } else {
      parent_[rootB] = rootA;
      ++rank_[rootA];
    }
  }

 private:
  std::vector<std::size_t> parent_;
  std::vector<std::size_t> rank_;
};

Bounds expandedBounds(const Bounds& bounds, double tolerance) {
  return Bounds{
      bounds.left - tolerance,
      bounds.top + tolerance,
      bounds.right + tolerance,
      bounds.bottom - tolerance,
  };
}

bool overlapY(const Bounds& a, const Bounds& b) {
  return !(a.bottom > b.top || b.bottom > a.top);
}

}  // namespace

bool boundsIntersect(const Bounds& a, const Bounds& b, double tolerance) {
  return !(a.right + tolerance < b.left ||
           b.right + tolerance < a.left ||
           a.bottom - tolerance > b.top ||
           b.bottom - tolerance > a.top);
}

Result findIntersectingGroups(const std::vector<Item>& items, const Options& options) {
  Result result;
  if (items.size() < 2) {
    return result;
  }

  std::vector<Meta> metas;
  metas.reserve(items.size());
  for (std::size_t i = 0; i < items.size(); ++i) {
    metas.push_back(Meta{
        i,
        items[i].id,
        items[i].bounds,
        expandedBounds(items[i].bounds, options.tolerance),
    });
  }

  std::sort(metas.begin(), metas.end(), [](const Meta& a, const Meta& b) {
    return a.scanBounds.left < b.scanBounds.left;
  });

  UnionFind uf(items.size());
  std::vector<Meta> active;

  for (const Meta& meta : metas) {
    std::vector<Meta> nextActive;
    nextActive.reserve(active.size() + 1);

    for (const Meta& other : active) {
      if (other.scanBounds.right < meta.scanBounds.left) {
        continue;
      }
      nextActive.push_back(other);

      if (overlapY(meta.scanBounds, other.scanBounds)) {
        ++result.stats.comparisons;
        if (boundsIntersect(meta.bounds, other.bounds, options.tolerance)) {
          uf.unite(meta.index, other.index);
        }
      }
    }

    nextActive.push_back(meta);
    active.swap(nextActive);
  }

  std::vector<std::vector<std::size_t>> grouped(items.size());
  for (std::size_t i = 0; i < items.size(); ++i) {
    grouped[uf.find(i)].push_back(items[i].id);
  }

  for (auto& group : grouped) {
    if (group.size() > 1) {
      result.groups.push_back(group);
    }
  }

  std::sort(result.groups.begin(), result.groups.end(), [](const auto& a, const auto& b) {
    return a.size() > b.size();
  });

  if (options.executionMode == "batch" && result.groups.size() > options.maxGroups) {
    result.groups.resize(options.maxGroups);
  }

  return result;
}

}  // namespace smart_group
}  // namespace hopeflow

