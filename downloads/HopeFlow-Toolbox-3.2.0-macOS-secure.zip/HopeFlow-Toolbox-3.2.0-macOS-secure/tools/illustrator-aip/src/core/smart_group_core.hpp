#pragma once

#include <cstddef>
#include <string>
#include <vector>

namespace hopeflow {
namespace smart_group {

struct Bounds {
  double left = 0.0;
  double top = 0.0;
  double right = 0.0;
  double bottom = 0.0;
};

struct Item {
  std::size_t id = 0;
  Bounds bounds;
};

struct Options {
  double tolerance = 0.0;
  std::string executionMode = "create";
  std::size_t maxGroups = 100;
};

struct Stats {
  std::size_t comparisons = 0;
};

struct Result {
  std::vector<std::vector<std::size_t>> groups;
  Stats stats;
};

bool boundsIntersect(const Bounds& a, const Bounds& b, double tolerance);
Result findIntersectingGroups(const std::vector<Item>& items, const Options& options);

}  // namespace smart_group
}  // namespace hopeflow

