#include "data_merge_core.hpp"

#include <cctype>
#include <cstdio>
#include <sstream>

namespace hopeflow {
namespace data_merge {

namespace {

const JsonValue kNullValue;

// ---- JSON parser ---------------------------------------------------------

struct Parser {
  const std::string& text;
  std::size_t pos = 0;
  std::string error;

  explicit Parser(const std::string& t) : text(t) {}

  bool fail(const std::string& message) {
    if (error.empty()) error = message;
    return false;
  }

  void skipWhitespace() {
    while (pos < text.size()) {
      const char ch = text[pos];
      if (ch == ' ' || ch == '\t' || ch == '\n' || ch == '\r') {
        ++pos;
      } else {
        break;
      }
    }
  }

  bool parseValue(JsonValue& out) {
    skipWhitespace();
    if (pos >= text.size()) return fail("Unexpected end of JSON.");
    const char ch = text[pos];
    switch (ch) {
      case '{': return parseObject(out);
      case '[': return parseArray(out);
      case '"': return parseString(out);
      case 't':
      case 'f': return parseBool(out);
      case 'n': return parseNull(out);
      default:
        if (ch == '-' || (ch >= '0' && ch <= '9')) return parseNumber(out);
        return fail("Unexpected character in JSON.");
    }
  }

  bool parseObject(JsonValue& out) {
    out.type = JsonType::Object;
    ++pos;  // consume '{'
    skipWhitespace();
    if (pos < text.size() && text[pos] == '}') {
      ++pos;
      return true;
    }
    while (true) {
      skipWhitespace();
      if (pos >= text.size() || text[pos] != '"') return fail("Expected object key.");
      JsonValue key;
      if (!parseString(key)) return false;
      skipWhitespace();
      if (pos >= text.size() || text[pos] != ':') return fail("Expected ':' in object.");
      ++pos;
      JsonValue value;
      if (!parseValue(value)) return false;
      out.objectValue[key.stringValue] = value;
      skipWhitespace();
      if (pos >= text.size()) return fail("Unterminated object.");
      if (text[pos] == ',') {
        ++pos;
        continue;
      }
      if (text[pos] == '}') {
        ++pos;
        return true;
      }
      return fail("Expected ',' or '}' in object.");
    }
  }

  bool parseArray(JsonValue& out) {
    out.type = JsonType::Array;
    ++pos;  // consume '['
    skipWhitespace();
    if (pos < text.size() && text[pos] == ']') {
      ++pos;
      return true;
    }
    while (true) {
      JsonValue value;
      if (!parseValue(value)) return false;
      out.arrayValue.push_back(value);
      skipWhitespace();
      if (pos >= text.size()) return fail("Unterminated array.");
      if (text[pos] == ',') {
        ++pos;
        continue;
      }
      if (text[pos] == ']') {
        ++pos;
        return true;
      }
      return fail("Expected ',' or ']' in array.");
    }
  }

  bool parseString(JsonValue& out) {
    out.type = JsonType::String;
    ++pos;  // consume opening quote
    std::string value;
    while (pos < text.size()) {
      const char ch = text[pos++];
      if (ch == '"') {
        out.stringValue = value;
        return true;
      }
      if (ch == '\\') {
        if (pos >= text.size()) return fail("Unterminated escape in string.");
        const char esc = text[pos++];
        switch (esc) {
          case '"': value += '"'; break;
          case '\\': value += '\\'; break;
          case '/': value += '/'; break;
          case 'b': value += '\b'; break;
          case 'f': value += '\f'; break;
          case 'n': value += '\n'; break;
          case 'r': value += '\r'; break;
          case 't': value += '\t'; break;
          case 'u': {
            if (pos + 4 > text.size()) return fail("Invalid \\u escape.");
            unsigned int code = 0;
            for (int i = 0; i < 4; ++i) {
              const char hex = text[pos++];
              code <<= 4;
              if (hex >= '0' && hex <= '9') code |= static_cast<unsigned int>(hex - '0');
              else if (hex >= 'a' && hex <= 'f') code |= static_cast<unsigned int>(hex - 'a' + 10);
              else if (hex >= 'A' && hex <= 'F') code |= static_cast<unsigned int>(hex - 'A' + 10);
              else return fail("Invalid \\u hex digit.");
            }
            // Encode the BMP code point as UTF-8. Surrogate pairs are passed
            // through as-is (rare in this payload; text values arrive UTF-8).
            appendUtf8(value, code);
            break;
          }
          default:
            return fail("Invalid escape in string.");
        }
        continue;
      }
      value += ch;
    }
    return fail("Unterminated string.");
  }

  static void appendUtf8(std::string& out, unsigned int code) {
    if (code < 0x80) {
      out += static_cast<char>(code);
    } else if (code < 0x800) {
      out += static_cast<char>(0xC0 | (code >> 6));
      out += static_cast<char>(0x80 | (code & 0x3F));
    } else {
      out += static_cast<char>(0xE0 | (code >> 12));
      out += static_cast<char>(0x80 | ((code >> 6) & 0x3F));
      out += static_cast<char>(0x80 | (code & 0x3F));
    }
  }

  bool parseNumber(JsonValue& out) {
    const std::size_t start = pos;
    if (pos < text.size() && text[pos] == '-') ++pos;
    while (pos < text.size()) {
      const char ch = text[pos];
      if ((ch >= '0' && ch <= '9') || ch == '.' || ch == 'e' || ch == 'E' || ch == '+' || ch == '-') {
        ++pos;
      } else {
        break;
      }
    }
    if (pos == start) return fail("Invalid number.");
    try {
      out.type = JsonType::Number;
      out.numberValue = std::stod(text.substr(start, pos - start));
    } catch (...) {
      return fail("Invalid number.");
    }
    return true;
  }

  bool parseBool(JsonValue& out) {
    if (text.compare(pos, 4, "true") == 0) {
      out.type = JsonType::Bool;
      out.boolValue = true;
      pos += 4;
      return true;
    }
    if (text.compare(pos, 5, "false") == 0) {
      out.type = JsonType::Bool;
      out.boolValue = false;
      pos += 5;
      return true;
    }
    return fail("Invalid literal.");
  }

  bool parseNull(JsonValue& out) {
    if (text.compare(pos, 4, "null") == 0) {
      out.type = JsonType::Null;
      pos += 4;
      return true;
    }
    return fail("Invalid literal.");
  }
};

std::string numberToString(double value) {
  // Values in this payload are small integers (indices, dpi, rowIndex). Render
  // whole numbers without a trailing ".000000".
  if (value == static_cast<double>(static_cast<long long>(value))) {
    return std::to_string(static_cast<long long>(value));
  }
  std::ostringstream stream;
  stream << value;
  return stream.str();
}

// Coerces a JSON scalar to its string form (numbers/bools become text). Mirrors
// ExtendScript's loose String() coercion of CSV cell values.
std::string coerceScalarToString(const JsonValue& value) {
  switch (value.type) {
    case JsonType::String: return value.stringValue;
    case JsonType::Number: return numberToString(value.numberValue);
    case JsonType::Bool: return value.boolValue ? "true" : "false";
    default: return "";
  }
}

void replaceAll(std::string& subject, const std::string& from, const std::string& to) {
  if (from.empty()) return;
  std::size_t pos = 0;
  while ((pos = subject.find(from, pos)) != std::string::npos) {
    subject.replace(pos, from.size(), to);
    pos += to.size();
  }
}

}  // namespace

// ---- JsonValue accessors -------------------------------------------------

const JsonValue& JsonValue::get(const std::string& key) const {
  if (type != JsonType::Object) return kNullValue;
  auto it = objectValue.find(key);
  return it == objectValue.end() ? kNullValue : it->second;
}

bool JsonValue::has(const std::string& key) const {
  return type == JsonType::Object && objectValue.find(key) != objectValue.end();
}

std::string JsonValue::asString(const std::string& fallback) const {
  if (type == JsonType::String) return stringValue;
  if (type == JsonType::Number) return numberToString(numberValue);
  if (type == JsonType::Bool) return boolValue ? "true" : "false";
  return fallback;
}

double JsonValue::asNumber(double fallback) const {
  if (type == JsonType::Number) return numberValue;
  if (type == JsonType::String) {
    try {
      return std::stod(stringValue);
    } catch (...) {
      return fallback;
    }
  }
  return fallback;
}

bool JsonValue::asBool(bool fallback) const {
  if (type == JsonType::Bool) return boolValue;
  if (type == JsonType::String) return stringValue == "true" || stringValue == "1";
  if (type == JsonType::Number) return numberValue != 0.0;
  return fallback;
}

bool parseJson(const std::string& text, JsonValue& out, std::string& error) {
  Parser parser(text);
  if (!parser.parseValue(out)) {
    error = parser.error.empty() ? "Malformed JSON." : parser.error;
    return false;
  }
  return true;
}

// ---- Request model -------------------------------------------------------

MappingType mappingTypeFromString(const std::string& value) {
  if (value == "TEXTUAL") return MappingType::Textual;
  if (value == "IMAGE") return MappingType::Image;
  if (value == "VISIBILITY") return MappingType::Visibility;
  return MappingType::Unmapped;
}

bool parseDataMergeRequest(const std::string& payload, DataMergeRequest& out, std::string& error) {
  JsonValue root;
  if (!parseJson(payload, root, error)) return false;
  if (root.type != JsonType::Object) {
    error = "Request payload is not a JSON object.";
    return false;
  }

  out.run = root.get("run").asBool(true);
  out.mode = root.get("mode").asString("exportSingle");
  out.rowIndex = static_cast<int>(root.get("rowIndex").asNumber(0.0));
  out.startIndex = static_cast<int>(root.get("startIndex").asNumber(0.0));
  out.csvDir = root.get("csvDir").asString("");

  const JsonValue& headers = root.get("headers");
  if (headers.type == JsonType::Array) {
    for (const auto& header : headers.arrayValue) {
      out.headers.push_back(header.asString(""));
    }
  }

  const JsonValue& rowData = root.get("rowData");
  if (rowData.type == JsonType::Array) {
    for (const auto& cell : rowData.arrayValue) {
      out.rowData.push_back(coerceScalarToString(cell));
    }
  }

  // exportBatch: csvData is an array of rows (each an array of cell values).
  const JsonValue& csvData = root.get("csvData");
  if (csvData.type == JsonType::Array) {
    for (const auto& rowValue : csvData.arrayValue) {
      std::vector<std::string> row;
      if (rowValue.type == JsonType::Array) {
        for (const auto& cell : rowValue.arrayValue) {
          row.push_back(coerceScalarToString(cell));
        }
      }
      out.rows.push_back(row);
    }
  }

  const JsonValue& mappings = root.get("mappings");
  if (mappings.type == JsonType::Array) {
    for (const auto& entry : mappings.arrayValue) {
      Mapping mapping;
      mapping.column = entry.get("column").asString("");
      mapping.type = mappingTypeFromString(entry.get("type").asString(""));
      mapping.targetName = entry.get("targetName").asString("");
      mapping.targetIndex = static_cast<int>(entry.get("targetIndex").asNumber(-1.0));
      out.mappings.push_back(mapping);
    }
  }

  const JsonValue& settings = root.get("exportSettings");
  if (settings.type == JsonType::Object) {
    std::string format = settings.get("format").asString("PDF");
    for (auto& ch : format) ch = static_cast<char>(std::toupper(static_cast<unsigned char>(ch)));
    out.exportSettings.format = format;
    out.exportSettings.outputFolder = settings.get("outputFolder").asString("");
    out.exportSettings.fileNamePattern = settings.get("fileNamePattern").asString("{#}");
    out.exportSettings.dpi = static_cast<int>(settings.get("dpi").asNumber(300.0));
  } else {
    error = "Request is missing exportSettings.";
    return false;
  }

  if (out.exportSettings.outputFolder.empty()) {
    error = "Request is missing an output folder.";
    return false;
  }

  return true;
}

// ---- Helpers -------------------------------------------------------------

int indexOfHeader(const std::vector<std::string>& headers, const std::string& column) {
  for (std::size_t i = 0; i < headers.size(); ++i) {
    if (headers[i] == column) return static_cast<int>(i);
  }
  return -1;
}

std::string sanitizeFileName(const std::string& value) {
  std::string result = value;
  for (auto& ch : result) {
    switch (ch) {
      case ':':
      case '/':
      case '\\':
      case '*':
      case '?':
      case '"':
      case '>':
      case '<':
      case '|':
        ch = '_';
        break;
      default:
        break;
    }
  }
  return result;
}

std::string generateFileName(const std::string& pattern,
                             const std::vector<std::string>& rowData,
                             const std::vector<std::string>& headers,
                             int rowIndex) {
  std::string result = pattern;
  replaceAll(result, "{#}", std::to_string(rowIndex + 1));
  for (std::size_t i = 0; i < headers.size(); ++i) {
    const std::string placeholder = "{" + headers[i] + "}";
    const std::string value = i < rowData.size() ? rowData[i] : "";
    replaceAll(result, placeholder, value);
  }
  return sanitizeFileName(result);
}

std::string escapeJson(const std::string& input) {
  std::string output;
  output.reserve(input.size() + 8);
  for (char ch : input) {
    switch (ch) {
      case '\\': output += "\\\\"; break;
      case '"': output += "\\\""; break;
      case '\r': output += "\\r"; break;
      case '\n': output += "\\n"; break;
      case '\t': output += "\\t"; break;
      default: output += ch; break;
    }
  }
  return output;
}

}  // namespace data_merge
}  // namespace hopeflow
