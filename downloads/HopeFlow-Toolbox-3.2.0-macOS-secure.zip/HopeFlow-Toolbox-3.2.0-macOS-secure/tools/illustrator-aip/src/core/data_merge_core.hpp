#pragma once

// SDK-agnostic core for the HopeFlow data-merge AIP.
// Holds JSON parsing of the panel request, mapping/export-setting models,
// filename generation and JSON escaping. No Illustrator SDK dependency, so it
// is unit-testable on its own (see tests/data_merge_core_test.cpp).

#include <cstddef>
#include <map>
#include <memory>
#include <string>
#include <vector>

namespace hopeflow {
namespace data_merge {

// ---------------------------------------------------------------------------
// Minimal JSON value + parser
// ---------------------------------------------------------------------------

enum class JsonType { Null, Bool, Number, String, Array, Object };

struct JsonValue {
  JsonType type = JsonType::Null;
  bool boolValue = false;
  double numberValue = 0.0;
  std::string stringValue;
  std::vector<JsonValue> arrayValue;
  std::map<std::string, JsonValue> objectValue;

  bool isNull() const { return type == JsonType::Null; }

  // Object member access (returns a Null value when absent / not an object).
  const JsonValue& get(const std::string& key) const;
  bool has(const std::string& key) const;

  std::string asString(const std::string& fallback = "") const;
  double asNumber(double fallback = 0.0) const;
  bool asBool(bool fallback = false) const;
};

// Parses a JSON document. On failure returns false and leaves an English
// message in error.
bool parseJson(const std::string& text, JsonValue& out, std::string& error);

// ---------------------------------------------------------------------------
// Data-merge request model
// ---------------------------------------------------------------------------

enum class MappingType { Textual, Image, Visibility, Unmapped };

MappingType mappingTypeFromString(const std::string& value);

struct Mapping {
  std::string column;
  MappingType type = MappingType::Unmapped;
  std::string targetName;
  int targetIndex = -1;
};

struct ExportSettings {
  std::string format = "PDF";   // PDF | PNG | JPG
  std::string outputFolder;
  std::string fileNamePattern = "{#}";
  int dpi = 300;
};

struct DataMergeRequest {
  bool run = true;
  std::string mode = "exportSingle";
  std::vector<Mapping> mappings;
  std::vector<std::string> headers;
  std::vector<std::string> rowData;                 // exportSingle: one row
  std::vector<std::vector<std::string>> rows;        // exportBatch: many rows (csvData)
  int rowIndex = 0;                                  // exportSingle: this row's index
  int startIndex = 0;                                // exportBatch: index of rows[0]
  ExportSettings exportSettings;
  std::string csvDir;
};

// Parses the panel payload into a request. Returns false + error on malformed
// input or missing required fields.
bool parseDataMergeRequest(const std::string& payload, DataMergeRequest& out, std::string& error);

// ---------------------------------------------------------------------------
// Helpers (mirror data-merge.jsx behaviour)
// ---------------------------------------------------------------------------

// Index of column in headers, or -1.
int indexOfHeader(const std::vector<std::string>& headers, const std::string& column);

// Mirrors data-merge.jsx generateFileName: {#} -> rowIndex+1, {header} -> value,
// then illegal filename characters replaced with '_'.
std::string generateFileName(const std::string& pattern,
                             const std::vector<std::string>& rowData,
                             const std::vector<std::string>& headers,
                             int rowIndex);

// Replaces characters illegal in filenames with '_'.
std::string sanitizeFileName(const std::string& value);

std::string escapeJson(const std::string& input);

}  // namespace data_merge
}  // namespace hopeflow
