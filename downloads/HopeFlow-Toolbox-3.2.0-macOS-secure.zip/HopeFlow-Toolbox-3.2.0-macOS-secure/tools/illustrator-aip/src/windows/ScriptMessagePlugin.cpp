#include "IllustratorSDK.h"
#include "ScriptMessagePlugin.h"

#include "AICSXS.h"
#include "AIScriptMessage.h"
#include "SmartGroupRunner.h"
#include "DataMergeRunner.h"

#include <fstream>
#include <cstring>
#include <string>

namespace {

void WriteStartupLog(const char* message) {
	char tempPath[MAX_PATH] = {0};
	std::string logPath = "C:\\hopeflow-smart-group-aip.log";
	const DWORD length = GetTempPathA(MAX_PATH, tempPath);
	if (length > 0 && length < MAX_PATH) {
		logPath = std::string(tempPath) + "hopeflow-smart-group-aip.log";
	}
	std::ofstream stream(logPath.c_str(), std::ios::out | std::ios::app);
	if (!stream.is_open()) return;
	stream << message << "\n";
}

}

Plugin* AllocatePlugin(SPPluginRef pluginRef) {
	return new ScriptMessagePlugin(pluginRef);
}

void FixupReload(Plugin* plugin) {
	ScriptMessagePlugin::FixupVTable((ScriptMessagePlugin*)plugin);
}

ScriptMessagePlugin::ScriptMessagePlugin(SPPluginRef pluginRef)
	: Plugin(pluginRef),
	  fPlugPlugSetupCompleteNotifier(nullptr),
	  fPanelController(nullptr) {
	strncpy(fPluginName, kScriptMessagePluginName, kMaxStringLength);
}

ASErr ScriptMessagePlugin::StartupPlugin(SPInterfaceMessage* message) {
	ASErr error = Plugin::StartupPlugin(message);
	if (error) return error;
	WriteStartupLog("StartupPlugin: entered");
	if (fPanelController == nullptr) {
		fPanelController = new ScriptMessagePanelController(fPluginRef);
		WriteStartupLog("StartupPlugin: panel controller created");
		error = Plugin::LockPlugin(true);
		if (error) return error;
	}

	if (fPanelController != nullptr) {
		fPanelController->RegisterCSXSEventListeners();
		WriteStartupLog("StartupPlugin: attempted direct RegisterCSXSEventListeners");
	}

	error = sAINotifier->AddNotifier(
		fPluginRef,
		kScriptMessagePluginName,
		kAICSXSPlugPlugSetupCompleteNotifier,
		&fPlugPlugSetupCompleteNotifier
	);
	WriteStartupLog(error ? "StartupPlugin: AddNotifier failed" : "StartupPlugin: AddNotifier succeeded");
	return error;
}

ASErr ScriptMessagePlugin::ShutdownPlugin(SPInterfaceMessage* message) {
	if (fPanelController != nullptr) {
		fPanelController->RemoveEventListeners();
		delete fPanelController;
		fPanelController = nullptr;
		Plugin::LockPlugin(false);
	}
	return Plugin::ShutdownPlugin(message);
}

ASErr ScriptMessagePlugin::Notify(AINotifierMessage* message) {
	if (message && message->notifier == fPlugPlugSetupCompleteNotifier && fPanelController != nullptr) {
		WriteStartupLog("Notify: kAICSXSPlugPlugSetupCompleteNotifier");
		fPanelController->RegisterCSXSEventListeners();
	}
	return kNoErr;
}

ASErr ScriptMessagePlugin::Message(char* caller, char* selector, void* message) {
	if (std::strcmp(caller, kCallerAIScriptMessage) != 0) {
		return Plugin::Message(caller, selector, message);
	}

	AIScriptMessage* scriptMessage = static_cast<AIScriptMessage*>(message);
	if (!scriptMessage) return kBadParameterErr;

	const std::string payload = scriptMessage->inParam.as_Platform();

	if (std::strcmp(selector, kHopeFlowSmartGroupSelectorRun) == 0) {
		scriptMessage->outParam = ai::UnicodeString(ExecuteSmartGroupRequestJson(payload).c_str());
		return kNoErr;
	}

	if (std::strcmp(selector, kHopeFlowDataMergeSelectorRun) == 0) {
		scriptMessage->outParam = ai::UnicodeString(ExecuteDataMergeRequestJson(payload).c_str());
		return kNoErr;
	}

	if (std::strcmp(selector, kHopeFlowReadRotationsSelectorRun) == 0) {
		scriptMessage->outParam = ai::UnicodeString(ExecuteReadTextRotationsJson(payload).c_str());
		return kNoErr;
	}

	scriptMessage->outParam = ai::UnicodeString(
		"{\"success\":false,\"message\":\"Unsupported selector.\",\"usedAip\":true}"
	);
	return kNoErr;
}
