#ifndef __ScriptMessageSuites_H__
#define __ScriptMessageSuites_H__

#include "IllustratorSDK.h"
#include "Suites.hpp"
#include "AIMatchingArt.h"
#include "AIMdMemory.h"
#include "AILayer.h"
#include "AIMenu.h"
#include "AIUndo.h"
#include "AIDocument.h"
#include "AITextFrame.h"
#include "AIPlaced.h"
#include "AITransformArt.h"

// ATE (Adobe Text Engine) — needed for editing text-frame contents.
#include "ATESuites.h"
#include "ATETypes.h"
#include "IText.h"
#include "ATETextSuitesImportHelper.h"

extern "C" SPBlocksSuite* sSPBlocks;
extern "C" AIUnicodeStringSuite* sAIUnicodeString;
extern "C" AIArtSuite* sAIArt;
extern "C" AIMatchingArtSuite* sAIMatchingArt;
extern "C" AIMdMemorySuite* sAIMdMemory;
extern "C" AILayerSuite* sAILayer;
extern "C" AIMenuSuite* sAIMenu;
extern "C" AIUndoSuite* sAIUndo;
extern "C" AIDocumentSuite* sAIDocument;
extern "C" AITextFrameSuite* sAITextFrame;
extern "C" AIPlacedSuite* sAIPlaced;
extern "C" AITransformArtSuite* sAITransformArt;

#endif
