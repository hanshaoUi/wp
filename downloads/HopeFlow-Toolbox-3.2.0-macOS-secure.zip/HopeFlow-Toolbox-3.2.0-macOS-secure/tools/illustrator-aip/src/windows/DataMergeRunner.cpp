#include "IllustratorSDK.h"
#include "DataMergeRunner.h"

#include "ScriptMessageID.h"
#include "ScriptMessageSuites.h"

#include "data_merge_core.hpp"
#include "data_merge_core.cpp"  // unity build of the SDK-agnostic core

#include "AITextFrame.h"
#include "AIPlaced.h"
#include "AITransformArt.h"
#include "IText.h"  // ATE ITextRange

#include <chrono>
#include <cmath>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>

using hopeflow::data_merge::DataMergeRequest;
using hopeflow::data_merge::Mapping;
using hopeflow::data_merge::MappingType;
using hopeflow::data_merge::escapeJson;
using hopeflow::data_merge::generateFileName;
using hopeflow::data_merge::indexOfHeader;
using hopeflow::data_merge::parseDataMergeRequest;

namespace {

const char* kPdfFormatName = "PDF File Format";  // == kAIPDFFileFormat

// Diagnostic log — mirrors the smart-group AIP log so the panel can point users
// at a file when something goes wrong on the real machine.
std::string LogPath() {
	const char* tempDir = std::getenv("TMPDIR");
	if (tempDir && tempDir[0] != '\0') {
		std::string path(tempDir);
		if (path.back() != '/') path += '/';
		return path + "hopeflow-datamerge-aip.log";
	}
	return "/tmp/hopeflow-datamerge-aip.log";
}

void Log(const std::string& message) {
	std::ofstream stream(LogPath().c_str(), std::ios::out | std::ios::app);
	if (stream.is_open()) stream << message << "\n";
}

long long NowMs() {
	using namespace std::chrono;
	return duration_cast<milliseconds>(steady_clock::now().time_since_epoch()).count();
}

ai::UnicodeString Utf8(const std::string& value) {
	return ai::UnicodeString(value, kAIUTF8CharacterEncoding);
}

std::string LowerAscii(const std::string& value) {
	std::string result = value;
	for (auto& ch : result) {
		if (ch >= 'A' && ch <= 'Z') ch = static_cast<char>(ch - 'A' + 'a');
	}
	return result;
}

bool FileExists(const std::string& path) {
	if (path.empty()) return false;
	std::ifstream stream(path.c_str());
	return stream.good();
}

// Resolves an image path, falling back to csvDir when the raw path is relative
// and missing (mirrors data-merge.jsx applyRowDataToDocument IMAGE branch).
std::string ResolveImagePath(const std::string& raw, const std::string& csvDir) {
	if (FileExists(raw)) return raw;
	if (!csvDir.empty()) {
		std::string joined = csvDir;
		if (!joined.empty() && joined.back() != '/' && joined.back() != '\\') joined += '/';
		joined += raw;
		if (FileExists(joined)) return joined;
	}
	return "";
}

// Collects every art object of the given type in the current document, in the
// order returned by the matching-art suite.
std::vector<AIArtHandle> CollectArtOfType(ai::int32 artType) {
	std::vector<AIArtHandle> result;
	if (!sAIMatchingArt || !sAIMdMemory) return result;

	AIMatchingArtSpec spec[1] = {AIMatchingArtSpec(artType, 0, 0)};
	AIArtHandle** matches = nullptr;
	ai::int32 count = 0;
	AIErr error = sAIMatchingArt->GetMatchingArt(spec, 1, &matches, &count);
	if (error || !matches) {
		if (matches) sAIMdMemory->MdMemoryDisposeHandle((AIMdMemoryHandle)matches);
		return result;
	}
	result.reserve(static_cast<std::size_t>(count));
	for (ai::int32 i = 0; i < count; ++i) result.push_back((*matches)[i]);
	sAIMdMemory->MdMemoryDisposeHandle((AIMdMemoryHandle)matches);
	return result;
}

// Returns the user-assigned name of an art object, or "" when it has only a
// default (auto) name.
std::string ArtNameUtf8(AIArtHandle art) {
	if (!sAIArt) return "";
	ai::UnicodeString name;
	ASBoolean isDefaultName = false;
	if (sAIArt->GetArtName(art, name, &isDefaultName)) return "";
	if (isDefaultName) return "";
	return name.as_UTF8();
}

// Finds a target art object: prefer name match, fall back to positional index
// within the type collection (index is fragile — see impl notes; P1 relies on
// named targets).
AIArtHandle FindTarget(ai::int32 artType, const std::string& targetName, int targetIndex) {
	std::vector<AIArtHandle> arts = CollectArtOfType(artType);
	if (!targetName.empty()) {
		for (AIArtHandle art : arts) {
			if (ArtNameUtf8(art) == targetName) return art;
		}
	}
	if (targetIndex >= 0 && static_cast<std::size_t>(targetIndex) < arts.size()) {
		return arts[static_cast<std::size_t>(targetIndex)];
	}
	return nullptr;
}

// Finds any named page item by name (VISIBILITY targets).
AIArtHandle FindNamedItem(const std::string& name) {
	if (name.empty()) return nullptr;
	std::vector<AIArtHandle> arts = CollectArtOfType(kAnyArt);
	for (AIArtHandle art : arts) {
		if (ArtNameUtf8(art) == name) return art;
	}
	return nullptr;
}

bool SetTextContents(AIArtHandle art, const std::string& utf8) {
	if (!sAITextFrame) return false;
	TextRangeRef rangeRef = nullptr;
	if (sAITextFrame->GetATETextRange(art, &rangeRef) || !rangeRef) return false;
	try {
		ATE::ITextRange range(rangeRef);
		range.Remove();
		range.InsertAfter(Utf8(utf8).as_ASUnicode().c_str());
	} catch (ATE::Exception&) {
		return false;
	}
	return true;
}

// Relinks a placed image and rescales it so its bounds match the original
// placeholder (mirrors data-merge.jsx IMAGE branch).
bool RelinkPlaced(AIArtHandle art, const std::string& imagePath) {
	if (!sAIPlaced || !sAIArt) return false;

	AIRealRect oldBounds;
	if (sAIArt->GetArtBounds(art, &oldBounds)) return false;
	const double oldW = oldBounds.right - oldBounds.left;
	const double oldH = oldBounds.top - oldBounds.bottom;

	ai::FilePath file(Utf8(imagePath));
	if (sAIPlaced->SetPlacedFileSpecification(art, file)) return false;

	AIRealRect newBounds;
	if (sAIArt->GetArtBounds(art, &newBounds)) return true;  // relinked; skip resize
	const double newW = newBounds.right - newBounds.left;
	const double newH = newBounds.top - newBounds.bottom;
	if (!(newW > 0.0) || !(newH > 0.0) || !(oldW > 0.0) || !(oldH > 0.0)) return true;

	const double sx = oldW / newW;
	const double sy = oldH / newH;

	// Scale about the new top-left, then shift so top-left lands on the old
	// top-left: x' = sx*x + (oldL - sx*newL); y' = sy*y + (oldT - sy*newT).
	AIRealMatrix matrix;
	matrix.a = sx;
	matrix.b = 0.0;
	matrix.c = 0.0;
	matrix.d = sy;
	matrix.tx = oldBounds.left - sx * newBounds.left;
	matrix.ty = oldBounds.top - sy * newBounds.top;

	if (sAITransformArt) {
		sAITransformArt->TransformArt(art, &matrix, 1.0, kTransformObjects);
	}
	return true;
}

void SetVisibilityFromValue(AIArtHandle art, const std::string& value) {
	if (!sAIArt) return;
	const std::string lowered = LowerAscii(value);
	const bool visible = (lowered == "true" || lowered == "1" || lowered == "yes");
	sAIArt->SetArtUserAttr(art, kArtHidden, visible ? 0 : kArtHidden);
}

struct ApplyResult {
	int applied = 0;
	int missing = 0;
};

ApplyResult ApplyRow(const std::vector<Mapping>& mappings,
                     const std::vector<std::string>& headers,
                     const std::vector<std::string>& row,
                     const std::string& csvDir) {
	ApplyResult result;
	for (const Mapping& mapping : mappings) {
		if (mapping.type == MappingType::Unmapped) continue;

		const int columnIndex = indexOfHeader(headers, mapping.column);
		if (columnIndex < 0 || static_cast<std::size_t>(columnIndex) >= row.size()) continue;
		const std::string& cell = row[static_cast<std::size_t>(columnIndex)];

		if (mapping.type == MappingType::Textual) {
			AIArtHandle art = FindTarget(kTextFrameArt, mapping.targetName, mapping.targetIndex);
			if (art && SetTextContents(art, cell)) {
				++result.applied;
			} else {
				++result.missing;
			}
		} else if (mapping.type == MappingType::Image) {
			AIArtHandle art = FindTarget(kPlacedArt, mapping.targetName, mapping.targetIndex);
			if (!art) {
				++result.missing;
				continue;
			}
			const std::string resolved = ResolveImagePath(cell, csvDir);
			if (!resolved.empty() && RelinkPlaced(art, resolved)) {
				++result.applied;
			} else {
				++result.missing;
			}
		} else if (mapping.type == MappingType::Visibility) {
			std::string name = mapping.column;
			if (!name.empty() && name[0] == '#') name = name.substr(1);
			AIArtHandle art = FindNamedItem(name);
			if (!art && !mapping.targetName.empty()) art = FindNamedItem(mapping.targetName);
			if (art) {
				SetVisibilityFromValue(art, cell);
				++result.applied;
			} else {
				++result.missing;
			}
		}
	}
	return result;
}

std::string JoinOutputPath(const std::string& folder, const std::string& fileName, const std::string& ext) {
	std::string path = folder;
	if (!path.empty() && path.back() != '/' && path.back() != '\\') path += '/';
	path += fileName;
	path += ext;
	return path;
}

std::string BuildError(const std::string& message) {
	std::ostringstream json;
	json << "{\"success\":false,\"usedAip\":true,\"message\":\"" << escapeJson(message) << "\"}";
	return json.str();
}

// Applies one row and exports it to a PDF. Returns true on success; on failure
// fills errOut. appliedOut receives the number of fields applied.
bool ExportRow(const DataMergeRequest& request,
               const std::vector<std::string>& row,
               int rowIndex,
               int& appliedOut,
               std::string& errOut) {
	const long long applyStart = NowMs();
	ApplyResult applied = ApplyRow(request.mappings, request.headers, row, request.csvDir);
	appliedOut = applied.applied;
	if (applied.applied == 0) {
		errOut = "No mapped targets found (name the template objects to match the mapping).";
		return false;
	}

	const std::string fileName = generateFileName(
		request.exportSettings.fileNamePattern, row, request.headers, rowIndex);
	const std::string outputPath = JoinOutputPath(request.exportSettings.outputFolder, fileName, ".pdf");

	const long long writeStart = NowMs();
	ai::FilePath outFile(Utf8(outputPath));
	AIErr writeError = sAIDocument->WriteDocument(outFile, kPdfFormatName, false);
	const long long writeEnd = NowMs();
	Log(std::string("  row ") + std::to_string(rowIndex + 1)
		+ ": apply=" + std::to_string(writeStart - applyStart) + "ms"
		+ " write=" + std::to_string(writeEnd - writeStart) + "ms"
		+ " fields=" + std::to_string(applied.applied)
		+ " -> " + outputPath);
	if (writeError) {
		errOut = std::string("PDF export failed (error ")
			+ std::to_string(static_cast<long long>(writeError)) + ").";
		return false;
	}
	return true;
}

}  // namespace

std::string ExecuteDataMergeRequestJson(const std::string& payload) {
	try {
		if (!sAIDocument || !sAIArt || !sAIMatchingArt || !sAIUndo) {
			return BuildError("Illustrator suites are not ready for data merge.");
		}

		DataMergeRequest request;
		std::string parseError;
		if (!parseDataMergeRequest(payload, request, parseError)) {
			Log(std::string("parse failed: ") + parseError + " (payload bytes=" + std::to_string(payload.size()) + ")");
			return BuildError(parseError);
		}
		if (!request.run) {
			// Health probe (run:false) — confirms the plugin + selector are live.
			return BuildError("Data merge request was disabled by payload.");
		}
		if (request.exportSettings.format != "PDF") {
			return BuildError("AIP data merge currently supports PDF only (P1).");
		}

		sAIUndo->SetUndoTextUS(
			ai::UnicodeString("Undo HopeFlow Data Merge"),
			ai::UnicodeString("Redo HopeFlow Data Merge")
		);

		// Batch mode: loop every row in one message round-trip.
		if (request.mode == "exportBatch") {
			const long long batchStart = NowMs();
			Log(std::string("exportBatch: rows=") + std::to_string(request.rows.size())
				+ " startIndex=" + std::to_string(request.startIndex)
				+ " mappings=" + std::to_string(request.mappings.size()));
			int exported = 0;
			int failed = 0;
			std::string firstError;
			for (std::size_t r = 0; r < request.rows.size(); ++r) {
				int applied = 0;
				std::string rowError;
				if (ExportRow(request, request.rows[r], request.startIndex + static_cast<int>(r), applied, rowError)) {
					++exported;
				} else {
					++failed;
					if (firstError.empty()) firstError = rowError;
				}
			}
			Log(std::string("exportBatch done: exported=") + std::to_string(exported)
				+ " failed=" + std::to_string(failed)
				+ " total=" + std::to_string(NowMs() - batchStart) + "ms");
			std::ostringstream json;
			json << "{\"success\":" << (failed == 0 ? "true" : (exported > 0 ? "true" : "false"))
			     << ",\"usedAip\":true"
			     << ",\"exported\":" << exported
			     << ",\"failed\":" << failed
			     << ",\"message\":\"" << escapeJson(firstError) << "\""
			     << "}";
			return json.str();
		}

		// Single row (exportSingle).
		int applied = 0;
		std::string rowError;
		if (!ExportRow(request, request.rowData, request.rowIndex, applied, rowError)) {
			return BuildError(rowError);
		}
		std::ostringstream json;
		json << "{\"success\":true,\"usedAip\":true"
		     << ",\"exported\":1,\"failed\":0"
		     << ",\"appliedFields\":" << applied
		     << "}";
		return json.str();
	} catch (const ai::Error& error) {
		Log(std::string("ai::Error thrown: ") + std::to_string(static_cast<long long>(error)));
		return BuildError(std::string("Native error ") + std::to_string(static_cast<long long>(error)) + ".");
	} catch (const std::exception& error) {
		Log(std::string("std::exception: ") + error.what());
		return BuildError(std::string("Native exception: ") + error.what());
	} catch (...) {
		Log("unknown exception thrown");
		return BuildError("Unknown native error during data merge.");
	}
}

std::string ExecuteReadTextRotationsJson(const std::string& /*payload*/) {
	try {
		if (!sAITextFrame || !sAIMatchingArt || !sAIMdMemory) {
			return BuildError("Text suites are not ready.");
		}
		std::vector<AIArtHandle> arts = CollectArtOfType(kTextFrameArt);
		std::ostringstream json;
		json << "{\"success\":true,\"usedAip\":true,\"rotations\":[";
		bool first = true;
		for (AIArtHandle art : arts) {
			const std::string name = ArtNameUtf8(art);
			if (name.empty()) continue;  // only named frames are addressable by the panel

			TextFrameRef ref = nullptr;
			if (sAITextFrame->GetATETextFrame(art, &ref) || !ref) continue;

			double angleDeg = 0.0, tx = 0.0, ty = 0.0;
			try {
				ATE::ITextFrame frame(ref);
				ATETextDOM::RealMatrix m = frame.GetMatrix();
				angleDeg = std::atan2(m.b, m.a) * 180.0 / 3.14159265358979323846;
				tx = m.tx;  // baseline anchor X (absolute AI coords)
				ty = m.ty;  // baseline anchor Y (absolute AI coords)
			} catch (...) {
				angleDeg = 0.0;
			}

			if (!first) json << ",";
			first = false;
			json << "{\"name\":\"" << escapeJson(name) << "\",\"angle\":" << angleDeg
			     << ",\"tx\":" << tx << ",\"ty\":" << ty << "}";
		}
		json << "]}";
		return json.str();
	} catch (...) {
		return BuildError("Reading text rotations failed.");
	}
}
