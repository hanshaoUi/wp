#include "IllustratorSDK.h"
#include "SmartGroupRunner.h"

#include "ScriptMessageID.h"
#include "ScriptMessageSuites.h"
#include "smart_group_core.hpp"
#include "smart_group_core.cpp"

#include <algorithm>
#include <cctype>
#include <map>
#include <sstream>
#include <string>
#include <vector>

using hopeflow::smart_group::Bounds;
using hopeflow::smart_group::Item;
using hopeflow::smart_group::Options;
using hopeflow::smart_group::findIntersectingGroups;

namespace {

struct NativeItem {
	AIArtHandle art = nullptr;
	AIArtHandle parent = nullptr;
	std::size_t stackRank = 0;
	Item item;
};

struct OperationStats {
	std::size_t candidateGroups = 0;
	std::size_t parentBuckets = 0;
	std::size_t createdGroups = 0;
	std::size_t skippedBuckets = 0;
	std::size_t comparisons = 0;
};

bool ArtIsAncestor(AIArtHandle ancestor, AIArtHandle descendant) {
	AIArtHandle parent = nullptr;
	if (sAIArt->GetArtParent(descendant, &parent)) return false;
	while (parent) {
		if (parent == ancestor) return true;
		AIArtHandle next = nullptr;
		if (sAIArt->GetArtParent(parent, &next)) break;
		parent = next;
	}
	return false;
}

bool IsEditableArt(AIArtHandle art) {
	if (!art) return false;
	ai::int32 attrs = 0;
	if (sAIArt->GetArtUserAttr(art, kArtLocked | kArtHidden, &attrs)) {
		return false;
	}
	return (attrs & (kArtLocked | kArtHidden)) == 0;
}

bool ContainsArt(const std::vector<AIArtHandle>& items, AIArtHandle art) {
	return std::find(items.begin(), items.end(), art) != items.end();
}

AIArtHandle PromoteToLayerChild(AIArtHandle art) {
	if (!art) return nullptr;

	AIArtHandle current = art;
	while (true) {
		AIArtHandle parent = nullptr;
		if (sAIArt->GetArtParent(current, &parent) || !parent) break;

		AIArtHandle grandparent = nullptr;
		if (sAIArt->GetArtParent(parent, &grandparent) || !grandparent) break;

		current = parent;
	}
	return current;
}

std::size_t GetSiblingIndex(AIArtHandle art) {
	AIArtHandle parent = nullptr;
	if (sAIArt->GetArtParent(art, &parent) || !parent) return 0;

	AIArtHandle child = nullptr;
	if (sAIArt->GetArtFirstChild(parent, &child)) return 0;

	std::size_t index = 0;
	while (child) {
		if (child == art) return index;
		++index;
		AIArtHandle next = nullptr;
		if (sAIArt->GetArtSibling(child, &next)) break;
		child = next;
	}
	return index;
}

void FilterTopLevelArt(std::vector<AIArtHandle>& candidates) {
	std::vector<AIArtHandle> filtered;
	filtered.reserve(candidates.size());
	for (std::size_t i = 0; i < candidates.size(); ++i) {
		AIArtHandle art = candidates[i];
		bool isContainer = false;
		for (std::size_t j = 0; j < candidates.size(); ++j) {
			if (art != candidates[j] && ArtIsAncestor(art, candidates[j])) {
				isContainer = true;
				break;
			}
		}
		if (!isContainer) filtered.push_back(art);
	}
	candidates.swap(filtered);
}

std::vector<NativeItem> BuildNativeItems(const std::vector<AIArtHandle>& candidates) {
	std::vector<NativeItem> nativeItems;
	nativeItems.reserve(candidates.size());
	for (std::size_t i = 0; i < candidates.size(); ++i) {
		AIRealRect rect;
		if (sAIArt->GetArtBounds(candidates[i], &rect)) continue;

		NativeItem native;
		native.art = candidates[i];
		sAIArt->GetArtParent(candidates[i], &native.parent);
		native.stackRank = GetSiblingIndex(candidates[i]);
		native.item.id = nativeItems.size();
		native.item.bounds = Bounds{rect.left, rect.top, rect.right, rect.bottom};
		nativeItems.push_back(native);
	}
	return nativeItems;
}

bool CollectSelectedCandidates(std::vector<AIArtHandle>& candidates) {
	if (!sAIMatchingArt || !sAIMatchingArt->IsSomeArtSelected || !sAIMatchingArt->IsSomeArtSelected()) {
		return false;
	}

	AIMatchingArtSpec spec[1] = {
		AIMatchingArtSpec(kAnyArt, kArtSelected, kArtSelected)
	};
	AIArtHandle** matches = nullptr;
	ai::int32 count = 0;
	AIErr error = sAIMatchingArt->GetMatchingArt(spec, 1, &matches, &count);
	if (error || !matches || count <= 0) {
		if (matches) sAIMdMemory->MdMemoryDisposeHandle((AIMdMemoryHandle)matches);
		return false;
	}

	candidates.reserve(static_cast<std::size_t>(count));
	for (ai::int32 i = 0; i < count; ++i) {
		AIArtHandle art = PromoteToLayerChild((*matches)[i]);
		if (IsEditableArt(art) && !ContainsArt(candidates, art)) candidates.push_back(art);
	}
	sAIMdMemory->MdMemoryDisposeHandle((AIMdMemoryHandle)matches);
	FilterTopLevelArt(candidates);
	return !candidates.empty();
}

bool CollectCurrentLayerCandidates(std::vector<AIArtHandle>& candidates) {
	if (!sAILayer) return false;

	AILayerHandle currentLayer = nullptr;
	if (sAILayer->GetCurrentLayer(&currentLayer) || !currentLayer) {
		return false;
	}

	AIBoolean editable = false;
	if (sAILayer->GetLayerEditable(currentLayer, &editable) || !editable) {
		return false;
	}

	AIBoolean visible = false;
	if (sAILayer->GetLayerVisible(currentLayer, &visible) || !visible) {
		return false;
	}

	AIBoolean isTemplate = false;
	if (!sAILayer->GetLayerIsTemplate(currentLayer, &isTemplate) && isTemplate) {
		return false;
	}

	AIArtHandle layerGroup = nullptr;
	if (sAIArt->GetFirstArtOfLayer(currentLayer, &layerGroup) || !layerGroup) {
		return false;
	}

	AIArtHandle child = nullptr;
	if (sAIArt->GetArtFirstChild(layerGroup, &child)) return false;
	while (child) {
		if (IsEditableArt(child)) candidates.push_back(child);
		AIArtHandle next = nullptr;
		if (sAIArt->GetArtSibling(child, &next)) break;
		child = next;
	}
	return !candidates.empty();
}

std::vector<NativeItem> CollectTargetItems() {
	std::vector<AIArtHandle> candidates;
	if (!CollectSelectedCandidates(candidates)) {
		CollectCurrentLayerCandidates(candidates);
	}
	return BuildNativeItems(candidates);
}

std::vector<std::vector<const NativeItem*>> PartitionByParent(const std::vector<const NativeItem*>& members) {
	std::map<AIArtHandle, std::vector<const NativeItem*>> buckets;
	for (const NativeItem* member : members) {
		if (!member || !member->parent) continue;
		buckets[member->parent].push_back(member);
	}

	std::vector<std::vector<const NativeItem*>> result;
	for (auto& entry : buckets) {
		auto& bucket = entry.second;
		if (bucket.size() < 2) continue;
		std::sort(bucket.begin(), bucket.end(), [](const NativeItem* a, const NativeItem* b) {
			return a->stackRank < b->stackRank;
		});
		result.push_back(bucket);
	}
	return result;
}

AIErr CreateGroupPreservingStack(const std::vector<const NativeItem*>& members, AIArtHandle* createdGroup) {
	if (createdGroup) *createdGroup = nullptr;
	if (members.size() < 2) return kBadParameterErr;

	AIArtHandle anchor = members.front()->art;
	AIArtHandle group = nullptr;
	AIErr error = sAIArt->NewArt(kGroupArt, kPlaceAbove, anchor, &group);
	if (error) return error;

	for (auto it = members.rbegin(); it != members.rend(); ++it) {
		error = sAIArt->ReorderArt((*it)->art, kPlaceInsideOnTop, group);
		if (error) return error;
	}

	if (createdGroup) *createdGroup = group;
	return kNoErr;
}

std::string EscapeJson(const std::string& input) {
	std::string output;
	output.reserve(input.size() + 8);
	for (char ch : input) {
		switch (ch) {
			case '\\': output += "\\\\"; break;
			case '"': output += "\\\""; break;
			case '\r': output += "\\r"; break;
			case '\n': output += "\\n"; break;
			case '\t': output += "\\t"; break;
			default:
				output += ch;
				break;
		}
	}
	return output;
}

bool ParseJsonBool(const std::string& source, const char* key, bool defaultValue) {
	const std::string needle = std::string("\"") + key + "\"";
	std::size_t pos = source.find(needle);
	if (pos == std::string::npos) return defaultValue;
	pos = source.find(':', pos + needle.size());
	if (pos == std::string::npos) return defaultValue;
	++pos;
	while (pos < source.size() && std::isspace(static_cast<unsigned char>(source[pos]))) ++pos;
	if (source.compare(pos, 4, "true") == 0) return true;
	if (source.compare(pos, 5, "false") == 0) return false;
	return defaultValue;
}

double ParseJsonNumber(const std::string& source, const char* key, double defaultValue) {
	const std::string needle = std::string("\"") + key + "\"";
	std::size_t pos = source.find(needle);
	if (pos == std::string::npos) return defaultValue;
	pos = source.find(':', pos + needle.size());
	if (pos == std::string::npos) return defaultValue;
	++pos;
	while (pos < source.size() && std::isspace(static_cast<unsigned char>(source[pos]))) ++pos;
	std::size_t end = pos;
	while (end < source.size()) {
		const char ch = source[end];
		if ((ch >= '0' && ch <= '9') || ch == '-' || ch == '+' || ch == '.') {
			++end;
			continue;
		}
		break;
	}
	if (end == pos) return defaultValue;
	try {
		return std::stod(source.substr(pos, end - pos));
	} catch (...) {
		return defaultValue;
	}
}

std::size_t ParseJsonSize(const std::string& source, const char* key, std::size_t defaultValue) {
	const double parsed = ParseJsonNumber(source, key, static_cast<double>(defaultValue));
	if (parsed < 1.0) return defaultValue;
	return static_cast<std::size_t>(parsed);
}

std::string ParseJsonString(const std::string& source, const char* key, const std::string& defaultValue) {
	const std::string needle = std::string("\"") + key + "\"";
	std::size_t pos = source.find(needle);
	if (pos == std::string::npos) return defaultValue;
	pos = source.find(':', pos + needle.size());
	if (pos == std::string::npos) return defaultValue;
	++pos;
	while (pos < source.size() && std::isspace(static_cast<unsigned char>(source[pos]))) ++pos;
	if (pos >= source.size() || source[pos] != '"') return defaultValue;
	++pos;

	std::string value;
	for (; pos < source.size(); ++pos) {
		const char ch = source[pos];
		if (ch == '\\' && pos + 1 < source.size()) {
			value += source[pos + 1];
			++pos;
			continue;
		}
		if (ch == '"') return value;
		value += ch;
	}
	return defaultValue;
}

std::string BuildJsonResponse(bool success, const std::string& message, const OperationStats& stats, bool usedAip) {
	std::ostringstream json;
	json << "{";
	json << "\"success\":" << (success ? "true" : "false");
	json << ",\"message\":\"" << EscapeJson(message) << "\"";
	json << ",\"usedAip\":" << (usedAip ? "true" : "false");
	json << ",\"candidateGroups\":" << stats.candidateGroups;
	json << ",\"createdGroups\":" << stats.createdGroups;
	json << ",\"skippedBuckets\":" << stats.skippedBuckets;
	json << ",\"comparisons\":" << stats.comparisons;
	json << "}";
	return json.str();
}

AIErr RunSmartGroup(const std::string& payload, OperationStats& stats, std::string& message) {
	if (!sAIArt || !sAIMatchingArt || !sAIMdMemory || !sAILayer || !sAIUndo) {
		message = "Illustrator suites are not ready.";
		return kNoErr;
	}

	std::vector<NativeItem> nativeItems = CollectTargetItems();
	if (nativeItems.size() < 2) {
		message = std::string("Need at least two editable items in the selection or active layer. Found ")
			+ std::to_string(static_cast<unsigned long long>(nativeItems.size())) + ".";
		return kNoErr;
	}

	std::vector<Item> items;
	items.reserve(nativeItems.size());
	for (const auto& native : nativeItems) items.push_back(native.item);

	Options options;
	options.tolerance = ParseJsonNumber(payload, "tolerance", 0.0);
	options.executionMode = ParseJsonString(payload, "executionMode", "create");
	options.maxGroups = ParseJsonSize(payload, "maxGroups", nativeItems.size());
	if (options.maxGroups < 1) options.maxGroups = nativeItems.size();

	auto result = findIntersectingGroups(items, options);
	stats.candidateGroups = result.groups.size();
	stats.comparisons = result.stats.comparisons;
	if (result.groups.empty()) {
		message = "No intersecting groups were detected.";
		return kNoErr;
	}

	bool changed = false;
	for (const auto& groupIds : result.groups) {
		std::vector<const NativeItem*> groupMembers;
		groupMembers.reserve(groupIds.size());
		for (std::size_t itemId : groupIds) {
			if (itemId < nativeItems.size()) groupMembers.push_back(&nativeItems[itemId]);
		}

		auto buckets = PartitionByParent(groupMembers);
		stats.parentBuckets += buckets.size();
		if (buckets.empty()) {
			++stats.skippedBuckets;
			continue;
		}

		for (const auto& bucket : buckets) {
			AIArtHandle createdGroup = nullptr;
			AIErr error = CreateGroupPreservingStack(bucket, &createdGroup);
			if (error) {
				if (changed) sAIUndo->UndoChanges();
				return error;
			}
			changed = true;
			++stats.createdGroups;
		}
	}

	std::ostringstream summary;
	summary << "Detected " << stats.candidateGroups << " candidate groups, created "
	        << stats.createdGroups << " Illustrator groups";
	if (stats.skippedBuckets > 0) {
		summary << ", skipped " << stats.skippedBuckets << " mixed-parent groups";
	}
	if (stats.createdGroups == 0) {
		summary << ". No new groups were created.";
	} else {
		summary << ".";
	}
	message = summary.str();
	return kNoErr;
}

}  // namespace

std::string ExecuteSmartGroupRequestJson(const std::string& payload) {
	const bool shouldRun = ParseJsonBool(payload, "run", true);
	if (!shouldRun) {
		return BuildJsonResponse(false, "AIP request was disabled by payload.", OperationStats{}, true);
	}

	if (!sAIUndo) {
		return BuildJsonResponse(false, "Illustrator undo suite is unavailable.", OperationStats{}, true);
	}

	sAIUndo->SetUndoTextUS(
		ai::UnicodeString(kHopeFlowSmartGroupUndoName),
		ai::UnicodeString(kHopeFlowSmartGroupRedoName)
	);

	OperationStats stats;
	std::string resultMessage;
	AIErr error = RunSmartGroup(payload, stats, resultMessage);
	if (error) {
		sAIUndo->UndoChanges();
		return BuildJsonResponse(
			false,
			std::string("Smart group failed: ") + std::to_string(static_cast<long long>(error)),
			stats,
			true
		);
	}

	return BuildJsonResponse(true, resultMessage, stats, true);
}
