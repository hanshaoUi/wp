#include "IllustratorSDK.h"
#include "ScriptMessagePanelController.h"

#include "AppContext.hpp"
#include "SmartGroupRunner.h"

#include <cctype>
#include <fstream>
#include <string>

namespace {

constexpr const char* kHopeFlowExtensionId = "com.hopeflow.toolbox.panel";
constexpr const char* kIllustratorAppId = "ILST";
constexpr const char* kSmartGroupRunEvent = "com.hopeflow.smartgroup.run";
constexpr const char* kSmartGroupResultEvent = "com.hopeflow.smartgroup.result";
constexpr const char* kSmartGroupDebugLog = "hopeflow-smart-group-aip.log";

std::string GetLogPath() {
	char tempPath[MAX_PATH] = {0};
	const DWORD length = GetTempPathA(MAX_PATH, tempPath);
	if (length > 0 && length < MAX_PATH) {
		return std::string(tempPath) + kSmartGroupDebugLog;
	}
	return "C:\\hopeflow-smart-group-aip.log";
}

std::string EscapeJson(const std::string& input) {
	std::string output;
	output.reserve(input.size() + 8);
	for (char ch : input) {
		switch (ch) {
			case '\\': output += "\\\\"; break;
			case '"': output += "\\\""; break;
			case '\r': output += "\\r"; break;
			case '\n': output += "\\n"; break;
			case '\t': output += "\\t"; break;
			default:
				output += ch;
				break;
		}
	}
	return output;
}

std::string ExtractJsonString(const std::string& source, const char* key) {
	const std::string needle = std::string("\"") + key + "\"";
	std::size_t pos = source.find(needle);
	if (pos == std::string::npos) return std::string();
	pos = source.find(':', pos + needle.size());
	if (pos == std::string::npos) return std::string();
	++pos;
	while (pos < source.size() && std::isspace(static_cast<unsigned char>(source[pos]))) ++pos;
	if (pos >= source.size() || source[pos] != '"') return std::string();
	++pos;

	std::string value;
	for (; pos < source.size(); ++pos) {
		char ch = source[pos];
		if (ch == '\\' && pos + 1 < source.size()) {
			value += source[pos + 1];
			++pos;
			continue;
		}
		if (ch == '"') break;
		value += ch;
	}
	return value;
}

static void SmartGroupRunFunc(const csxs::event::Event* const eventParam, void* const context) {
	ScriptMessagePanelController* panelController = static_cast<ScriptMessagePanelController*>(context);
	if (!panelController) return;
	panelController->HandleSmartGroupRun(eventParam ? eventParam->data : nullptr);
}

}  // namespace

ScriptMessagePanelController::ScriptMessagePanelController(SPPluginRef pluginRef)
	: FlashUIController(kHopeFlowExtensionId),
	  fPluginRef(pluginRef) {}

csxs::event::EventErrorCode ScriptMessagePanelController::RegisterCSXSEventListeners() {
	if (fListenersRegistered) {
		LogDebug("RegisterCSXSEventListeners: already registered");
		return csxs::event::kEventErrorCode_Success;
	}

	const csxs::event::EventErrorCode result = fPPLib.AddEventListener(kSmartGroupRunEvent, SmartGroupRunFunc, this);
	LogDebug(std::string("RegisterCSXSEventListeners: result=") + std::to_string(static_cast<int>(result)));
	if (result == csxs::event::kEventErrorCode_Success) {
		fListenersRegistered = true;
	}
	return result;
}

csxs::event::EventErrorCode ScriptMessagePanelController::RemoveEventListeners() {
	if (!fListenersRegistered) {
		return csxs::event::kEventErrorCode_Success;
	}
	const csxs::event::EventErrorCode result = fPPLib.RemoveEventListener(kSmartGroupRunEvent, SmartGroupRunFunc, this);
	LogDebug(std::string("RemoveEventListeners: result=") + std::to_string(static_cast<int>(result)));
	if (result == csxs::event::kEventErrorCode_Success) {
		fListenersRegistered = false;
	}
	return result;
}

ASErr ScriptMessagePanelController::SendThemeToPanel() {
	return kNoErr;
}

ASErr ScriptMessagePanelController::SendData() {
	return kNoErr;
}

void ScriptMessagePanelController::ParseData(const char* eventData) {
	fLastEventData = eventData ? eventData : "";
}

void ScriptMessagePanelController::HandleSmartGroupRun(const char* eventData) {
	ParseData(eventData);
	LogDebug(std::string("HandleSmartGroupRun: payload=") + fLastEventData);
	const std::string requestId = ExtractJsonString(fLastEventData, "requestId");
	AppContext appContext(fPluginRef);
	const std::string resultJson = ExecuteSmartGroupRequestJson(fLastEventData);
	LogDebug(std::string("HandleSmartGroupRun: requestId=") + requestId + ", result=" + resultJson);
	DispatchSmartGroupResult(requestId, resultJson);
}

void ScriptMessagePanelController::DispatchSmartGroupResult(const std::string& requestId, const std::string& resultJson) {
	const std::string payload =
		std::string("{\"requestId\":\"") + EscapeJson(requestId) + "\",\"result\":" + resultJson + "}";

	csxs::event::Event event = {
		kSmartGroupResultEvent,
		csxs::event::kEventScope_Application,
		kIllustratorAppId,
		kHopeFlowExtensionId,
		payload.c_str()
	};
	LogDebug(std::string("DispatchSmartGroupResult: requestId=") + requestId);
	fPPLib.DispatchEvent(&event);
}

void ScriptMessagePanelController::LogDebug(const std::string& message) {
	const std::string logPath = GetLogPath();
	if (logPath.empty()) return;
	std::ofstream stream(logPath.c_str(), std::ios::out | std::ios::app);
	if (!stream.is_open()) return;
	stream << message << "\n";
}
