#ifndef __SmartGroupRunner_h__
#define __SmartGroupRunner_h__

#include <string>

std::string ExecuteSmartGroupRequestJson(const std::string& payload);

#endif
