#include "IllustratorSDK.h"
#include "ScriptMessageSuites.h"

extern "C"
{
	SPBlocksSuite* sSPBlocks = nullptr;
	AIUnicodeStringSuite* sAIUnicodeString = nullptr;
	AIArtSuite* sAIArt = nullptr;
	AIMatchingArtSuite* sAIMatchingArt = nullptr;
	AIMdMemorySuite* sAIMdMemory = nullptr;
	AILayerSuite* sAILayer = nullptr;
	AIMenuSuite* sAIMenu = nullptr;
	AIUndoSuite* sAIUndo = nullptr;
	AIDocumentSuite* sAIDocument = nullptr;
	AITextFrameSuite* sAITextFrame = nullptr;
	AIPlacedSuite* sAIPlaced = nullptr;
	AITransformArtSuite* sAITransformArt = nullptr;
	// ATE C++ wrapper suite globals (used by ITextRange etc.).
	EXTERN_TEXT_SUITES
}

ImportSuite gImportSuites[] =
{
	kSPBlocksSuite, kSPBlocksSuiteVersion, &sSPBlocks,
	kAIUnicodeStringSuite, kAIUnicodeStringVersion, &sAIUnicodeString,
	kAIArtSuite, kAIArtSuiteVersion, &sAIArt,
	kAIMatchingArtSuite, kAIMatchingArtSuiteVersion, &sAIMatchingArt,
	kAIMdMemorySuite, kAIMdMemorySuiteVersion, &sAIMdMemory,
	kAILayerSuite, kAILayerSuiteVersion, &sAILayer,
	kAIMenuSuite, kAIMenuSuiteVersion, &sAIMenu,
	kAIUndoSuite, kAIUndoSuiteVersion, &sAIUndo,
	kAIDocumentSuite, kAIDocumentVersion, &sAIDocument,
	kAITextFrameSuite, kAITextFrameSuiteVersion, &sAITextFrame,
	kAIPlacedSuite, kAIPlacedSuiteVersion, &sAIPlaced,
	kAITransformArtSuite, kAITransformArtSuiteVersion, &sAITransformArt,
	IMPORT_TEXT_SUITES
	nullptr, 0, nullptr
};
