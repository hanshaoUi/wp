#ifndef __DataMergeRunner_H__
#define __DataMergeRunner_H__

#include <string>

// Entry point for the HopeFlow data-merge AIP selector (runDataMerge).
// Parses the panel JSON payload, applies one CSV row to the active document by
// replacing mapped text/image/visibility targets, exports the current artboard
// (P1: PDF only, single row) and returns a JSON result string.
std::string ExecuteDataMergeRequestJson(const std::string& payload);

// Reads the rotation angle (degrees) of every named text frame in the active
// document via ATE ITextFrame::GetMatrix — ExtendScript cannot read this.
// Returns JSON: {"success":true,"rotations":[{"name":..,"angle":..},...]}.
std::string ExecuteReadTextRotationsJson(const std::string& payload);

#endif
