#ifndef __ScriptMessageID_H__
#define __ScriptMessageID_H__

#define kScriptMessagePluginName "HopeFlow"
#define kHopeFlowSmartGroupSelectorRun "runSmartGroup"
#define kHopeFlowDataMergeSelectorRun "runDataMerge"
#define kHopeFlowReadRotationsSelectorRun "readTextRotations"
#define kHopeFlowSmartGroupUndoName "Undo HopeFlow Smart Group"
#define kHopeFlowSmartGroupRedoName "Redo HopeFlow Smart Group"

#endif
