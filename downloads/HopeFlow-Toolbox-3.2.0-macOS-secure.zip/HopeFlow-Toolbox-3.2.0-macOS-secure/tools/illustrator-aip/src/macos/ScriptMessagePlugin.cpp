#include "IllustratorSDK.h"
#include "ScriptMessagePlugin.h"

#include "AICSXS.h"
#include "AIScriptMessage.h"
#include "SmartGroupRunner.h"
#include "DataMergeRunner.h"

#include <cstdlib>
#include <cstring>
#include <fstream>
#include <new>
#include <sstream>
#include <string>

namespace {

std::string GetStartupLogPath() {
	const char* tempDir = std::getenv("TMPDIR");
	if (tempDir && tempDir[0] != '\0') {
		std::string path(tempDir);
		if (path.back() != '/') path += '/';
		return path + "hopeflow-smart-group-aip.log";
	}

	const char* homeDir = std::getenv("HOME");
	if (homeDir && homeDir[0] != '\0') {
		return std::string(homeDir) + "/Library/Logs/hopeflow-smart-group-aip.log";
	}

	return "/tmp/hopeflow-smart-group-aip.log";
}

void WriteStartupLog(const char* message) {
	std::ofstream stream(GetStartupLogPath().c_str(), std::ios::out | std::ios::app);
	if (!stream.is_open()) return;
	stream << message << "\n";
}

void WriteStartupLogWithError(const char* message, ASErr error) {
	std::ostringstream line;
	line << message << ": " << static_cast<long>(error);
	WriteStartupLog(line.str().c_str());
}

}  // namespace

Plugin* AllocatePlugin(SPPluginRef pluginRef) {
	return new ScriptMessagePlugin(pluginRef);
}

void FixupReload(Plugin* plugin) {
	ScriptMessagePlugin::FixupVTable((ScriptMessagePlugin*)plugin);
}

ScriptMessagePlugin::ScriptMessagePlugin(SPPluginRef pluginRef)
	: Plugin(pluginRef),
	  fPlugPlugSetupCompleteNotifier(nullptr),
	  fPanelController(nullptr) {
	strncpy(fPluginName, kScriptMessagePluginName, kMaxStringLength);
}

ASErr ScriptMessagePlugin::StartupPlugin(SPInterfaceMessage* message) {
	WriteStartupLog("StartupPlugin: entering before base startup");
	ASErr error = kNoErr;
	error = SetGlobal(this);
	WriteStartupLogWithError("StartupPlugin: SetGlobal result", error);
	if (!error) {
		fSuites = new(std::nothrow) Suites;
		if (!fSuites) {
			error = kOutOfMemoryErr;
		} else {
			error = fSuites->Error();
			fSuites->InitializeRefCount();
		}
	}
	WriteStartupLogWithError("StartupPlugin: Suites result", error);
	if (error == kSPSuiteNotFoundError) {
		WriteStartupLog("StartupPlugin: continuing after kSPSuiteNotFoundError during early startup");
		error = kNoErr;
	}
	if (error) {
		if (fSuites) {
			delete fSuites;
			fSuites = nullptr;
		}
		return error;
	}
	error = sSPPlugins->SetPluginName(message->d.self, fPluginName);
	WriteStartupLogWithError("StartupPlugin: SetPluginName result", error);
	if (!error) {
		error = AllocateSuiteTables();
		WriteStartupLogWithError("StartupPlugin: AllocateSuiteTables result", error);
	}
	if (!error) {
		error = FillSuiteTables();
		WriteStartupLogWithError("StartupPlugin: FillSuiteTables result", error);
	}
	if (!error) {
		error = Plugin::LockPlugin(true);
		WriteStartupLogWithError("StartupPlugin: LockPlugin result", error);
	}
	if (error) return error;
	if (sAINotifier != nullptr) {
		error = sAINotifier->AddNotifier(
			fPluginRef,
			kScriptMessagePluginName,
			kAICSXSPlugPlugSetupCompleteNotifier,
			&fPlugPlugSetupCompleteNotifier
		);
		WriteStartupLogWithError(error ? "StartupPlugin: AddNotifier failed" : "StartupPlugin: AddNotifier succeeded", error);
		return error == kSPSuiteNotFoundError ? kNoErr : error;
	}

	WriteStartupLog("StartupPlugin: sAINotifier unavailable; skipping PlugPlug setup notifier");
	return kNoErr;
}

ASErr ScriptMessagePlugin::ShutdownPlugin(SPInterfaceMessage* message) {
	if (fPanelController != nullptr) {
		fPanelController->RemoveEventListeners();
		delete fPanelController;
		fPanelController = nullptr;
		Plugin::LockPlugin(false);
	}
	return Plugin::ShutdownPlugin(message);
}

ASErr ScriptMessagePlugin::Notify(AINotifierMessage* message) {
	if (message && message->notifier == fPlugPlugSetupCompleteNotifier && fPanelController != nullptr) {
		WriteStartupLog("Notify: kAICSXSPlugPlugSetupCompleteNotifier");
		fPanelController->RegisterCSXSEventListeners();
	} else if (message && message->notifier == fPlugPlugSetupCompleteNotifier) {
		WriteStartupLog("Notify: PlugPlug setup complete; panel controller disabled for macOS startup stability");
	}
	return kNoErr;
}

ASErr ScriptMessagePlugin::Message(char* caller, char* selector, void* message) {
	if (std::strcmp(caller, kCallerAIScriptMessage) != 0) {
		return Plugin::Message(caller, selector, message);
	}

	AIScriptMessage* scriptMessage = static_cast<AIScriptMessage*>(message);
	if (!scriptMessage) return kBadParameterErr;

	const std::string payload = scriptMessage->inParam.as_Platform();

	if (std::strcmp(selector, kHopeFlowSmartGroupSelectorRun) == 0) {
		scriptMessage->outParam = ai::UnicodeString(ExecuteSmartGroupRequestJson(payload).c_str());
		return kNoErr;
	}

	if (std::strcmp(selector, kHopeFlowDataMergeSelectorRun) == 0) {
		scriptMessage->outParam = ai::UnicodeString(ExecuteDataMergeRequestJson(payload).c_str());
		return kNoErr;
	}

	if (std::strcmp(selector, kHopeFlowReadRotationsSelectorRun) == 0) {
		scriptMessage->outParam = ai::UnicodeString(ExecuteReadTextRotationsJson(payload).c_str());
		return kNoErr;
	}

	scriptMessage->outParam = ai::UnicodeString(
		"{\"success\":false,\"message\":\"Unsupported selector.\",\"usedAip\":true}"
	);
	return kNoErr;
}
