#ifndef __ScriptMessagePlugin_h__
#define __ScriptMessagePlugin_h__

#include "Plugin.hpp"
#include "ScriptMessagePanelController.h"
#include "SDKDef.h"
#include "ScriptMessageID.h"
#include "ScriptMessageSuites.h"
#include "AIScriptMessage.h"

Plugin* AllocatePlugin(SPPluginRef pluginRef);
void FixupReload(Plugin* plugin);

class ScriptMessagePlugin : public Plugin
{
public:
	ScriptMessagePlugin(SPPluginRef pluginRef);
	FIXUP_VTABLE_EX(ScriptMessagePlugin, Plugin);

	virtual ASErr StartupPlugin(SPInterfaceMessage* message);
	virtual ASErr ShutdownPlugin(SPInterfaceMessage* message);
	virtual ASErr Message(char* caller, char* selector, void* message);
	virtual ASErr Notify(AINotifierMessage* message);

private:
	AINotifierHandle fPlugPlugSetupCompleteNotifier;
	ScriptMessagePanelController* fPanelController;
};

#endif
