#ifndef __ScriptMessagePanelController_h__
#define __ScriptMessagePanelController_h__

#include "IllustratorSDK.h"
#include "FlashUIController.h"

#include <string>

class ScriptMessagePanelController : public FlashUIController
{
public:
	explicit ScriptMessagePanelController(SPPluginRef pluginRef);

	csxs::event::EventErrorCode RegisterCSXSEventListeners() override;
	csxs::event::EventErrorCode RemoveEventListeners() override;
	ASErr SendThemeToPanel();
	ASErr SendData() override;
	void ParseData(const char* eventData) override;
	void HandleSmartGroupRun(const char* eventData);

private:
	void DispatchSmartGroupResult(const std::string& requestId, const std::string& resultJson);
	void LogDebug(const std::string& message);
	SPPluginRef fPluginRef;
	std::string fLastEventData;
	bool fListenersRegistered = false;
};

#endif
