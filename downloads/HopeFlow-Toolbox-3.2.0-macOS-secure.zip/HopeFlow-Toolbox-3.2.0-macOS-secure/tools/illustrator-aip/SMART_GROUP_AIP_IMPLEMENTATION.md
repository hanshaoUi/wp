# 智能分组 AIP 实现方案

本文记录当前 Windows AIP 实现的运行路径、安全边界和后续 macOS 迁移注意事项。目标是让智能分组在 Illustrator 进程内完成计算和建组，避免 JSX 往返带来的性能问题，同时不改变对象几何、外观和可撤销性。

## 当前范围

- 正式入口是 CEP 面板中的“智能分组”按钮，不再把 AIP 暴露为 Illustrator 顶层菜单。
- `create` 模式必须走 AIP；如果插件不可用，面板直接报错，不退回 JSX。
- Windows 是当前验收平台；macOS 只保留可复用核心算法和迁移说明。
- AIP 只允许做结构性变化：创建 Illustrator 原生 group，并把符合条件的对象移动进该 group。
- 不修改填充、描边、透明度、混合模式、文本内容、路径点、变换矩阵、对象坐标或尺寸。

## 运行链路

1. 面板在 `src/panel/components/ScriptCard.tsx` 中调用 `runSmartGroupAip`。
2. 面板通过 CSXS 事件 `com.hopeflow.smartgroup.run` 发送参数和 `requestId`。
3. AIP 的 `ScriptMessagePanelController` 监听该事件。
4. 事件回调内必须创建 `AppContext appContext(fPluginRef)`，否则 Illustrator suite 在面板事件线程里可能读不到当前文档和选择，表现为 `Found 0`。
5. `ExecuteSmartGroupRequestJson` 调用 `SmartGroupRunner` 完成对象收集、候选分组和建组。
6. AIP 通过 `com.hopeflow.smartgroup.result` 回传 JSON 结果。
7. CEP 侧兼容两类 payload：部分环境会直接传对象，部分环境会传 JSON 字符串。

## 对象收集策略

- 首选当前选择：`AIArtSetSuite::MatchingArtSet` 查询 `kAnyArt + kArtSelected`。
- 选择对象可能是复合路径、组内子对象或更深层级对象，因此 AIP 会把选中子对象提升到“可移动的外层 layer child”作为候选。
- 提升后的候选会去重，避免同一个外层对象因为多个子对象被选中而重复参与计算。
- 如果没有可编辑候选，返回明确错误：至少需要两个可编辑对象。
- 锁定、隐藏、不可编辑对象不应进入建组阶段。

## 分组计算

- 可复用核心位于 `tools/illustrator-aip/src/core/smart_group_core.*`。
- 核心算法保留现有 JSX 的最小必要语义：容差、矩形边界、候选缩减、连通分量。
- Windows runner 从 Illustrator bounds 构造轻量 item，再交给核心算法计算 candidate groups。
- `candidateGroups` 表示算法检测到的逻辑连通组；`createdGroups` 表示实际创建的 Illustrator group 数量。

## 建组安全边界

Illustrator 对象的外观可能依赖父容器、图层、剪切组、透明组、混合上下文和堆叠上下文。之前跨父级直接搬对象会导致颜色变化，因此当前实现采用更保守的规则：

- 只在同一个直接父容器内创建 group。
- 一个候选组如果跨多个父容器，会按父容器拆分成多个实际 group。
- 不把对象从不同父容器强行合并到一个 group。
- 不解散已有 group、compound path、clipping group 或其他容器结构。
- 建组时使用 Illustrator SDK 的 `NewArt(kGroupArt, ...)` 和 `ReorderArt(..., kPlaceInsideOnTop, group)`。
- 对象进入 group 后仍是原对象句柄，不做坐标重建或外观复制。

这个边界解释了为什么运行结果可能出现 `Detected 71 candidate groups, created 1007 Illustrator groups`：检测到 71 个逻辑连通组，但为了不跨父级破坏外观，每个逻辑组会被拆成多个同父级安全 group。

## 堆叠顺序

- 每个实际 group 只处理同父级对象，避免跨父级重排。
- 建组前按当前父容器下的堆叠关系排序。
- group 以同组对象中的锚点对象为参照创建，再按顺序把成员移动进 group。
- 这保证视觉顺序尽量保持在原父容器范围内；不得为了减少 group 数量而跨容器合并。

## 撤销

- 执行前通过 `AIUndoSuite::SetUndoTextUS` 设置撤销/重做文案。
- 建组使用 Illustrator 原生 art 操作，因此进入 Illustrator 原生撤销栈。
- 用户执行一次 Undo 应完整撤回本次智能分组。
- 如果后续增加更复杂的事务控制，必须保证异常路径不会留下半完成 group。

## Windows 构建与安装

- 构建入口：`tools/illustrator-aip/build-windows-aip.ps1`。
- 支持单版本和 `-All` 批量构建，自动发现 `tools/illustrator-aip/sdk/win_Adobe Illustrator YYYY SDK/`。
- 产物名称固定为 `HopeFlow.aip`。
- 根产物：`tools/illustrator-aip/HopeFlow.aip`。
- 年份产物：`tools/illustrator-aip/windows/YYYY/HopeFlow.aip`。
- 安装脚本：`tools/installers/windows-installer.ps1`。
- Windows 安装脚本会按 Illustrator 年份选择匹配 AIP，并同时兼容 `Plug-ins` 与中文 `增效工具` 插件目录。
- 打包脚本：`build/package-windows-release.ps1`，负责把 AIP 产物纳入 Windows release。

常用验证命令：

```powershell
npm run typecheck
node tools/validate-script-registry.js
powershell -ExecutionPolicy Bypass -File .\tools\illustrator-aip\build-windows-aip.ps1 -Year 2026
powershell -ExecutionPolicy Bypass -File .\tools\installers\windows-installer.ps1
```

## macOS 迁移要点

- 复用 `src/core/smart_group_core.*`，不要重写分组算法。
- macOS AIP 工程由 `tools/illustrator-aip/build-macos-aip.sh` 从 Adobe SDK `samplecode/ScriptMessage` 动态生成，保持插件名和结果协议一致：`HopeFlow`、`com.hopeflow.smartgroup.run`、`com.hopeflow.smartgroup.result`。
- 面板入口不应区分 Windows/macOS 的业务逻辑，只应根据平台安装对应 AIP。
- macOS 的 CSXS/PlugPlug 事件回调同样必须进入 Illustrator `AppContext`。
- 建组仍然只能使用 Illustrator SDK suite 操作原对象，不能导出坐标后重建对象。
- 必须保留“同父级建组”安全边界；如果未来要支持跨父级完整合并，需要先证明不会改变图层外观、剪切、透明组、混合模式和堆叠语义。
- macOS 安装脚本 `install.sh` 会安装 CEP 面板，并把 `tools/illustrator-aip/macos/YYYY/HopeFlow.aip` 或 `macos/HopeFlow.aip` 放入 Illustrator Plug-ins 目录；打包脚本必须排除 Adobe SDK 和临时构建目录。

## 后续改进方向

- 如果需要减少 `createdGroups` 数量，应研究“安全公共父容器”策略，而不是恢复跨父级移动。
- 可以增加运行前后的外观校验脚本，比较 bounds、transform、appearance hash 和父容器上下文。
- 可以把 Windows runner 的 Illustrator suite 访问再薄化，让 macOS 只实现平台适配层。
- 可以保留调试日志开关，但默认不弹窗、不阻塞面板。
