param(
    [switch]$All,
    [ValidatePattern('^\d{4}$')]
    [string]$Year = $env:ILLUSTRATOR_SDK_YEAR,
    [string]$IllustratorSdkRoot = $env:ILLUSTRATOR_SDK_ROOT
)

$ErrorActionPreference = 'Stop'

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$AipRoot = $ScriptDir
$SourceRoot = Join-Path $AipRoot 'src'
$TemplateSource = Join-Path $SourceRoot 'windows'
$CoreSource = Join-Path $SourceRoot 'core'
$OutputRoot = Join-Path $AipRoot 'windows'
$AipFileName = 'HopeFlow.aip'
$DefaultOutputAip = Join-Path $AipRoot $AipFileName
$WorkRoot = Join-Path $AipRoot 'build-aip-work\windows'

function Get-IllustratorSdkYear {
    param([string]$Path)
    $match = [regex]::Match($Path, 'Adobe Illustrator (\d{4}) SDK')
    if ($match.Success) {
        return $match.Groups[1].Value
    }
    return 'default'
}

function Get-WindowsSdkCandidates {
    $candidates = @(
        Join-Path $AipRoot 'sdk\AdobeIllustratorSDK'
    )

    foreach ($sdkYear in 2026..2020) {
        $candidates += (Join-Path $AipRoot "sdk\win_Adobe Illustrator $sdkYear SDK")
    }

    foreach ($candidate in $candidates) {
        if (Test-Path -LiteralPath (Join-Path $candidate 'illustratorapi\illustrator\AIPlugin.h') -PathType Leaf) {
            Get-Item -LiteralPath $candidate
        }
    }
}

function Get-MSBuildPath {
    $commands = @(
        (Get-Command msbuild.exe -ErrorAction SilentlyContinue).Source
    ) | Where-Object { $_ }

    $vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
    if (Test-Path -LiteralPath $vswhere -PathType Leaf) {
        $found = & $vswhere -latest -products * -requires Microsoft.Component.MSBuild -find 'MSBuild\**\Bin\MSBuild.exe'
        $commands += @($found | Where-Object { $_ })
    }

    $path = $commands | Select-Object -First 1
    if (-not $path) {
        throw 'MSBuild was not found. Install Visual Studio with the C++ workload before building Windows AIP variants.'
    }
    return $path
}

function Build-OneWindowsAip {
    param(
        [string]$SdkRoot,
        [string]$SdkYear,
        [string]$MSBuildPath
    )

    $sampleDir = Join-Path $SdkRoot 'samplecode\ScriptMessage'
    $projectFile = Join-Path $sampleDir 'ScriptMessage.vcxproj'
    if (-not (Test-Path -LiteralPath $projectFile -PathType Leaf)) {
        throw "Missing SDK ScriptMessage project: $projectFile"
    }

    $workDir = Join-Path $WorkRoot $SdkYear
    $projectDir = Join-Path $workDir 'samplecode\ScriptMessage'
    $outputAip = if ($SdkYear -eq 'default') {
        $DefaultOutputAip
    } else {
        Join-Path (Join-Path $OutputRoot $SdkYear) $AipFileName
    }

    Remove-Item -LiteralPath $workDir -Recurse -Force -ErrorAction SilentlyContinue
    New-Item -ItemType Directory -Path $workDir -Force | Out-Null
    New-Item -ItemType Directory -Path (Split-Path -Parent $outputAip) -Force | Out-Null

    Copy-Item -LiteralPath (Join-Path $SdkRoot 'samplecode') -Destination (Join-Path $workDir 'samplecode') -Recurse -Force
    Copy-Item -LiteralPath (Join-Path $SdkRoot 'tools') -Destination (Join-Path $workDir 'tools') -Recurse -Force
    Copy-Item -LiteralPath (Join-Path $SdkRoot 'illustratorapi') -Destination (Join-Path $workDir 'illustratorapi') -Recurse -Force

    $modernPiplTools = Join-Path $AipRoot 'sdk\win_Adobe Illustrator 2026 SDK\tools\pipl'
    $workPiplTools = Join-Path $workDir 'tools\pipl'
    if (Test-Path -LiteralPath $modernPiplTools -PathType Container) {
        Remove-Item -LiteralPath $workPiplTools -Recurse -Force -ErrorAction SilentlyContinue
        Copy-Item -LiteralPath $modernPiplTools -Destination $workPiplTools -Recurse -Force
    }

    # NOTE: use -Path (not -LiteralPath) so the '*' wildcard expands. -LiteralPath
    # treats '*' literally and silently copies nothing, leaving the SDK's stock
    # ScriptMessage source in place (the plug-in then has no HopeFlow code).
    Get-ChildItem -LiteralPath $TemplateSource -File | Copy-Item -Destination (Join-Path $projectDir 'Source') -Force
    Copy-Item -LiteralPath (Join-Path $CoreSource 'smart_group_core.hpp') -Destination (Join-Path $projectDir 'Source\smart_group_core.hpp') -Force
    Copy-Item -LiteralPath (Join-Path $CoreSource 'smart_group_core.cpp') -Destination (Join-Path $projectDir 'Source\smart_group_core.cpp') -Force
    # data_merge_core is unity-included by DataMergeRunner.cpp (#include "data_merge_core.cpp"),
    # so both files must sit next to it in Source. Mirrors the macOS Xcode project additions.
    Copy-Item -LiteralPath (Join-Path $CoreSource 'data_merge_core.hpp') -Destination (Join-Path $projectDir 'Source\data_merge_core.hpp') -Force
    Copy-Item -LiteralPath (Join-Path $CoreSource 'data_merge_core.cpp') -Destination (Join-Path $projectDir 'Source\data_merge_core.cpp') -Force

    $resourceFile = Join-Path $projectDir 'Resources\Win\ScriptMessage.rc'
    if (Test-Path -LiteralPath $resourceFile -PathType Leaf) {
        $resourceText = Get-Content -LiteralPath $resourceFile -Raw
        $resourceText = $resourceText -replace '#include "afxres\.h"', '#include "winres.h"'
        $resourceText = $resourceText -replace '#define kMySDKPluginName "ScriptMessage"', '#define kMySDKPluginName "HopeFlow"'
        Set-Content -LiteralPath $resourceFile -Value $resourceText -Encoding UTF8
    }

    $projectFile = Join-Path $projectDir 'ScriptMessage.vcxproj'
    if (Test-Path -LiteralPath $projectFile -PathType Leaf) {
        $projText = Get-Content -LiteralPath $projectFile -Raw
        $projText = $projText.Replace('\"name\":\"ScriptMessage\"', '\"name\":\"HopeFlow\"')
        $projText = $projText.Replace('ScriptMessage.aip', 'HopeFlow.aip')
        $projText = $projText.Replace('ScriptMessage.lib', 'HopeFlow.lib')
        $projText = $projText.Replace('ScriptMessage.pdb', 'HopeFlow.pdb')
        if ($projText -notmatch 'Source\\SmartGroupRunner\.cpp') {
            # DataMergeRunner.cpp defines Execute{DataMergeRequest,ReadTextRotations}Json,
            # called from ScriptMessagePlugin.cpp; IText.cpp/IThrowException.cpp provide the
            # ATE ITextRange/Exception implementations it links against. Mirrors macOS.
            $projText = $projText.Replace(
                '<ClCompile Include="Source\ScriptMessageSuites.cpp" />',
                "<ClCompile Include=`"Source\ScriptMessageSuites.cpp`" />`r`n" +
                "    <ClCompile Include=`"Source\SmartGroupRunner.cpp`" />`r`n" +
                "    <ClCompile Include=`"Source\DataMergeRunner.cpp`" />`r`n" +
                "    <ClCompile Include=`"..\..\illustratorapi\ate\IText.cpp`" />`r`n" +
                "    <ClCompile Include=`"..\..\illustratorapi\ate\IThrowException.cpp`" />"
            )
        }
        if ($projText -notmatch 'Source\\SmartGroupRunner\.h') {
            $projText = $projText.Replace(
                '<ClInclude Include="Source\ScriptMessageID.h" />',
                "<ClInclude Include=`"Source\ScriptMessageID.h`" />`r`n" +
                "    <ClInclude Include=`"Source\SmartGroupRunner.h`" />`r`n" +
                "    <ClInclude Include=`"Source\DataMergeRunner.h`" />"
            )
        }
        Set-Content -LiteralPath $projectFile -Value $projText -Encoding UTF8
    }

    Write-Host "Building Windows AIP with Illustrator SDK ${SdkYear}: $SdkRoot"
    & $MSBuildPath (Join-Path $projectDir 'ScriptMessage.vcxproj') /m /p:Configuration=Release /p:Platform=x64 /p:PlatformToolset=v143 /p:TargetName=HopeFlow
    if ($LASTEXITCODE -ne 0) {
        throw "MSBuild failed for Illustrator SDK $SdkYear with exit code $LASTEXITCODE."
    }

    $found = Get-ChildItem -LiteralPath $workDir -Recurse -Filter '*.aip' -File -ErrorAction SilentlyContinue |
        Sort-Object @{ Expression = { if ($_.Name -eq $AipFileName) { 0 } else { 1 } } }, LastWriteTime -Descending |
        Select-Object -First 1
    if (-not $found) {
        throw "Build succeeded but $AipFileName was not found for SDK $SdkYear."
    }

    Copy-Item -LiteralPath $found.FullName -Destination $outputAip -Force
    Write-Host "Windows AIP created: $outputAip"
}

$sdkItems = @()
if ($IllustratorSdkRoot) {
    $sdkItems = @(Get-Item -LiteralPath $IllustratorSdkRoot)
} elseif ($All) {
    $sdkItems = @(Get-WindowsSdkCandidates | Where-Object { (Get-IllustratorSdkYear $_.FullName) -ne 'default' })
} elseif ($Year) {
    $sdkItems = @(Get-Item -LiteralPath (Join-Path $AipRoot "sdk\win_Adobe Illustrator $Year SDK"))
} else {
    $sdkItems = @(Get-WindowsSdkCandidates | Select-Object -First 1)
}

if ($sdkItems.Count -eq 0) {
    throw "Illustrator Windows SDK not found under $(Join-Path $AipRoot 'sdk')."
}

$msbuild = Get-MSBuildPath
foreach ($sdk in $sdkItems) {
    $sdkYear = Get-IllustratorSdkYear $sdk.FullName
    Build-OneWindowsAip -SdkRoot $sdk.FullName -SdkYear $sdkYear -MSBuildPath $msbuild
}

$latest = Get-ChildItem -LiteralPath $OutputRoot -Recurse -Filter $AipFileName -File -ErrorAction SilentlyContinue |
    Sort-Object FullName -Descending |
    Select-Object -First 1
if ($latest) {
    Copy-Item -LiteralPath $latest.FullName -Destination $DefaultOutputAip -Force
}
