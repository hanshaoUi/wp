#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
AIP_ROOT="$SCRIPT_DIR"
SOURCE_ROOT="$AIP_ROOT/src"
WINDOWS_SOURCE="$SOURCE_ROOT/windows"
MACOS_SOURCE="$SOURCE_ROOT/macos"
CORE_SOURCE="$SOURCE_ROOT/core"
OUTPUT_ROOT="$AIP_ROOT/macos"
WORK_ROOT="$AIP_ROOT/build-aip-work/macos"
AIP_FILE_NAME="HopeFlow.aip"
DEFAULT_OUTPUT_AIP="$OUTPUT_ROOT/$AIP_FILE_NAME"

ALL=0
YEAR="${ILLUSTRATOR_SDK_YEAR:-}"
ILLUSTRATOR_SDK_ROOT="${ILLUSTRATOR_SDK_ROOT:-}"
CONFIGURATION="${CONFIGURATION:-release}"
MACOSX_DEPLOYMENT_TARGET="${MACOSX_DEPLOYMENT_TARGET:-12.0}"
MACOS_ARCHS="${MACOS_ARCHS:-arm64}"
MACOS_CODESIGN_IDENTITY="${MACOS_CODESIGN_IDENTITY:-}"

usage() {
  cat <<'EOF'
Usage:
  tools/illustrator-aip/build-macos-aip.sh [--year YYYY] [--all] [--sdk-root PATH]

Options:
  --year YYYY      Build one SDK year from tools/illustrator-aip/sdk/mac_Adobe Illustrator YYYY SDK
  --all            Build every detected macOS SDK from 2020 through 2026
  --sdk-root PATH  Build from an explicit Illustrator SDK root

Outputs:
  tools/illustrator-aip/macos/YYYY/HopeFlow.aip
  tools/illustrator-aip/macos/HopeFlow.aip is refreshed from the newest built macOS output
EOF
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --all)
      ALL=1
      shift
      ;;
    --year)
      YEAR="${2:-}"
      shift 2
      ;;
    --year=*)
      YEAR="${1#--year=}"
      shift
      ;;
    --sdk-root)
      ILLUSTRATOR_SDK_ROOT="${2:-}"
      shift 2
      ;;
    --sdk-root=*)
      ILLUSTRATOR_SDK_ROOT="${1#--sdk-root=}"
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unknown option: $1" >&2
      usage >&2
      exit 2
      ;;
  esac
done

sdk_year_from_path() {
  local path="$1"
  if [[ "$path" =~ Adobe\ Illustrator\ ([0-9]{4})\ SDK ]]; then
    printf '%s\n' "${BASH_REMATCH[1]}"
  else
    printf 'default\n'
  fi
}

has_illustrator_sdk() {
  [ -f "$1/illustratorapi/illustrator/AIPlugin.h" ] && [ -d "$1/samplecode/ScriptMessage/ScriptMessage.xcodeproj" ]
}

find_macos_sdks() {
  local candidate
  candidate="$AIP_ROOT/sdk/AdobeIllustratorSDK"
  if has_illustrator_sdk "$candidate"; then
    printf '%s\n' "$candidate"
  fi

  local y
  for y in 2026 2025 2024 2023 2022 2021 2020; do
    candidate="$AIP_ROOT/sdk/mac_Adobe Illustrator $y SDK"
    if has_illustrator_sdk "$candidate"; then
      printf '%s\n' "$candidate"
    fi
  done
}

require_macos_tools() {
  if ! command -v xcodebuild >/dev/null 2>&1; then
    echo "xcodebuild was not found. Install Xcode or Xcode Command Line Tools on macOS." >&2
    exit 1
  fi
  if ! command -v python3 >/dev/null 2>&1; then
    echo "python3 was not found. It is required by the Illustrator SDK pipl tool." >&2
    exit 1
  fi
}

find_local_codesign_identity() {
  if [ -n "$MACOS_CODESIGN_IDENTITY" ]; then
    printf '%s\n' "$MACOS_CODESIGN_IDENTITY"
    return 0
  fi

  security find-identity -p codesigning -v 2>/dev/null \
    | awk -F '"' '/HopeFlow Local Code Signing/ { print $2; exit }'
}

sign_macos_aip_if_possible() {
  local aip="$1"
  local identity
  identity="$(find_local_codesign_identity || true)"
  if [ -z "$identity" ]; then
    return 0
  fi

  codesign --force --deep --sign "$identity" "$aip"
}

clear_macos_extended_attributes() {
  local path="$1"
  xattr -cr "$path" >/dev/null 2>&1 || true
}

patch_project() {
  local project_file="$1"

  python3 - "$project_file" <<'PY'
from pathlib import Path
import re
import sys

path = Path(sys.argv[1])
text = path.read_text()

text = text.replace(
    '6EE2BA530A40BB2600CC7CE2 /* ScriptMessage.aip */ = {isa = PBXFileReference; explicitFileType = wrapper.cfbundle; includeInIndex = 0; path = ScriptMessage.aip; sourceTree = BUILT_PRODUCTS_DIR; };',
    '6EE2BA530A40BB2600CC7CE2 /* HopeFlow.aip */ = {isa = PBXFileReference; explicitFileType = wrapper.cfbundle; includeInIndex = 0; path = HopeFlow.aip; sourceTree = BUILT_PRODUCTS_DIR; };'
)
text = text.replace('6EE2BA530A40BB2600CC7CE2 /* ScriptMessage.aip */', '6EE2BA530A40BB2600CC7CE2 /* HopeFlow.aip */')
text = text.replace('productName = ScriptMessage;', 'productName = HopeFlow;')
text = text.replace(
    'shellScript = "python3 ../../tools/pipl/create_pipl.py -input \'[{\\"name\\":\\"ScriptMessage\\",\\"entry_point\\" : \\"PluginMain\\"}]\' \\n";',
    'shellScript = "python3 ../../tools/pipl/create_pipl.py -input \'[{\\"name\\":\\"HopeFlow\\",\\"entry_point\\" : \\"PluginMain\\"}]\' \\n";'
)
text = text.replace(
    'shellScript = "python ../../tools/pipl/create_pipl.py -input \'[{\\"name\\":\\"ScriptMessage\\",\\"entry_point\\" : \\"PluginMain\\"}]\' \\n";',
    'shellScript = "python3 ../../tools/pipl/create_pipl.py -input \'[{\\"name\\":\\"HopeFlow\\",\\"entry_point\\" : \\"PluginMain\\"}]\' \\n";'
)
text = re.sub(
    r'shellScript = "python3? \.\./\.\./tools/pipl/create_pipl\.py -input \'.*?\' ?\\?n?";',
    'shellScript = "python3 ../../tools/pipl/create_pipl.py -input \'[{\\"name\\":\\"HopeFlow\\",\\"entry_point\\" : \\"PluginMain\\"}]\' \\\\n";',
    text
)

if 'A1B2C3D4E5F6000000000001 /* SmartGroupRunner.cpp in Sources */' not in text:
    text = text.replace(
        '/* End PBXBuildFile section */',
        '\t\tA1B2C3D4E5F6000000000001 /* SmartGroupRunner.cpp in Sources */ = {isa = PBXBuildFile; fileRef = A1B2C3D4E5F6000000000002 /* SmartGroupRunner.cpp */; };\n'
        '\t\tA1B2C3D4E5F6000000000003 /* SmartGroupRunner.h in Headers */ = {isa = PBXBuildFile; fileRef = A1B2C3D4E5F6000000000004 /* SmartGroupRunner.h */; };\n'
        '/* End PBXBuildFile section */'
    )

if 'path = Source/SmartGroupRunner.cpp;' not in text:
    text = text.replace(
        '/* End PBXFileReference section */',
        '\t\tA1B2C3D4E5F6000000000002 /* SmartGroupRunner.cpp */ = {isa = PBXFileReference; fileEncoding = 4; lastKnownFileType = sourcecode.cpp.cpp; name = SmartGroupRunner.cpp; path = Source/SmartGroupRunner.cpp; sourceTree = "<group>"; };\n'
        '\t\tA1B2C3D4E5F6000000000004 /* SmartGroupRunner.h */ = {isa = PBXFileReference; fileEncoding = 4; lastKnownFileType = sourcecode.c.h; name = SmartGroupRunner.h; path = Source/SmartGroupRunner.h; sourceTree = "<group>"; };\n'
        '\t\tA1B2C3D4E5F6000000000005 /* smart_group_core.hpp */ = {isa = PBXFileReference; fileEncoding = 4; lastKnownFileType = sourcecode.c.h; name = smart_group_core.hpp; path = Source/smart_group_core.hpp; sourceTree = "<group>"; };\n'
        '\t\tA1B2C3D4E5F6000000000006 /* smart_group_core.cpp */ = {isa = PBXFileReference; fileEncoding = 4; lastKnownFileType = sourcecode.cpp.cpp; name = smart_group_core.cpp; path = Source/smart_group_core.cpp; sourceTree = "<group>"; };\n'
        '/* End PBXFileReference section */'
    )

if 'A1B2C3D4E5F6000000000002 /* SmartGroupRunner.cpp */,' not in text:
    text = text.replace(
        '\t\t\t\t9E9C47001423A1FF004EA572 /* ScriptMessagePanelController.cpp */,\n',
        '\t\t\t\t9E9C47001423A1FF004EA572 /* ScriptMessagePanelController.cpp */,\n'
        '\t\t\t\tA1B2C3D4E5F6000000000002 /* SmartGroupRunner.cpp */,\n'
        '\t\t\t\tA1B2C3D4E5F6000000000004 /* SmartGroupRunner.h */,\n'
        '\t\t\t\tA1B2C3D4E5F6000000000005 /* smart_group_core.hpp */,\n'
        '\t\t\t\tA1B2C3D4E5F6000000000006 /* smart_group_core.cpp */,\n'
    )

if 'A1B2C3D4E5F6000000000003 /* SmartGroupRunner.h in Headers */,' not in text:
    text = text.replace(
        '\t\t\t\t9E9C47011423A1FF004EA572 /* ScriptMessagePanelController.h in Headers */,\n',
        '\t\t\t\t9E9C47011423A1FF004EA572 /* ScriptMessagePanelController.h in Headers */,\n'
        '\t\t\t\tA1B2C3D4E5F6000000000003 /* SmartGroupRunner.h in Headers */,\n'
    )

if 'A1B2C3D4E5F6000000000001 /* SmartGroupRunner.cpp in Sources */,' not in text:
    text = text.replace(
        '\t\t\t\t68B2247215063ED00035B025 /* SDKAboutPluginsHelper.cpp in Sources */,\n',
        '\t\t\t\t68B2247215063ED00035B025 /* SDKAboutPluginsHelper.cpp in Sources */,\n'
        '\t\t\t\tA1B2C3D4E5F6000000000001 /* SmartGroupRunner.cpp in Sources */,\n'
    )

# --- Data merge sources (DataMergeRunner.cpp + data_merge_core + ATE IText.cpp) ---
if 'A1B2C3D4E5F6000000000011 /* DataMergeRunner.cpp in Sources */' not in text:
    text = text.replace(
        '/* End PBXBuildFile section */',
        '\t\tA1B2C3D4E5F6000000000011 /* DataMergeRunner.cpp in Sources */ = {isa = PBXBuildFile; fileRef = A1B2C3D4E5F6000000000012 /* DataMergeRunner.cpp */; };\n'
        '\t\tA1B2C3D4E5F6000000000013 /* DataMergeRunner.h in Headers */ = {isa = PBXBuildFile; fileRef = A1B2C3D4E5F6000000000014 /* DataMergeRunner.h */; };\n'
        '\t\tA1B2C3D4E5F6000000000017 /* IText.cpp in Sources */ = {isa = PBXBuildFile; fileRef = A1B2C3D4E5F6000000000018 /* IText.cpp */; };\n'
        '\t\tA1B2C3D4E5F6000000000019 /* IThrowException.cpp in Sources */ = {isa = PBXBuildFile; fileRef = A1B2C3D4E5F600000000001A /* IThrowException.cpp */; };\n'
        '/* End PBXBuildFile section */'
    )

if 'path = Source/DataMergeRunner.cpp;' not in text:
    text = text.replace(
        '/* End PBXFileReference section */',
        '\t\tA1B2C3D4E5F6000000000012 /* DataMergeRunner.cpp */ = {isa = PBXFileReference; fileEncoding = 4; lastKnownFileType = sourcecode.cpp.cpp; name = DataMergeRunner.cpp; path = Source/DataMergeRunner.cpp; sourceTree = "<group>"; };\n'
        '\t\tA1B2C3D4E5F6000000000014 /* DataMergeRunner.h */ = {isa = PBXFileReference; fileEncoding = 4; lastKnownFileType = sourcecode.c.h; name = DataMergeRunner.h; path = Source/DataMergeRunner.h; sourceTree = "<group>"; };\n'
        '\t\tA1B2C3D4E5F6000000000015 /* data_merge_core.hpp */ = {isa = PBXFileReference; fileEncoding = 4; lastKnownFileType = sourcecode.c.h; name = data_merge_core.hpp; path = Source/data_merge_core.hpp; sourceTree = "<group>"; };\n'
        '\t\tA1B2C3D4E5F6000000000016 /* data_merge_core.cpp */ = {isa = PBXFileReference; fileEncoding = 4; lastKnownFileType = sourcecode.cpp.cpp; name = data_merge_core.cpp; path = Source/data_merge_core.cpp; sourceTree = "<group>"; };\n'
        '\t\tA1B2C3D4E5F6000000000018 /* IText.cpp */ = {isa = PBXFileReference; fileEncoding = 4; lastKnownFileType = sourcecode.cpp.cpp; name = IText.cpp; path = ../../illustratorapi/ate/IText.cpp; sourceTree = "<group>"; };\n'
        '\t\tA1B2C3D4E5F600000000001A /* IThrowException.cpp */ = {isa = PBXFileReference; fileEncoding = 4; lastKnownFileType = sourcecode.cpp.cpp; name = IThrowException.cpp; path = ../../illustratorapi/ate/IThrowException.cpp; sourceTree = "<group>"; };\n'
        '/* End PBXFileReference section */'
    )

if 'A1B2C3D4E5F6000000000012 /* DataMergeRunner.cpp */,' not in text:
    text = text.replace(
        '\t\t\t\tA1B2C3D4E5F6000000000006 /* smart_group_core.cpp */,\n',
        '\t\t\t\tA1B2C3D4E5F6000000000006 /* smart_group_core.cpp */,\n'
        '\t\t\t\tA1B2C3D4E5F6000000000012 /* DataMergeRunner.cpp */,\n'
        '\t\t\t\tA1B2C3D4E5F6000000000014 /* DataMergeRunner.h */,\n'
        '\t\t\t\tA1B2C3D4E5F6000000000015 /* data_merge_core.hpp */,\n'
        '\t\t\t\tA1B2C3D4E5F6000000000016 /* data_merge_core.cpp */,\n'
        '\t\t\t\tA1B2C3D4E5F6000000000018 /* IText.cpp */,\n'
        '\t\t\t\tA1B2C3D4E5F600000000001A /* IThrowException.cpp */,\n'
    )

if 'A1B2C3D4E5F6000000000013 /* DataMergeRunner.h in Headers */,' not in text:
    text = text.replace(
        '\t\t\t\tA1B2C3D4E5F6000000000003 /* SmartGroupRunner.h in Headers */,\n',
        '\t\t\t\tA1B2C3D4E5F6000000000003 /* SmartGroupRunner.h in Headers */,\n'
        '\t\t\t\tA1B2C3D4E5F6000000000013 /* DataMergeRunner.h in Headers */,\n'
    )

if 'A1B2C3D4E5F6000000000011 /* DataMergeRunner.cpp in Sources */,' not in text:
    text = text.replace(
        '\t\t\t\tA1B2C3D4E5F6000000000001 /* SmartGroupRunner.cpp in Sources */,\n',
        '\t\t\t\tA1B2C3D4E5F6000000000001 /* SmartGroupRunner.cpp in Sources */,\n'
        '\t\t\t\tA1B2C3D4E5F6000000000011 /* DataMergeRunner.cpp in Sources */,\n'
        '\t\t\t\tA1B2C3D4E5F6000000000017 /* IText.cpp in Sources */,\n'
        '\t\t\t\tA1B2C3D4E5F6000000000019 /* IThrowException.cpp in Sources */,\n'
    )

path.write_text(text)
PY
}

patch_common_diagnostics() {
  local suites_file="$1/samplecode/common/source/Suites.cpp"
  [ -f "$suites_file" ] || return 0

  python3 - "$suites_file" <<'PY'
from pathlib import Path
import sys

path = Path(sys.argv[1])
text = path.read_text()

text = text.replace(
    "\tkAINotifierSuite, kAINotifierSuiteVersion, &sAINotifier,\n",
    ""
)

if "HopeFlowLogSuiteAcquireFailure" not in text:
    text = text.replace(
        "#include <stdio.h>\n",
        "#include <stdio.h>\n#include <stdlib.h>\n"
    )
    text = text.replace(
        "extern \"C\" SPBasicSuite *sSPBasic;\n",
        """extern \"C\" SPBasicSuite *sSPBasic;

static void HopeFlowLogSuiteAcquireFailure(const char* suiteName, int version, ASErr error)
{
\tconst char* tempDir = getenv(\"TMPDIR\");
\tchar path[1024];
\tif (tempDir && tempDir[0])
\t\tsnprintf(path, sizeof(path), \"%shopeflow-smart-group-aip.log\", tempDir);
\telse
\t\tsnprintf(path, sizeof(path), \"/tmp/hopeflow-smart-group-aip.log\");
\tFILE* stream = fopen(path, \"a\");
\tif (!stream) return;
\tfprintf(stream, \"AcquireSuite failed: name=%s version=%d error=%ld\\\\n\", suiteName ? suiteName : \"(null)\", version, (long)error);
\tfclose(stream);
}
"""
    )
    text = text.replace(
        "\t}\n\treturn result;\n}\n\nASErr Suites::ReleaseSuites()",
        "\t}\n\tif (result) HopeFlowLogSuiteAcquireFailure(suite->name, suite->version, result);\n\treturn result;\n}\n\nASErr Suites::ReleaseSuites()"
    )

path.write_text(text)
PY
}

build_one_macos_aip() {
  local sdk_root="$1"
  local sdk_year="$2"
  local sample_dir="$sdk_root/samplecode/ScriptMessage"
  local project_file="$sample_dir/ScriptMessage.xcodeproj/project.pbxproj"
  if [ ! -f "$project_file" ]; then
    echo "Missing SDK ScriptMessage project: $project_file" >&2
    exit 1
  fi

  local work_dir="$WORK_ROOT/$sdk_year"
  local project_dir="$work_dir/samplecode/ScriptMessage"
  local output_aip
  if [ "$sdk_year" = "default" ]; then
    output_aip="$DEFAULT_OUTPUT_AIP"
  else
    output_aip="$OUTPUT_ROOT/$sdk_year/$AIP_FILE_NAME"
  fi

  rm -rf "$work_dir"
  mkdir -p "$work_dir" "$(dirname "$output_aip")"

  cp -R "$sdk_root/samplecode" "$work_dir/samplecode"
  cp -R "$sdk_root/tools" "$work_dir/tools"
  cp -R "$sdk_root/illustratorapi" "$work_dir/illustratorapi"
  patch_common_diagnostics "$work_dir"

  if [ -d "$AIP_ROOT/sdk/mac_Adobe Illustrator 2026 SDK/tools/pipl" ]; then
    rm -rf "$work_dir/tools/pipl"
    cp -R "$AIP_ROOT/sdk/mac_Adobe Illustrator 2026 SDK/tools/pipl" "$work_dir/tools/pipl"
  fi

  cp "$WINDOWS_SOURCE"/* "$project_dir/Source/"
  cp "$MACOS_SOURCE"/* "$project_dir/Source/"
  cp "$CORE_SOURCE/smart_group_core.hpp" "$project_dir/Source/smart_group_core.hpp"
  cp "$CORE_SOURCE/smart_group_core.cpp" "$project_dir/Source/smart_group_core.cpp"
  cp "$CORE_SOURCE/data_merge_core.hpp" "$project_dir/Source/data_merge_core.hpp"
  cp "$CORE_SOURCE/data_merge_core.cpp" "$project_dir/Source/data_merge_core.cpp"

  patch_project "$project_dir/ScriptMessage.xcodeproj/project.pbxproj"

  local build_archs="$MACOS_ARCHS"
  if [ "$sdk_year" = "2020" ] && [ "${MACOS_ARCHS:-arm64}" = "arm64" ]; then
    build_archs="x86_64"
  fi

  echo "Building macOS AIP with Illustrator SDK ${sdk_year}: $sdk_root"
  xcodebuild \
    -project "$project_dir/ScriptMessage.xcodeproj" \
    -target ScriptMessage \
    -configuration "$CONFIGURATION" \
    ARCHS="$build_archs" \
    ONLY_ACTIVE_ARCH=YES \
    SDKROOT=macosx \
    CODE_SIGNING_ALLOWED=NO \
    CODE_SIGNING_REQUIRED=NO \
    MACOSX_DEPLOYMENT_TARGET="$MACOSX_DEPLOYMENT_TARGET" \
    PRODUCT_NAME=HopeFlow \
    build

  local found
  found="$(find "$work_dir" -name "$AIP_FILE_NAME" -type d -print | sort | tail -n 1 || true)"
  if [ -z "$found" ]; then
    echo "Build finished but $AIP_FILE_NAME was not found for SDK $sdk_year." >&2
    exit 1
  fi

  rm -rf "$output_aip"
  cp -R "$found" "$output_aip"
  clear_macos_extended_attributes "$output_aip"
  sign_macos_aip_if_possible "$output_aip"
  echo "macOS AIP created: $output_aip"
}

require_macos_tools

sdks=()
if [ -n "$ILLUSTRATOR_SDK_ROOT" ]; then
  sdks+=("$ILLUSTRATOR_SDK_ROOT")
elif [ "$ALL" = "1" ]; then
  while IFS= read -r sdk; do
    [ "$(sdk_year_from_path "$sdk")" != "default" ] && sdks+=("$sdk")
  done < <(find_macos_sdks)
  elif [ -n "$YEAR" ]; then
    for candidate in "$AIP_ROOT/sdk/mac_Adobe Illustrator $YEAR SDK" "$AIP_ROOT/sdk/win_Adobe Illustrator $YEAR SDK"; do
      if has_illustrator_sdk "$candidate"; then
        sdks+=("$candidate")
        break
      fi
    done
else
  while IFS= read -r sdk; do
    sdks+=("$sdk")
    break
  done < <(find_macos_sdks)
fi

if [ "${#sdks[@]}" -eq 0 ]; then
  echo "Illustrator macOS SDK not found under $AIP_ROOT/sdk." >&2
  exit 1
fi

for sdk in "${sdks[@]}"; do
  if ! has_illustrator_sdk "$sdk"; then
    echo "Invalid Illustrator macOS SDK root: $sdk" >&2
    exit 1
  fi
  build_one_macos_aip "$sdk" "$(sdk_year_from_path "$sdk")"
done

latest="$(find "$OUTPUT_ROOT" -name "$AIP_FILE_NAME" -type d -print 2>/dev/null | sort | tail -n 1 || true)"
if [ -n "$latest" ]; then
  if [ "$latest" != "$DEFAULT_OUTPUT_AIP" ]; then
    rm -rf "$DEFAULT_OUTPUT_AIP"
    cp -R "$latest" "$DEFAULT_OUTPUT_AIP"
    clear_macos_extended_attributes "$DEFAULT_OUTPUT_AIP"
    sign_macos_aip_if_possible "$DEFAULT_OUTPUT_AIP"
  fi
fi
