const fs = require('fs');
const path = require('path');

const scriptsRoot = path.join(__dirname, '..', 'src', 'scripts');
const filesWithBom = [];

function scanDirectory(directory) {
  const entries = fs.readdirSync(directory, { withFileTypes: true });
  for (const entry of entries) {
    const filePath = path.join(directory, entry.name);
    if (entry.isDirectory()) {
      scanDirectory(filePath);
      continue;
    }
    if (!entry.isFile() || !entry.name.endsWith('.jsx')) continue;

    const header = fs.readFileSync(filePath).subarray(0, 3);
    if (header.length === 3 && header[0] === 0xef && header[1] === 0xbb && header[2] === 0xbf) {
      filesWithBom.push(path.relative(path.join(__dirname, '..'), filePath));
    }
  }
}

scanDirectory(scriptsRoot);

if (filesWithBom.length > 0) {
  console.error('JSX files must not start with UTF-8 BOM:');
  for (const filePath of filesWithBom) {
    console.error(`- ${filePath}`);
  }
  process.exit(1);
}
