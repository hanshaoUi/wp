#!/usr/bin/env bash
# HopeFlow 工具箱 macOS 一键安装器（双击运行）
# 也支持参数直通 install.sh，例如：./HopeFlow-Installer.command --check
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT_DIR"

clear
echo "=============================================="
echo " HopeFlow 工具箱 · macOS 安装器"
echo "=============================================="
echo
echo "即将为当前用户安装/更新 HopeFlow 工具箱。"
echo "建议先完全退出 Adobe Illustrator。"
echo

on_error() {
  echo
  echo "❌ 安装失败，请把上方的错误信息截图反馈。"
  echo
  read -r -p "按回车键关闭此窗口..."
}
trap on_error ERR

if [ ! -x "$ROOT_DIR/install.sh" ]; then
  chmod +x "$ROOT_DIR/install.sh" >/dev/null 2>&1 || true
fi

"$ROOT_DIR/install.sh" "$@"

trap - ERR
echo
read -r -p "按回车键关闭此窗口..."
