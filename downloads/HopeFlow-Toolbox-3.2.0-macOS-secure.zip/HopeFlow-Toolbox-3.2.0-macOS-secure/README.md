# HopeFlow Toolbox

> [!WARNING]
> 该项目目前暂时停止开发与维护，恢复时间未知。
> 现有代码与发布包仅保留作参考和按现状使用，不承诺后续更新、修复或兼容性维护。

HopeFlow Toolbox 是一款面向 Adobe Illustrator 生产场景的 CEP 插件，聚焦批量处理、画板管理、导出、测量、排版和重复性操作自动化。

当前稳定版：**v3.1.412**

## v3.1.412 更新内容

### 优化

- Windows 双击 `HopeFlow-Installer.bat` 后直接安装/更新，无需再进入图形界面点击安装。
- macOS 双击 `HopeFlow-Installer.command` 后直接开始安装/更新，不再要求先回车确认。
- 安装器会自动扫描本机 Illustrator 版本；如果检测到多个版本，默认安装到全部兼容目标。
- 图形浮雕 Native helper 现已兼容 macOS 与 Windows，发布包和安装脚本都会自动分发对应平台的 helper。
- macOS 安装脚本现在会优先完成 CEP 面板和图形浮雕 helper 安装；如果原生 AIP 需要额外权限或签名，只提示手动处理，不再中断整个安装流程。
- 同步更新 Windows 和 macOS 发布包版本号。

## v3.1.411 更新内容

### 新增

- 新增 macOS 原生 AIP 构建产物，智能编组可通过本地 AIP HTTP 接口执行边界框分组。
- 新增 macOS 一键安装入口：双击 `HopeFlow-Installer.command` 即可安装/更新。
- 新增 macOS 发布包脚本：`npm run package:macos`，生成 zip，并在 macOS 上同时生成 dmg。

### 优化

- macOS 安装脚本会同时检测 Illustrator 2021-2026 的用户 Plug-ins 目录。
- Windows/macOS 发布包会排除本地 Adobe SDK 和临时 AIP 构建目录，减少包体积并避免分发 SDK。

## v3.1.410 更新内容

### 新增

- **自动检查更新**：插件启动后会读取 GitHub Latest Release，比对当前 `APP_VERSION`，发现新版本时在主界面顶部显示更新提示。
- 设置页「关于」新增版本状态卡片，支持手动检查更新、打开下载页和“本版本不再提醒”。

### 说明

- v3.1.410 之后安装过带检查器的版本，后续新版本发布时才能在插件内收到提示。
- v3.1.409 及更早版本本身没有检查器，无法自动弹出升级到 v3.1.410 的插件内提示，仍需要通过 GitHub Watch Releases、RSS 或手动访问 Releases 页面获知本次更新。

## v3.1.409 更新内容

### 新增

- **智能排料优化** 接入 C++ helper：支持真实轮廓、多角度旋转、C++ 加速、自测脚本和打包自动编译。
- 智能排料面板新增快速 / 均衡 / 精细模式，以及 C++ 加速、真实轮廓、旋转、报告等常用开关。

### 优化

- Native helper 缺失或执行失败时，智能排料会自动回退到 JSX 排料路径，避免发布包或本机环境异常时直接中断。
- 图形浮雕工具去掉旧的 SCD 前缀，统一显示为 **图形浮雕**。
- Windows 发布包会在打包前自动构建智能排料 C++ helper，并把 `nesting_native.exe` 放入发布包。

### 文档

- 同步更新 `hopeflow-docs` 的更新日志、安装页、功能清单和版本更新 FAQ。

## v3.1.408 更新内容

### 优化

- AI 引擎改为按需启动，AI 功能入口新增统一状态展示和重试入口，减少打开插件时的后台干扰。
- 工具列表新增独立的“最近使用”入口，与“收藏夹”分离：收藏用于手动固定，最近使用用于自动历史回访。
- 扩展工具元数据和搜索匹配范围，补充执行类型、前置条件、风险等级、输出类型等信息，为后续校验和提示打基础。
- 设置页增强 API Key 管理，支持显示/隐藏、清空和本地存储风险提示。
- 新增工具注册表一致性校验脚本，检查 JSX 工具和独立面板入口是否匹配。

### 修复

- 修复“创建边界线”在剪切蒙版群组中错误按蒙版内部内容创建边界的问题，现在会优先使用剪切路径边界。
- 统一部分高频脚本的执行结果和错误返回，包括 PLT 导出、嵌入图片、打开 PDF、尺寸标注和印前角线等工具。

### 文档

- 补充任务导向推荐工作流，覆盖印前导出、批量画板、文字整理、图像处理和 AI 生成图。

## v3.1.407 更新内容

### 新增

- 新增 **图形浮雕** 工具，支持面板生成文字和平行线，也支持当前选区生成浮雕线效果。
- 增加图形浮雕 Native 加速工具源码和测试脚本，提升复杂轮廓采样与生成速度。

### 优化

- 图形浮雕面板支持预览、清除预览、应用、线条参数、浮雕模式、采样精度和平滑控制。
- 发布版本同步更新至 v3.1.407。

## v3.1.406 更新内容

### 开发中补充

- 补全 **批量绘制矩形** 工具说明，支持按 mm 宽度列表、多行、行列间距和填充开关生成矩形。
- 补全 **AI 色号产生器** 中文说明，脚本管理器可直接读取用途说明。
- 同步更新 `hopeflow-docs` 工具文档、首页工具清单与工具导航。

### 新增

- 新增 **导出画板尺寸表格** 独立面板：
  - 支持按画板或按尺寸分组。
  - 支持 mm、cm、in、pt、px 单位。
  - 支持 1:X 比例换算。
  - 支持 XLSX 和 CSV 导出。
  - XLSX 支持嵌入画板图示。
  - 支持成品面积、单价、金额列，金额可按公式自动计算。
  - 支持文档目录、桌面和弹窗选择导出目录。
- 新增 Windows 图形安装器：
  - `HopeFlow-Installer.bat` 提供安装、更新和卸载入口。
  - 用户电脑不再需要安装 Node.js 或执行构建命令。
  - 安装时自动写入 CEP 调试加载开关。
- 新增 Windows 发布包命令：`npm run package:windows`。

### 优化

- 画板尺寸表导出前自动保存当前 AI 文档。
- 图示导出改为临时 PNG 并写入 XLSX，避免 HTML 形式交付。
- XLSX 图示按原比例等比缩放，不再拉伸变形。
- 按画板创建矩形时，每次创建独立图层存放结果。
- 优化安装方式，安装脚本改为复制发布包，不再依赖 junction 链接。

### 修复

- 修复 CEP 环境中 ExcelJS `createWriteStream` / `readFile` 不可用导致 XLSX 写入失败的问题。
- 修复部分 Illustrator API 抛出 `PARM` 时导致整个画板尺寸表导出中断的问题。
- 修复当前目标图层不可编辑时“按画板创建矩形”失败的问题。

## 安装

### Windows

1. 关闭 Illustrator。
2. 双击 `HopeFlow-Toolbox-版本-Windows-Setup.exe`，或解压发布包后双击 `HopeFlow-Installer.bat`。
3. 等待安装完成，然后重启 Illustrator。
4. 在 Illustrator 中打开 `窗口 > 扩展 > HopeFlow Toolbox`。

安装器会自动：

- 安装 CEP 面板到当前用户的 `Adobe/CEP/extensions/com.hopeflow.toolbox`
- 按 Illustrator 版本安装对应的 Windows 原生 AIP
- 确保图形浮雕所需的 `graphic_relief_native.exe` 已包含在插件目录中

如果有多个兼容 Illustrator 版本，会安装到全部检测到的用户目标。

也可以使用命令行参数：

```bat
HopeFlow-Installer.bat -Check
HopeFlow-Installer.bat -Uninstall
```

### macOS

1. 关闭 Illustrator。
2. 打开 dmg 或解压 macOS 发布包。
3. 双击 `HopeFlow-Installer.command`。
4. 等待安装完成，然后重启 Illustrator。
5. 在 Illustrator 中打开 `窗口 > 扩展 > HopeFlow Toolbox`。

安装器会自动：

- 安装 CEP 面板到 `~/Library/Application Support/Adobe/CEP/extensions/com.hopeflow.toolbox`
- 安装图形浮雕所需的 `tools/graphic-relief-native/build/graphic_relief_native`
- 尝试把 macOS 原生 AIP 安装到 Illustrator 的 `Plug-ins.localized` 目录

如果本机已有本地代码签名证书或 AIP 目录可直接写入，脚本会自动继续处理；如果 AIP 安装需要管理员权限、手动签名或系统授权，脚本会给出提示，但不会阻断 CEP 面板和图形浮雕 helper 的安装。

也可以使用命令行：`./install.sh`

如果安装完成后图形浮雕仍提示 Native helper 未编译，可先确认下面这个文件是否存在：

```bash
~/Library/Application\ Support/Adobe/CEP/extensions/com.hopeflow.toolbox/tools/graphic-relief-native/build/graphic_relief_native
```

也可以直接运行自检：

```bash
"$HOME/Library/Application Support/Adobe/CEP/extensions/com.hopeflow.toolbox/tools/graphic-relief-native/build/graphic_relief_native" --self-test
```

## 开发

环境要求：

- Node.js 20+
- npm
- Adobe Illustrator 23.0 或更高版本（CEP / CSXS 9.0+）

当前 `CSXS/manifest.xml` 声明的支持范围：

- Illustrator Host：`ILST [23.0,99.9]`
- CSXS Runtime：`9.0`

Windows/macOS 安装器会安装 CEP 面板，并按平台分发对应的原生组件：

- 智能排料使用 `tools/nesting-native` 的 Windows helper
- 图形浮雕使用 `tools/graphic-relief-native` 的平台 helper
- 智能编组使用 `tools/illustrator-aip` 下的原生 AIP

AIP 原生插件支持说明：

- 当前仓库提供的原生 AIP 功能仅支持 Adobe Illustrator 2020-2026。
- Windows 包内的 Windows AIP 是 `tools/illustrator-aip/windows/YYYY/HopeFlow.aip`（按 Illustrator 年份分目录）。
- 安装器会按检测到的 Illustrator 年份安装对应 `windows/YYYY/HopeFlow.aip`；无匹配年份时回退到 `windows/` 下最新年份的 AIP。
- 当前 AIP 构建脚本会识别本地 2020-2026 SDK 目录；Windows 可运行 `npm run build:aip:windows:all` 或 `npm run package:windows:aip` 生成/打包多版本 AIP。
- 安装器会扫描 Illustrator 2020-2026 的常见用户 Plug-ins / 增效工具目录；如果 Adobe 后续版本仍兼容当前 AIP ABI，可继续安装，但发布说明中只承诺已验证版本。
- 只安装 CEP 面板时可在 Illustrator 23.0+ 使用；依赖原生 AIP 的智能分组能力以对应平台 AIP 是否安装成功为准。

Native helper 说明：

- `npm run package:macos` 会自动构建并打包 `graphic_relief_native`
- `npm run package:windows` 会自动构建并打包 `graphic_relief_native.exe`
- macOS `install.sh` 会在安装时自动构建或复制图形浮雕 helper 到 CEP 扩展目录
- Windows 安装器在发布包模式下会直接复制 `graphic_relief_native.exe`；开发源码模式下如果缺失，会尝试用 CMake 自动构建

常用命令：

```bash
npm install
npm run build
npm run typecheck
npm run package:windows
npm run package:windows:aip
npm run package:macos
```

## 项目结构

架构与实施规划文档：

- `docs/architecture/implementation-roadmap.md`：运行时分层、公共模块、AIP 边界、测试验证与验收路线图

```text
CSXS/                         CEP 清单
build/                        构建与发布脚本
docs/                         项目文档、维护记录和参考资料
docs/reference/               Illustrator 菜单/API 参考资料
src/                          面板源码、脚本注册与 Illustrator JSX 脚本
tools/installers/             安装器实现脚本
tools/illustrator-aip/        Windows/macOS 原生 AIP、源码和 SDK 说明
tools/nesting-native/         智能排料 Native helper 源码
tools/graphic-relief-native/  图形浮雕 Native helper 源码
HopeFlow-Installer.bat        Windows 一键安装入口
HopeFlow-Installer.command    macOS 一键安装入口
install.sh                    macOS 命令行安装入口
```

`dist/`、`release/`、`node_modules/`、`_local-archive/` 和各类原生 build 目录都是本地可再生产物或归档目录，不进入 Git。

## Illustrator SDK 与 AIP

原生 AIP 使用 Adobe Illustrator SDK 构建。SDK 文件属于 Adobe 专有内容，不提交到仓库。

```text
tools/illustrator-aip/sdk/AdobeIllustratorSDK/
tools/illustrator-aip/sdk/mac_Adobe Illustrator 2026 SDK/
tools/illustrator-aip/sdk/mac_Adobe Illustrator 2025 SDK/
tools/illustrator-aip/sdk/mac_Adobe Illustrator 2024 SDK/
tools/illustrator-aip/sdk/mac_Adobe Illustrator 2023 SDK/
tools/illustrator-aip/sdk/mac_Adobe Illustrator 2022 SDK/
tools/illustrator-aip/sdk/mac_Adobe Illustrator 2021 SDK/
tools/illustrator-aip/sdk/mac_Adobe Illustrator 2020 SDK/
tools/illustrator-aip/sdk/win_Adobe Illustrator 2026 SDK/
tools/illustrator-aip/sdk/win_Adobe Illustrator 2025 SDK/
tools/illustrator-aip/sdk/win_Adobe Illustrator 2024 SDK/
tools/illustrator-aip/sdk/win_Adobe Illustrator 2023 SDK/
tools/illustrator-aip/sdk/win_Adobe Illustrator 2022 SDK/
tools/illustrator-aip/sdk/win_Adobe Illustrator 2021 SDK/
tools/illustrator-aip/sdk/win_Adobe Illustrator 2020 SDK/
```

当前验证目标是 Adobe Illustrator 2026 SDK；如果本地保留 2020-2026 多个 SDK，统一放在 `tools/illustrator-aip/sdk/` 下并按年份命名。也可以在 CMake 中通过 `ILLUSTRATOR_SDK_ROOT` 指定自定义 SDK 路径。详细说明见 `tools/illustrator-aip/README.md` 和 `tools/illustrator-aip/sdk/README.md`。

## 文档

- 文档站点：[https://hanshaoui.github.io/hopeflow-docs/](https://hanshaoui.github.io/hopeflow-docs/)
- 仓库：[https://github.com/hanshaoUi/hopeflow-toolbox](https://github.com/hanshaoUi/hopeflow-toolbox)
- Releases：[https://github.com/hanshaoUi/hopeflow-toolbox/releases](https://github.com/hanshaoUi/hopeflow-toolbox/releases)

## 推荐工作流

- 印前导出：先保存文档，再使用“导出画板尺寸表格”“导出生产 PDF”“导出 PLT”等工具；涉及文件写入的工具会在面板中标记为“导文件”。
- 批量画板：使用画板选择、按画板分组、批量重命名和尺寸表导出完成交付前检查。
- 文字整理：使用字体选择、查找替换、文本样式规则、自动编号和转曲工具；需要选区的工具会显示“需选区”。
- 图像处理：使用嵌入图片、打开 PDF、图像矢量化、AI 图像增强等工具；AI 功能需要手动启动本机引擎。
- AI 生成图：先在设置中配置可信 image2 接口和 API Key，再使用“AI 生成图”；API Key 保存在本机插件设置中，截图或导出配置前请隐藏或清空。

## License

MIT
