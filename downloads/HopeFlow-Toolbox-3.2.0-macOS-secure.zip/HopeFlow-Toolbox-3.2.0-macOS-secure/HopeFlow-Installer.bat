@echo off
rem HopeFlow 工具箱 Windows 一键安装器（双击运行）
rem 也支持命令行参数直通，例如：HopeFlow-Installer.bat -Uninstall / -Check
setlocal EnableExtensions
chcp 65001 >nul 2>&1

set "ROOT_DIR=%~dp0"
set "INSTALLER=%ROOT_DIR%tools\installers\windows-installer.ps1"

if /I "%~1"=="/?" goto :help
if /I "%~1"=="-h" goto :help
if /I "%~1"=="--help" goto :help

if not exist "%INSTALLER%" (
    echo [错误] 找不到安装程序：
    echo "%INSTALLER%"
    echo 请确认发布包完整（不要单独拷贝此文件）。
    pause
    exit /b 1
)

echo ==============================================
echo  HopeFlow 工具箱 · Windows 安装器
echo ==============================================
echo.
echo 即将为当前用户安装/更新 HopeFlow 工具箱。
echo 建议先完全退出 Adobe Illustrator。
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%INSTALLER%" %*
set "EXIT_CODE=%ERRORLEVEL%"

echo.
if not "%EXIT_CODE%"=="0" (
    echo [错误] 安装失败（错误码 %EXIT_CODE%），请把上方信息截图反馈。
    pause
    exit /b %EXIT_CODE%
)

echo ==============================================
echo  ✅ 安装完成
echo.
echo  下一步：
echo   1. 重启 Adobe Illustrator
echo   2. 菜单：窗口 ^> 扩展 (Extensions)
echo   3. 打开「HopeFlow 工具箱」主面板
echo      （画板/对象/收藏/脚本子面板也在同一菜单中）
echo ==============================================
pause
exit /b 0

:help
echo HopeFlow 工具箱安装器
echo.
echo 用法：
echo   HopeFlow-Installer.bat             安装/更新
echo   HopeFlow-Installer.bat -Uninstall  卸载
echo   HopeFlow-Installer.bat -Check      仅检查安装包
echo.
pause
exit /b 0
