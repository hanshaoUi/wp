from __future__ import annotations

import struct
from typing import NamedTuple, cast


SpotCmyk = tuple[float, float, float, float]


class PhotoshopLayerStreamLayout(NamedTuple):
    prefix: bytes
    suffix: bytes
    uncompressed_length: int


def normalize_spot_cmyk(values: tuple[float, ...]) -> SpotCmyk:
    padded = (*values[:4], 0.0, 0.0, 0.0, 1.0)
    return cast(SpotCmyk, tuple(max(0.0, min(1.0, float(value))) for value in padded[:4]))


def _pad(data: bytes, multiple: int) -> bytes:
    return data + (b"\0" * (-len(data) % multiple))


def _photoshop_unicode_string(text: str) -> bytes:
    # Adobe Unicode string: a 4-byte character count that INCLUDES the trailing
    # NUL, followed by UTF-16BE data plus that NUL. Photoshop derives the visible
    # length as count-1, so omitting the terminator drops the final character
    # (e.g. a channel named "W1" reads back as "W").
    return struct.pack(">I", len(text) + 1) + text.encode("utf-16-be") + b"\0\0"


def _image_resource(resource_id: int, data: bytes) -> bytes:
    return b"8BIM" + struct.pack(">H", resource_id) + b"\0\0" + struct.pack(">I", len(data)) + _pad(data, 2)


def _display_components(cmyk: SpotCmyk) -> tuple[int, int, int, int]:
    return cast(tuple[int, int, int, int], tuple(round(component * 65535) for component in cmyk))


def photoshop_tiff_image_resources(spot_name: str, spot_cmyk: SpotCmyk) -> bytes:
    legacy_name = spot_name.encode("ascii", errors="replace")[:255]
    alpha_names = bytes((len(legacy_name),)) + legacy_name
    unicode_name = _photoshop_unicode_string(spot_name)
    display_info = struct.pack(">H4HHBB", 2, *_display_components(spot_cmyk), 100, 2, 0)
    return b"".join(
        (
            _image_resource(1006, alpha_names),
            _image_resource(1045, unicode_name),
            _image_resource(1007, display_info),
        )
    )


def _photoshop_block(key: bytes, data: bytes) -> bytes:
    return b"8BIM" + key + struct.pack(">I", len(data)) + _pad(data, 4)


def photoshop_alpha_data(spot_name: str, spot_cmyk: SpotCmyk) -> bytes:
    unicode_name = _photoshop_unicode_string(spot_name)
    record = b"".join(
        (
            struct.pack(">II", 4, 0xFFFFFFFF),
            _photoshop_block(b"name", unicode_name),
            _photoshop_block(b"kind", b"8BIMspot"),
            _photoshop_block(b"opac", b"\0"),
            _photoshop_block(b"colr", struct.pack(">H4H", 2, *_display_components(spot_cmyk))),
            _photoshop_block(b"id  ", struct.pack(">I", 3)),
        )
    )
    return struct.pack(">III", 5, 1, len(record)) + record


def photoshop_layer_stream_layout(
    width: int,
    height: int,
    spot_name: str,
    spot_cmyk: SpotCmyk,
) -> PhotoshopLayerStreamLayout:
    pixel_count = width * height
    channel_length = pixel_count + 2
    channel_records = b"".join(struct.pack(">hI", channel, channel_length) for channel in range(4))
    layer_name = _pad(b"\x07Layer 1", 4)
    extra_data = struct.pack(">I", 0) + struct.pack(">I", 0) + layer_name
    layer_record = b"".join(
        (
            struct.pack(">iiiiH", 0, 0, height, width, 4),
            channel_records,
            b"8BIMnorm",
            bytes((255, 0, 8, 0)),
            struct.pack(">I", len(extra_data)),
            extra_data,
        )
    )
    layer_prefix = struct.pack(">h", 1) + layer_record
    layer_length = len(layer_prefix) + (channel_length * 4)
    prefix = b"8BIMLayr" + struct.pack(">I", layer_length) + layer_prefix
    layer_padding = b"\0" * (-layer_length % 4)
    global_mask = bytes.fromhex("0000ffff00000000000000328000")
    suffix = b"".join(
        (
            layer_padding,
            _photoshop_block(b"LMsk", global_mask),
            _photoshop_block(b"Patt", b""),
            _photoshop_block(b"Alph", photoshop_alpha_data(spot_name, spot_cmyk)),
        )
    )
    return PhotoshopLayerStreamLayout(
        prefix=prefix,
        suffix=suffix,
        uncompressed_length=len(prefix) + (channel_length * 4) + len(suffix),
    )
