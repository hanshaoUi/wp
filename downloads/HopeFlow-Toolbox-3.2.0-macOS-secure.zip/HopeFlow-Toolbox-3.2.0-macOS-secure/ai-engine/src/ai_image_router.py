from __future__ import annotations

import base64
import binascii
import json
import mimetypes
import uuid
from io import BytesIO
from pathlib import Path
from typing import Any, Dict, List, Optional, Union
from urllib import error, request

from fastapi import APIRouter
from pydantic import BaseModel, Field
from PIL import Image, UnidentifiedImageError

from ai_image_config import AiImageConfigurationError, load_ai_image_runtime_config


DEFAULT_BASE_URL = "https://toloveu.asia/v1"
DEFAULT_MODEL = "gpt-image-2"
# Hard cap on how many images we forward upstream (1 base edit image + 8 references).
MAX_INPUT_IMAGES = 9
router = APIRouter()
JsonValue = Union[None, bool, int, float, str, List["JsonValue"], Dict[str, "JsonValue"]]
JsonObject = Dict[str, JsonValue]


class AiImageRequest(BaseModel):
    prompt: str = Field(min_length=1)
    model: str = DEFAULT_MODEL
    # Which configured platform to use (provider id or name); empty = active provider.
    provider: Optional[str] = None
    size: str = "1024x1024"
    n: int = Field(default=1, ge=1, le=4)
    quality: Optional[str] = None
    # Base image to edit (kept single). References are additional guidance images.
    edit_image: Optional[str] = None
    reference_image: Optional[str] = None  # legacy single-reference field, still honoured
    reference_images: List[str] = Field(default_factory=list)
    # Arbitrary passthrough params for gateway-specific options (seed, style, ...).
    extra: Optional[Dict[str, Any]] = None
    grant: Optional[str] = ""
    feature: Optional[str] = "ai-image"
    site_base_url: Optional[str] = ""


class AiImageResponse(BaseModel):
    success: bool
    output: Optional[str] = None
    outputs: List[str] = Field(default_factory=list)
    error: Optional[str] = None


class AiImageModelsResponse(BaseModel):
    success: bool
    models: List[str] = Field(default_factory=list)
    error: Optional[str] = None


class AiImageUpstreamError(RuntimeError):
    pass


def _auth_headers(api_key: str, extra: Optional[Dict[str, str]] = None) -> Dict[str, str]:
    headers = {"Authorization": f"Bearer {api_key}"}
    if extra:
        headers.update(extra)
    return headers


def _request_json(endpoint: str, payload: JsonObject, api_key: str, base_url: str) -> JsonObject:
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    upstream_request = request.Request(
        f"{base_url}{endpoint}",
        data=body,
        headers=_auth_headers(api_key, {"Content-Type": "application/json"}),
        method="POST",
    )
    return _open_json(upstream_request)


def _get_json(endpoint: str, api_key: str, base_url: str) -> JsonObject:
    upstream_request = request.Request(
        f"{base_url}{endpoint}",
        headers=_auth_headers(api_key),
        method="GET",
    )
    return _open_json(upstream_request)


def _extra_string_fields(extra: Optional[Dict[str, JsonValue]]) -> Dict[str, str]:
    """Flatten passthrough params into multipart string fields (non-scalars become JSON)."""
    fields: Dict[str, str] = {}
    if not extra:
        return fields
    for key, value in extra.items():
        if isinstance(value, bool):
            fields[key] = "true" if value else "false"
        elif isinstance(value, (int, float, str)):
            fields[key] = str(value)
        elif value is None:
            continue
        else:
            fields[key] = json.dumps(value, ensure_ascii=False)
    return fields


def _multipart_body(fields: dict[str, str], image_paths: list[Path], image_field: str = "image[]") -> tuple[bytes, str]:
    boundary = f"hopeflow-{uuid.uuid4().hex}"
    chunks: list[bytes] = []
    for name, value in fields.items():
        chunks.extend(
            [
                f"--{boundary}\r\n".encode("ascii"),
                f'Content-Disposition: form-data; name="{name}"\r\n\r\n'.encode("ascii"),
                value.encode("utf-8"),
                b"\r\n",
            ]
        )
    for image_path in image_paths:
        mime_type = mimetypes.guess_type(image_path.name)[0] or "application/octet-stream"
        chunks.extend(
            [
                f"--{boundary}\r\n".encode("ascii"),
                (
                    f'Content-Disposition: form-data; name="{image_field}"; filename="{image_path.name}"\r\n'
                    f"Content-Type: {mime_type}\r\n\r\n"
                ).encode("utf-8"),
                image_path.read_bytes(),
                b"\r\n",
            ]
        )
    chunks.append(f"--{boundary}--\r\n".encode("ascii"))
    return b"".join(chunks), f"multipart/form-data; boundary={boundary}"


def _request_edit(req: AiImageRequest, image_paths: list[Path], api_key: str, base_url: str) -> JsonObject:
    fields: Dict[str, str] = {
        "model": req.model or DEFAULT_MODEL,
        "prompt": req.prompt,
        "n": str(req.n),
    }
    if req.size and req.size != "auto":
        fields["size"] = req.size
    if req.quality:
        fields["quality"] = req.quality
    fields.update(_extra_string_fields(req.extra))

    # Single image keeps the plain `image` field (widest gateway compatibility);
    # multiple images use `image[]` as per the OpenAI multi-image edit contract.
    image_field = "image" if len(image_paths) == 1 else "image[]"
    body, content_type = _multipart_body(fields, image_paths, image_field)
    upstream_request = request.Request(
        f"{base_url}/images/edits",
        data=body,
        headers=_auth_headers(api_key, {"Content-Type": content_type}),
        method="POST",
    )
    return _open_json(upstream_request)


def _generation_payload(req: AiImageRequest) -> JsonObject:
    payload: JsonObject = {
        "model": req.model or DEFAULT_MODEL,
        "prompt": req.prompt,
        "n": req.n,
    }
    if req.size:
        payload["size"] = req.size
    if req.quality:
        payload["quality"] = req.quality
    if req.extra:
        for key, value in req.extra.items():
            payload[key] = value
    return payload


def _open_json(upstream_request: request.Request) -> JsonObject:
    try:
        with request.urlopen(upstream_request, timeout=300) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except error.HTTPError as exc:
        details = exc.read().decode("utf-8", errors="replace")
        raise AiImageUpstreamError(f"Upstream returned HTTP {exc.code}: {details}") from exc
    except error.URLError as exc:
        raise AiImageUpstreamError(f"Cannot reach AI image upstream: {exc.reason}") from exc
    except json.JSONDecodeError as exc:
        raise AiImageUpstreamError("AI image upstream returned invalid JSON.") from exc
    if not isinstance(payload, dict):
        raise AiImageUpstreamError("AI image upstream returned an invalid response object.")
    return payload


def _input_images(req: AiImageRequest) -> list[Path]:
    raw: list[str] = []
    if req.edit_image:
        raw.append(req.edit_image)
    raw.extend(value for value in (req.reference_images or []) if value)
    if req.reference_image:
        raw.append(req.reference_image)

    seen: set[str] = set()
    image_paths: list[Path] = []
    for value in raw:
        if value in seen:
            continue
        seen.add(value)
        path = Path(value)
        if not path.is_file():
            raise AiImageConfigurationError(f"Image input does not exist: {path}")
        image_paths.append(path)
    if len(image_paths) > MAX_INPUT_IMAGES:
        raise AiImageConfigurationError(f"At most {MAX_INPUT_IMAGES} input images are supported.")
    return image_paths


def _result_bytes(item: JsonObject) -> bytes:
    encoded = item.get("b64_json") or item.get("b64")
    if isinstance(encoded, str) and encoded:
        try:
            return base64.b64decode(encoded, validate=True)
        except (binascii.Error, ValueError) as exc:
            raise AiImageUpstreamError("AI image upstream returned invalid base64 image data.") from exc

    image_url = item.get("url")
    if isinstance(image_url, str) and image_url:
        try:
            with request.urlopen(image_url, timeout=120) as response:
                return response.read()
        except error.URLError as exc:
            raise AiImageUpstreamError(f"Cannot download generated image: {exc.reason}") from exc
    raise AiImageUpstreamError("AI image upstream returned neither b64 image data nor a URL.")


def _save_png(image_bytes: bytes) -> str:
    # 存到持久目录（而非系统临时目录），避免历史缩略图被系统清理/重启后消失。
    output_dir = Path.home() / ".hopeflow" / "ai-images"
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / f"ai-image-{uuid.uuid4().hex}.png"
    try:
        with Image.open(BytesIO(image_bytes)) as image:
            image.convert("RGBA").save(output_path, "PNG")
    except (UnidentifiedImageError, OSError) as exc:
        raise AiImageUpstreamError("AI image upstream returned an unreadable image.") from exc
    return str(output_path)


def _persist_results(payload: JsonObject) -> list[str]:
    data = payload.get("data")
    if not isinstance(data, list) or not data:
        raise AiImageUpstreamError("AI image upstream returned no image results.")
    outputs: list[str] = []
    for item in data:
        if not isinstance(item, dict):
            raise AiImageUpstreamError("AI image upstream returned an invalid image result.")
        outputs.append(_save_png(_result_bytes(item)))
    return outputs


def _is_image_model(model_id: str) -> bool:
    keywords = (
        "image", "flux", "sd", "sdxl", "dall", "banana", "imagine", "seedream",
        "seededit", "mj", "midjourney", "kling", "ideogram", "recraft", "qwen-image",
        "wan", "hunyuan", "cogview", "draw", "paint", "irag", "gpt-image",
    )
    lowered = model_id.lower()
    return any(keyword in lowered for keyword in keywords)


@router.get("/ai_image/models")
def ai_image_models(provider: Optional[str] = None) -> AiImageModelsResponse:
    try:
        config = load_ai_image_runtime_config(DEFAULT_BASE_URL, provider=provider)
        payload = _get_json("/models", config.api_key, config.base_url)
        data = payload.get("data")
        if not isinstance(data, list):
            raise AiImageUpstreamError("Model list upstream returned no data array.")
        ids = [
            item["id"]
            for item in data
            if isinstance(item, dict) and isinstance(item.get("id"), str) and item["id"]
        ]
        # Surface likely image models first, but keep every model available.
        image_models = sorted(m for m in ids if _is_image_model(m))
        other_models = sorted(m for m in ids if not _is_image_model(m))
        return AiImageModelsResponse(success=True, models=image_models + other_models)
    except (AiImageConfigurationError, AiImageUpstreamError, OSError) as exc:
        return AiImageModelsResponse(success=False, error=str(exc))


@router.post("/ai_image")
def ai_image(req: AiImageRequest) -> AiImageResponse:
    try:
        config = load_ai_image_runtime_config(DEFAULT_BASE_URL, provider=req.provider)
        image_paths = _input_images(req)
        if image_paths:
            upstream_payload = _request_edit(req, image_paths, config.api_key, config.base_url)
        else:
            upstream_payload = _request_json(
                "/images/generations",
                _generation_payload(req),
                config.api_key,
                config.base_url,
            )
        outputs = _persist_results(upstream_payload)
        return AiImageResponse(success=True, output=outputs[0], outputs=outputs)
    except (AiImageConfigurationError, AiImageUpstreamError, OSError) as exc:
        return AiImageResponse(success=False, error=str(exc))
