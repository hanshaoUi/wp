from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Literal

import numpy as np
import tifffile
from fastapi import APIRouter
from numpy.typing import NDArray
from PIL import Image, UnidentifiedImageError
from pydantic import BaseModel, ConfigDict, Field
from spot_tiff_writer import TIFF_CHANNELS, SpotTiffWriteSpec, write_spot_tiff

router = APIRouter()


class SpotTiffTile(BaseModel):
    model_config = ConfigDict(frozen=True)

    process: str
    mask: str
    x: int = Field(ge=0)
    y: int = Field(ge=0)
    width: int = Field(gt=0)
    height: int = Field(gt=0)
    crop_x: int = Field(default=0, ge=0)
    crop_y: int = Field(default=0, ge=0)
    crop_width: int = Field(default=0, ge=0)
    crop_height: int = Field(default=0, ge=0)


class SpotTiffRequest(BaseModel):
    model_config = ConfigDict(frozen=True, str_strip_whitespace=True)

    output: str = Field(min_length=1)
    spot_name: str = Field(min_length=1, max_length=64)
    dpi: int = Field(gt=0, le=2400)
    width: int = Field(gt=0)
    height: int = Field(gt=0)
    tiles: tuple[SpotTiffTile, ...] = Field(min_length=1)


class SpotTiffResponse(BaseModel):
    model_config = ConfigDict(frozen=True)

    success: bool
    output: str = ""
    width_px: int = 0
    height_px: int = 0
    spot_name: str = ""
    compression: Literal["none"] = "none"
    error: str = ""


@dataclass(frozen=True)
class SpotTiffError(Exception):
    reason: Literal[
        "missing-input",
        "invalid-process-tile",
        "tile-size-mismatch",
        "tile-out-of-bounds",
    ]
    detail: str = ""

    def __str__(self) -> str:
        messages = {
            "missing-input": "找不到 TIFF 分片或专色蒙版",
            "invalid-process-tile": "专色 TIFF 需要四通道 CMYK 分片",
            "tile-size-mismatch": "CMYK 分片与专色蒙版尺寸不一致",
            "tile-out-of-bounds": "专色 TIFF 分片超出目标画布",
        }
        suffix = f": {self.detail}" if self.detail else ""
        return f"{messages[self.reason]}{suffix}"


def _read_tile(tile: SpotTiffTile) -> tuple[NDArray[np.uint8], NDArray[np.uint8]]:
    process_path = Path(tile.process)
    mask_path = Path(tile.mask)
    if not process_path.is_file() or not mask_path.is_file():
        raise SpotTiffError("missing-input")

    process = np.asarray(tifffile.imread(process_path), dtype=np.uint8)
    if process.ndim != 3 or process.shape[2] != 4:
        raise SpotTiffError("invalid-process-tile", str(process.shape))

    with Image.open(mask_path) as image:
        mask = np.asarray(image.convert("RGBA").getchannel("A"), dtype=np.uint8)
    if process.shape[:2] != mask.shape:
        raise SpotTiffError("tile-size-mismatch")
    return process, mask


def render_spot_tiff(request: SpotTiffRequest) -> SpotTiffResponse:
    try:
        with TemporaryDirectory(prefix="hf-spot-tiff-") as temporary_directory:
            memory_path = Path(temporary_directory) / "pixels.bin"
            canvas = np.memmap(
                memory_path,
                mode="w+",
                dtype=np.uint8,
                shape=(request.height, request.width, TIFF_CHANNELS),
            )
            canvas[:] = 0
            for tile in request.tiles:
                process, mask = _read_tile(tile)
                crop_width = tile.crop_width or tile.width
                crop_height = tile.crop_height or tile.height
                target_right = tile.x + crop_width
                target_bottom = tile.y + crop_height
                if target_right > request.width or target_bottom > request.height:
                    raise SpotTiffError("tile-out-of-bounds")
                source_right = tile.crop_x + crop_width
                source_bottom = tile.crop_y + crop_height
                if source_right > process.shape[1] or source_bottom > process.shape[0]:
                    raise SpotTiffError("tile-out-of-bounds")

                target = canvas[tile.y:target_bottom, tile.x:target_right]
                target[:, :, :4] = process[tile.crop_y:source_bottom, tile.crop_x:source_right]
                target[:, :, 4] = mask[tile.crop_y:source_bottom, tile.crop_x:source_right]
            canvas.flush()
            write_spot_tiff(
                SpotTiffWriteSpec(
                    output=request.output,
                    spot_name=request.spot_name,
                    dpi=request.dpi,
                    width=request.width,
                    height=request.height,
                ),
                canvas,
            )
            del canvas
        return SpotTiffResponse(
            success=True,
            output=request.output,
            width_px=request.width,
            height_px=request.height,
            spot_name=request.spot_name,
        )
    except SpotTiffError as error:
        return SpotTiffResponse(success=False, error=str(error))
    except (OSError, ValueError, tifffile.TiffFileError, UnidentifiedImageError) as error:
        return SpotTiffResponse(success=False, error=f"专色 TIFF 编码失败: {error}")


@router.post("/spot_tiff")
def spot_tiff(request: SpotTiffRequest) -> SpotTiffResponse:
    return render_spot_tiff(request)
