from __future__ import annotations

import html
import os
import shutil
import tempfile
import zlib
from datetime import datetime
from pathlib import Path
from typing import BinaryIO, Iterable, NamedTuple

import numpy as np
from numpy.typing import NDArray

from photoshop_spot_metadata import SpotCmyk, normalize_spot_cmyk, photoshop_layer_stream_layout


STREAM_ROWS = 256
PHOTOSHOP_PRODUCER = "Adobe Photoshop for Macintosh -- Image Conversion Plug-in"


class SpotPdfWriteSpec(NamedTuple):
    output: str
    spot_name: str
    dpi: int
    width: int
    height: int
    page_width_pt: float
    page_height_pt: float
    spot_cmyk: SpotCmyk = (0.0, 0.0, 0.0, 1.0)


class _StreamingPdfWriter:
    def __init__(self, stream: BinaryIO) -> None:
        self._stream = stream
        self._offsets = [0]
        self._stream.write(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")

    def add_object(self, number: int, body: bytes) -> None:
        if number != len(self._offsets):
            raise ValueError(f"expected PDF object {len(self._offsets)}, received {number}")
        self._offsets.append(self._stream.tell())
        self._stream.write(f"{number} 0 obj\n".encode("ascii"))
        self._stream.write(body)
        self._stream.write(b"\nendobj\n")

    def add_stream(self, number: int, dictionary: bytes, source: Path) -> None:
        length = source.stat().st_size
        header = b"<<\n" + dictionary + f"\n/Length {length}\n>>\nstream\n".encode("ascii")
        if number != len(self._offsets):
            raise ValueError(f"expected PDF object {len(self._offsets)}, received {number}")
        self._offsets.append(self._stream.tell())
        self._stream.write(f"{number} 0 obj\n".encode("ascii"))
        self._stream.write(header)
        with source.open("rb") as source_stream:
            shutil.copyfileobj(source_stream, self._stream, length=1024 * 1024)
        self._stream.write(b"\nendstream\nendobj\n")

    def finish(self, root: int, info: int) -> None:
        xref_offset = self._stream.tell()
        self._stream.write(f"xref\n0 {len(self._offsets)}\n".encode("ascii"))
        self._stream.write(b"0000000000 65535 f \n")
        for offset in self._offsets[1:]:
            self._stream.write(f"{offset:010d} 00000 n \n".encode("ascii"))
        self._stream.write(
            f"trailer\n<< /Size {len(self._offsets)} /Root {root} 0 R /Info {info} 0 R >>\n"
            f"startxref\n{xref_offset}\n%%EOF\n".encode("ascii")
        )


def _compressed_file(path: Path, chunks: Iterable[bytes]) -> None:
    compressor = zlib.compressobj(level=6)
    with path.open("wb") as stream:
        for chunk in chunks:
            encoded = compressor.compress(chunk)
            if encoded:
                stream.write(encoded)
        stream.write(compressor.flush())


def _process_chunks(pixels: NDArray[np.uint8], height: int) -> Iterable[bytes]:
    for top in range(0, height, STREAM_ROWS):
        yield np.ascontiguousarray(pixels[top:min(top + STREAM_ROWS, height), :, :4]).tobytes()


def _spot_chunks(pixels: NDArray[np.uint8], height: int) -> Iterable[bytes]:
    for top in range(0, height, STREAM_ROWS):
        channel = np.ascontiguousarray(pixels[top:min(top + STREAM_ROWS, height), :, 4])
        yield np.bitwise_not(channel).tobytes()


def _layer_chunks(
    pixels: NDArray[np.uint8],
    height: int,
    prefix: bytes,
    suffix: bytes,
) -> Iterable[bytes]:
    yield prefix
    for channel_index in range(4):
        yield b"\0\0"
        for top in range(0, height, STREAM_ROWS):
            channel = np.ascontiguousarray(
                pixels[top:min(top + STREAM_ROWS, height), :, channel_index]
            )
            yield np.bitwise_not(channel).tobytes()
    yield suffix


def _pdf_name(value: str) -> bytes:
    safe = b"!$&'*+,-.0123456789:;=?@ABCDEFGHIJKLMNOPQRSTUVWXYZ^_`abcdefghijklmnopqrstuvwxyz|~"
    return b"/" + b"".join(
        bytes((byte,)) if byte in safe else f"#{byte:02X}".encode("ascii")
        for byte in value.encode("utf-8")
    )


def _pdf_string(value: str) -> bytes:
    encoded = value.encode("utf-8")
    escaped = bytearray(b"(")
    for byte in encoded:
        if byte in (40, 41, 92):
            escaped.extend(b"\\" + bytes((byte,)))
        elif byte < 32 or byte > 126:
            escaped.extend(f"\\{byte:03o}".encode("ascii"))
        else:
            escaped.append(byte)
    return bytes(escaped + b")")


def _number(value: float) -> str:
    return f"{value:.6f}".rstrip("0").rstrip(".") or "0"


def _write_document(
    output: Path,
    spec: SpotPdfWriteSpec,
    spot_cmyk: SpotCmyk,
    process_stream: Path,
    spot_stream: Path,
    layer_stream: Path,
    layer_length: int,
    workdir: Path,
) -> None:
    lookup_stream = workdir / "lookup.bin"
    content_stream = workdir / "content.bin"
    resource_stream = workdir / "resources.bin"
    metadata_stream = workdir / "metadata.bin"
    _compressed_file(lookup_stream, (bytes(range(255, -1, -1)),))
    spot_utf16 = (b"\xfe\xff" + spec.spot_name.encode("utf-16-be")).hex().upper()
    width_pt = _number(spec.page_width_pt)
    height_pt = _number(spec.page_height_pt)
    content = (
        f"/MultiChannelImage <</MainChannel /CMYKColorMode /Spot [<{spot_utf16}>]>>BDC\n"
        f"/SeparationImages BMC\n/SpotImage <</Ink <{spot_utf16}>>>BDC\n"
        f"q /GS0 gs {width_pt} 0 0 {height_pt} 0 0 cm /Im0 Do Q\nEMC EMC\n"
        f"/MainChannelImage BMC\nq /GS0 gs {width_pt} 0 0 {height_pt} 0 0 cm /Im1 Do Q\n"
        "EMC EMC EMC\n"
    ).encode("ascii")
    _compressed_file(content_stream, (content,))
    _compressed_file(resource_stream, (b"",))
    timestamp = datetime.now().astimezone()
    iso_date = timestamp.isoformat(timespec="seconds")
    xmp = (
        '<?xpacket begin="\ufeff"?>'
        '<x:xmpmeta xmlns:x="adobe:ns:meta/">'
        '<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">'
        '<rdf:Description rdf:about="" xmlns:xmp="http://ns.adobe.com/xap/1.0/" '
        f'xmp:CreatorTool="HopeFlow Toolbox" xmp:CreateDate="{html.escape(iso_date)}"/>'
        '</rdf:RDF></x:xmpmeta><?xpacket end="w"?>'
    ).encode("utf-8")
    _compressed_file(metadata_stream, (xmp,))
    pdf_date = timestamp.strftime("D:%Y%m%d%H%M%S%z")
    cmyk = " ".join(_number(value) for value in spot_cmyk)
    spot_name = _pdf_name(spec.spot_name)
    page_box = f"[ 0 0 {width_pt} {height_pt} ]"
    temp_stream = tempfile.NamedTemporaryFile(prefix=f".{output.name}.", suffix=".tmp", dir=output.parent, delete=False)
    temp_path = Path(temp_stream.name)
    try:
        with temp_stream:
            writer = _StreamingPdfWriter(temp_stream)
            writer.add_object(1, b"<< /Producer " + _pdf_string(PHOTOSHOP_PRODUCER) + b" /Creator (HopeFlow Toolbox) >>")
            writer.add_object(2, b"<< /Type /Pages /Count 1 /Kids [ 4 0 R ] >>")
            writer.add_object(3, b"<< /Type /Catalog /Pages 2 0 R /Metadata 15 0 R >>")
            page = (
                f"<< /Type /Page /Parent 2 0 R /Resources << /ColorSpace << /CS0 [ /Indexed "
            ).encode("ascii") + b"[ /Separation " + spot_name + (
                f" /DeviceCMYK 5 0 R ] 255 6 0 R ] /DefaultCMYK /DeviceCMYK >> "
                f"/ExtGState << /GS0 9 0 R >> /XObject << /Im0 7 0 R /Im1 8 0 R >> >> "
                f"/MediaBox {page_box} /CropBox {page_box} /ArtBox {page_box} /Rotate 0 "
                f"/LastModified ({pdf_date}) /Contents 10 0 R /PieceInfo 14 0 R >>"
            ).encode("ascii")
            writer.add_object(4, page)
            writer.add_object(5, f"<< /FunctionType 2 /Domain [ 0 1 ] /C0 [ 0 0 0 0 ] /C1 [ {cmyk} ] /N 1 >>".encode("ascii"))
            writer.add_stream(6, b"/Filter /FlateDecode", lookup_stream)
            indexed_space = b"[ /Indexed [ /Separation " + spot_name + b" /DeviceCMYK 5 0 R ] 255 6 0 R ]"
            writer.add_stream(7, b"/Filter /FlateDecode /Type /XObject /Subtype /Image " + f"/Width {spec.width} /Height {spec.height} /BitsPerComponent 8 /Name /X /ColorSpace ".encode("ascii") + indexed_space, spot_stream)
            writer.add_stream(8, f"/Filter /FlateDecode /Type /XObject /Subtype /Image /Width {spec.width} /Height {spec.height} /BitsPerComponent 8 /Name /X /ColorSpace /DeviceCMYK /Matte [ 0 0 0 0 ]".encode("ascii"), process_stream)
            writer.add_object(9, b"<< /Type /ExtGState /op true >>")
            writer.add_stream(10, b"/Filter /FlateDecode", content_stream)
            writer.add_stream(11, b"/Filter /FlateDecode", resource_stream)
            writer.add_stream(12, b"/Filter /FlateDecode", layer_stream)
            private = (
                f"<< /CompositeImage 8 0 R /EmbedFonts true /ExportCrispy true /ImageResources 11 0 R "
                f"/RoundTrip true /SaveTransparency true /SpotChannels << /N 1 /XObject << /Im1 7 0 R >> >> "
                f"/StandardImageFileData 12 0 R /StandardImageFileLength {layer_length} /UseTextOutlines false >>"
            ).encode("ascii")
            writer.add_object(13, private)
            writer.add_object(14, f"<< /AdobePhotoshop << /LastModified ({pdf_date}) /Private 13 0 R >> >>".encode("ascii"))
            writer.add_stream(15, b"/Filter /FlateDecode /Type /Metadata /Subtype /XML", metadata_stream)
            writer.finish(root=3, info=1)
            temp_stream.flush()
            os.fsync(temp_stream.fileno())
        os.replace(temp_path, output)
    finally:
        temp_path.unlink(missing_ok=True)


def write_photoshop_spot_pdf(
    spec: SpotPdfWriteSpec,
    pixels: NDArray[np.uint8],
    composite_pixels: NDArray[np.uint8] | None = None,
) -> None:
    output = Path(spec.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    spot_cmyk = normalize_spot_cmyk(spec.spot_cmyk)
    layout = photoshop_layer_stream_layout(spec.width, spec.height, spec.spot_name, spot_cmyk)
    with tempfile.TemporaryDirectory(prefix="hf-photoshop-pdf-") as temporary_directory:
        workdir = Path(temporary_directory)
        process_stream = workdir / "process.bin"
        spot_stream = workdir / "spot.bin"
        layer_stream = workdir / "layer.bin"
        _compressed_file(
            process_stream,
            _process_chunks(composite_pixels if composite_pixels is not None else pixels, spec.height),
        )
        _compressed_file(spot_stream, _spot_chunks(pixels, spec.height))
        _compressed_file(
            layer_stream,
            _layer_chunks(pixels, spec.height, layout.prefix, layout.suffix),
        )
        _write_document(
            output,
            spec,
            spot_cmyk,
            process_stream,
            spot_stream,
            layer_stream,
            layout.uncompressed_length,
            workdir,
        )
