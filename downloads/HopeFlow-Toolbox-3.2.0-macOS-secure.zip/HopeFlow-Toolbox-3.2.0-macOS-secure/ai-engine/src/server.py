from __future__ import annotations

import os
import json
import re
import shutil
import threading
from io import BytesIO
from pathlib import Path
from typing import Any, Dict, List, Optional
from urllib.request import urlretrieve

import cv2
import numpy as np
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from PIL import Image, ImageEnhance, ImageFilter
from export_router import router as export_router
from ai_image_router import router as ai_image_router


APP_VERSION = "1.0.0"
app = FastAPI(title="HopeFlow AI Engine", version=APP_VERSION)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.include_router(export_router)
app.include_router(ai_image_router)


class UpscaleRequest(BaseModel):
    input: str
    output: str
    scale: int = 2
    engine: str = "basic"
    grant: Optional[str] = ""
    feature: Optional[str] = "ai-enhance"
    site_base_url: Optional[str] = ""


class RemoveBgRequest(BaseModel):
    input: str
    output: str
    alpha_matting: bool = False
    grant: Optional[str] = ""
    feature: Optional[str] = "ai-enhance"
    site_base_url: Optional[str] = ""


class DenoiseRequest(BaseModel):
    input: str
    output: str
    level: str = "medium"
    grant: Optional[str] = ""
    feature: Optional[str] = "ai-enhance"
    site_base_url: Optional[str] = ""


class PerspectiveRequest(BaseModel):
    input: str
    output: str
    # 四个角点，像素坐标 [[x, y] x 4]，顺序任意（服务端会自动排成 左上/右上/右下/左下）
    corners: Optional[List[List[float]]] = None
    # corners 为空时自动检测；两者都给时以 corners 为准
    auto_detect: bool = False
    # 输出尺寸；留空则按四边形边长推算
    width: Optional[int] = None
    height: Optional[int] = None
    grant: Optional[str] = ""
    feature: Optional[str] = "ai-enhance"
    site_base_url: Optional[str] = ""


class PerspectiveDetectRequest(BaseModel):
    input: str


class PackageFontsRequest(BaseModel):
    # [{name, family, style}]，来自 Illustrator 的 textFont
    fonts: List[Dict[str, str]]
    output_dir: str


class DataMergeRenderRequest(BaseModel):
    template: Dict[str, Any]
    headers: List[str]
    rows: List[List[str]]
    output: str
    csv_dir: Optional[str] = ""


if hasattr(DataMergeRenderRequest, "model_rebuild"):
    DataMergeRenderRequest.model_rebuild()


def _ensure_parent(path: str) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)


def _open_rgba(path: str) -> Image.Image:
    if not os.path.exists(path):
        raise FileNotFoundError(f"Input file does not exist: {path}")
    return Image.open(path).convert("RGBA")


def _save_png(image: Image.Image, output_path: str) -> None:
    _ensure_parent(output_path)
    image.save(output_path, "PNG")


def _response(output_path: str) -> dict:
    return {"success": True, "output": output_path}


@app.get("/health")
def health() -> dict:
    return {
        "ok": True,
        "device": "CPU",
        "version": APP_VERSION,
        "features": {
            "upscale": True,
            "realesrgan": _realesrgan_available(),
            "denoise": True,
            "perspective": True,
            "package_fonts": True,
            "remove_bg": _rembg_available(),
            "data_merge_pdf": True,
            "pdf_to_jpeg": True,
            "spot_tiff": True,
            "spot_pdf_tiff": True,
            "ai_image": True,
        },
    }


@app.post("/upscale")
def upscale(req: UpscaleRequest) -> dict:
    try:
        scale = 4 if int(req.scale) >= 4 else 2
        if (req.engine or "basic").lower() == "realesrgan":
            return _upscale_realesrgan(req.input, req.output, scale)

        image = _open_rgba(req.input)
        width, height = image.size
        resized = image.resize((width * scale, height * scale), Image.Resampling.LANCZOS)
        enhanced = resized.filter(ImageFilter.UnsharpMask(radius=1.2, percent=140, threshold=3))
        enhanced = ImageEnhance.Sharpness(enhanced).enhance(1.08)
        _save_png(enhanced, req.output)
        return _response(req.output)
    except Exception as exc:
        return {"success": False, "error": str(exc)}


@app.post("/denoise")
def denoise(req: DenoiseRequest) -> dict:
    try:
        image = _open_rgba(req.input)
        rgba = np.array(image)
        rgb = cv2.cvtColor(rgba[:, :, :3], cv2.COLOR_RGB2BGR)

        strength_map = {
            "none": 0,
            "low": 4,
            "medium": 8,
            "high": 12,
        }
        strength = strength_map.get((req.level or "medium").lower(), 8)
        if strength > 0:
            rgb = cv2.fastNlMeansDenoisingColored(rgb, None, strength, strength, 7, 21)

        result_rgb = cv2.cvtColor(rgb, cv2.COLOR_BGR2RGB)
        result = np.dstack([result_rgb, rgba[:, :, 3]])
        _save_png(Image.fromarray(result, "RGBA"), req.output)
        return _response(req.output)
    except Exception as exc:
        return {"success": False, "error": str(exc)}


@app.post("/remove_bg")
def remove_bg(req: RemoveBgRequest) -> dict:
    try:
        try:
            from rembg import remove
        except Exception:
            return {
                "success": False,
                "error": "rembg is not installed. Install optional rembg dependencies to use background removal.",
            }

        image = _open_rgba(req.input)
        result = remove(image, alpha_matting=bool(req.alpha_matting))
        if not isinstance(result, Image.Image):
            result = Image.open(result).convert("RGBA")
        _save_png(result.convert("RGBA"), req.output)
        return _response(req.output)
    except Exception as exc:
        return {"success": False, "error": str(exc)}


@app.post("/perspective")
def perspective(req: PerspectiveRequest) -> dict:
    try:
        rgba = np.array(_open_rgba(req.input))

        if req.corners:
            corners = _validate_corners(req.corners)
        elif req.auto_detect:
            corners = _detect_corners(rgba)
            if corners is None:
                return {"success": False, "error": "未能自动识别四边形，请手动指定四个角点"}
        else:
            return {"success": False, "error": "缺少角点：请提供 corners 或开启 auto_detect"}

        ordered = _order_corners(corners)
        width, height = _perspective_target_size(ordered, req.width, req.height)
        dst = np.array(
            [[0, 0], [width - 1, 0], [width - 1, height - 1], [0, height - 1]],
            dtype=np.float32,
        )
        matrix = cv2.getPerspectiveTransform(ordered, dst)
        warped = cv2.warpPerspective(
            rgba,
            matrix,
            (width, height),
            flags=cv2.INTER_LANCZOS4,
            borderMode=cv2.BORDER_CONSTANT,
            borderValue=(0, 0, 0, 0),
        )

        _save_png(Image.fromarray(warped, "RGBA"), req.output)
        return {
            "success": True,
            "output": req.output,
            "corners": ordered.tolist(),
            "width": width,
            "height": height,
        }
    except Exception as exc:
        return {"success": False, "error": str(exc)}


@app.post("/perspective_detect")
def perspective_detect(req: PerspectiveDetectRequest) -> dict:
    try:
        rgba = np.array(_open_rgba(req.input))
        corners = _detect_corners(rgba)
        if corners is None:
            return {"success": False, "error": "未能自动识别四边形，请手动指定四个角点"}
        ordered = _order_corners(corners)
        return {
            "success": True,
            "corners": ordered.tolist(),
            "width": int(rgba.shape[1]),
            "height": int(rgba.shape[0]),
        }
    except Exception as exc:
        return {"success": False, "error": str(exc)}


def _validate_corners(corners: List[List[float]]) -> np.ndarray:
    if len(corners) != 4:
        raise ValueError(f"需要 4 个角点，收到 {len(corners)} 个")
    points = []
    for point in corners:
        if len(point) < 2:
            raise ValueError("角点格式应为 [x, y]")
        points.append([float(point[0]), float(point[1])])
    return np.array(points, dtype=np.float32)


def _order_corners(points: np.ndarray) -> np.ndarray:
    """把任意顺序的四点排成 左上 / 右上 / 右下 / 左下。"""
    total = points.sum(axis=1)
    # diff = y - x：右上角最小，左下角最大
    diff = (points[:, 1] - points[:, 0])
    return np.array(
        [
            points[int(np.argmin(total))],
            points[int(np.argmin(diff))],
            points[int(np.argmax(total))],
            points[int(np.argmax(diff))],
        ],
        dtype=np.float32,
    )


def _perspective_target_size(
    ordered: np.ndarray,
    width: Optional[int],
    height: Optional[int],
) -> tuple[int, int]:
    top_left, top_right, bottom_right, bottom_left = ordered
    edge_width = max(
        float(np.linalg.norm(bottom_right - bottom_left)),
        float(np.linalg.norm(top_right - top_left)),
    )
    edge_height = max(
        float(np.linalg.norm(top_right - bottom_right)),
        float(np.linalg.norm(top_left - bottom_left)),
    )
    out_width = int(width) if width else int(round(edge_width))
    out_height = int(height) if height else int(round(edge_height))
    return max(1, out_width), max(1, out_height)


def _detect_corners(rgba: np.ndarray) -> Optional[np.ndarray]:
    """自动找画面里最大的四边形。

    透明背景（Illustrator 导出的 PNG 常见）时直接用 alpha 通道当轮廓来源，
    比灰度边缘稳得多；否则退回 灰度 + Canny。
    """
    alpha = rgba[:, :, 3]
    if int(alpha.min()) < 250:
        mask = cv2.threshold(alpha, 127, 255, cv2.THRESH_BINARY)[1]
    else:
        gray = cv2.cvtColor(rgba[:, :, :3], cv2.COLOR_RGB2GRAY)
        gray = cv2.GaussianBlur(gray, (5, 5), 0)
        mask = cv2.Canny(gray, 50, 150)
        mask = cv2.dilate(mask, np.ones((3, 3), np.uint8), iterations=1)

    contours = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[0]
    if not contours:
        return None

    total_area = float(rgba.shape[0] * rgba.shape[1])
    candidates = sorted(contours, key=cv2.contourArea, reverse=True)[:5]
    for contour in candidates:
        if cv2.contourArea(contour) < total_area * 0.05:
            break
        perimeter = cv2.arcLength(contour, True)
        for factor in (0.01, 0.02, 0.03, 0.05, 0.08):
            approx = cv2.approxPolyDP(contour, factor * perimeter, True)
            if len(approx) == 4 and cv2.isContourConvex(approx):
                return approx.reshape(4, 2).astype(np.float32)

    # 近似不出四边形时（边缘毛糙/圆角），退回最大轮廓的最小外接旋转矩形
    largest = candidates[0]
    if cv2.contourArea(largest) < total_area * 0.05:
        return None
    return cv2.boxPoints(cv2.minAreaRect(largest)).astype(np.float32)


@app.post("/package_fonts")
def package_fonts(req: PackageFontsRequest) -> dict:
    """把文档用到的字体文件真正拷进打包目录。

    ExtendScript 读不到系统字体文件，但引擎可以：直接复用数据合并那套跨平台字体索引。
    找不到的字体如实列进 missing，绝不用近似字体顶替。
    """
    try:
        out_dir = Path(req.output_dir)
        out_dir.mkdir(parents=True, exist_ok=True)

        copied: List[Dict[str, str]] = []
        missing: List[str] = []
        seen_sources = set()

        for entry in req.fonts:
            display = (entry.get("name") or "").strip()
            if not display:
                continue
            hint = " ".join(
                part for part in (
                    entry.get("name") or "",
                    entry.get("family") or "",
                    entry.get("style") or "",
                ) if part
            ).strip()

            resolved = _resolve_font_file_strict(hint) or _resolve_font_file_strict(display)
            if not resolved:
                missing.append(display)
                continue

            source = Path(resolved[0])
            if not source.exists():
                missing.append(display)
                continue

            # 单个字体拷贝失败不能拖垮整批（系统字体目录受 SIP 保护，权限问题很常见）
            try:
                if str(source) not in seen_sources:
                    # 必须用 copyfile 而不是 copy2：copy2 会连带复制 SIP 保护的元数据，
                    # 拷贝 /System/Library/Fonts 下的字体时会抛 Operation not permitted。
                    shutil.copyfile(source, out_dir / source.name)
                    seen_sources.add(str(source))
                copied.append({"name": display, "file": source.name})
            except Exception as copy_error:
                missing.append(f"{display}（复制失败：{copy_error}）")

        _write_font_report(out_dir, copied, missing)
        return {
            "success": True,
            "output_dir": str(out_dir),
            "copied": copied,
            "missing": missing,
        }
    except Exception as exc:
        return {"success": False, "error": str(exc)}


def _resolve_font_file_strict(hint: str):
    """打包专用解析：只做 精确 / 归一化 / 逐词 匹配。

    刻意不复用 _resolve_font_file 的 CJK 兜底（它找不到「方正兰亭黑」会退给「苹方」）——
    渲染时退化字体尚可接受，打包时拿错字体比缺字体更糟。
    """
    import re as _re

    idx = _build_font_index()
    h = (hint or "").strip().lower()
    if not h:
        return None
    if h in idx:
        return idx[h]

    def norm(value: str) -> str:
        return _re.sub(r"[\s\-_,]", "", value)

    normalized = norm(h)
    if normalized:
        for key, value in idx.items():
            if norm(key) == normalized:
                return value

    for token in h.split():
        if token in idx:
            return idx[token]
        normalized_token = norm(token)
        if normalized_token:
            for key, value in idx.items():
                if norm(key) == normalized_token:
                    return value
    return None


def _write_font_report(out_dir: Path, copied: List[Dict[str, str]], missing: List[str]) -> None:
    lines = ["--- 字体打包报告 ---", ""]
    lines.append(f"已打包 {len(copied)} 个字体文件：")
    if copied:
        for item in copied:
            lines.append(f"  - {item['name']}  →  {item['file']}")
    else:
        lines.append("  （无）")
    lines.append("")
    lines.append(f"未找到 {len(missing)} 个字体：")
    if missing:
        for name in missing:
            lines.append(f"  - {name}")
        lines.append("")
        lines.append("未找到的原因通常是：该字体来自 Adobe Fonts（Typekit）等云端激活服务，")
        lines.append("其字体文件不以常规格式存放在系统字体目录中，无法被复制。")
    else:
        lines.append("  （无）")
    lines.append("")
    lines.append("注意：字体文件受版权保护，随稿件转交第三方前请确认授权允许。")
    (out_dir / "字体打包报告.txt").write_text("\n".join(lines), encoding="utf-8")


@app.post("/clear_cache")
def clear_cache() -> dict:
    return {"success": True}


@app.post("/data_merge_pdf")
def data_merge_pdf(req: DataMergeRenderRequest) -> dict:
    try:
        output_path = render_data_merge_pdf(req)
        debug_path = f"{output_path}.debug.json"
        return {
            "success": True,
            "output": output_path,
            "pages": len(req.rows),
            "debug": debug_path if os.path.exists(debug_path) else "",
        }
    except Exception as exc:
        return {"success": False, "error": str(exc)}


@app.post("/shutdown")
def shutdown() -> dict:
    threading.Timer(0.2, lambda: os._exit(0)).start()
    return {"success": True}


def _rembg_available() -> bool:
    try:
        import rembg  # noqa: F401

        return True
    except Exception:
        return False


def _realesrgan_available() -> bool:
    try:
        _import_realesrgan()
        return True
    except Exception:
        return False


def _import_realesrgan():
    import sys
    import torchvision.transforms.functional as functional

    sys.modules.setdefault("torchvision.transforms.functional_tensor", functional)

    from basicsr.archs.rrdbnet_arch import RRDBNet
    from realesrgan import RealESRGANer

    return RRDBNet, RealESRGANer


def _models_dir() -> Path:
    model_dir = Path.home() / ".hopeflow" / "ai-engine" / "models"
    model_dir.mkdir(parents=True, exist_ok=True)
    return model_dir


def _realesrgan_model_path() -> Path:
    model_path = _models_dir() / "RealESRGAN_x4plus.pth"
    if not model_path.exists():
        urlretrieve(
            "https://github.com/xinntao/Real-ESRGAN/releases/download/v0.1.0/RealESRGAN_x4plus.pth",
            model_path,
        )
    return model_path


# ---- Data-merge PDF rendering via PyMuPDF (fitz) ----
# 换用 fitz：支持思源黑体等 OTF/可变字体、任意角度旋转、精确定位；比 reportlab 更快。

_FONT_INDEX = None
_FITZ_FONT_CACHE = {}
def _font_dirs():
    """按平台返回字体目录（含 * 的在 _build_font_index 里 glob 展开）。"""
    import sys as _sys
    if _sys.platform == "darwin":
        return [
            os.path.expanduser("~/Library/Fonts"),
            "/Library/Fonts",
            "/System/Library/Fonts",
            "/System/Library/Fonts/Supplemental",
            "/Library/Application Support/Adobe/Fonts",
            os.path.expanduser("~/Library/Application Support/Adobe/Fonts"),
            "/Applications/Adobe Illustrator */Adobe Illustrator.app/Contents/Required/Fonts",
            "/Applications/Adobe*/*.app/Contents/Required/Fonts",
            "/Applications/Adobe*/*.app/Contents/Required/PDFL/Resource/Fonts",
            "/Applications/Adobe*/*.app/Contents/Resources/Resource/CIDFont",
        ]
    if _sys.platform.startswith("win"):
        windir = os.environ.get("WINDIR", r"C:\Windows")
        local = os.environ.get("LOCALAPPDATA", "")
        appdata = os.environ.get("APPDATA", "")
        pf = os.environ.get("ProgramFiles", r"C:\Program Files")
        pf86 = os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")
        dirs = [
            os.path.join(windir, "Fonts"),
            os.path.join(pf, "Common Files", "Adobe", "Fonts"),
            os.path.join(pf86, "Common Files", "Adobe", "Fonts"),
            os.path.join(pf, "Adobe", "Adobe Illustrator *", "Support Files", "Required", "Fonts"),
            os.path.join(pf86, "Adobe", "Adobe Illustrator *", "Support Files", "Required", "Fonts"),
        ]
        if local:
            dirs.append(os.path.join(local, "Microsoft", "Windows", "Fonts"))
        if appdata:
            dirs.append(os.path.join(appdata, "Adobe", "Fonts"))
        return dirs
    return [
        os.path.expanduser("~/.fonts"),
        os.path.expanduser("~/.local/share/fonts"),
        "/usr/share/fonts",
        "/usr/local/share/fonts",
    ]


_FONT_DIRS = _font_dirs()


def _hex_rgb(h):
    h = (h or "#000000").lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    try:
        return (int(h[0:2], 16) / 255.0, int(h[2:4], 16) / 255.0, int(h[4:6], 16) / 255.0)
    except Exception:
        return (0.0, 0.0, 0.0)


def _build_font_index():
    """扫描系统字体，建立 字体名(小写) -> (文件路径, ttc子序号) 映射。"""
    global _FONT_INDEX
    if _FONT_INDEX is not None:
        return _FONT_INDEX
    from fontTools.ttLib import TTFont, TTCollection

    idx = {}

    def add(name, path, i):
        if name:
            idx.setdefault(str(name).strip().lower(), (path, i))

    for d in _FONT_DIRS:
        if not os.path.isdir(d):
            continue
        for fn in os.listdir(d):
            ext = os.path.splitext(fn)[1].lower()
            if ext not in (".ttf", ".otf", ".ttc", ".otc"):
                continue
            path = os.path.join(d, fn)
            try:
                if ext in (".ttc", ".otc"):
                    fonts = list(TTCollection(path, lazy=True).fonts)
                else:
                    fonts = [TTFont(path, lazy=True, fontNumber=0)]
                for i, f in enumerate(fonts):
                    try:
                        nm = f["name"]
                        for nid in (6, 4, 1, 16):  # postscript / full / family / typographic-family
                            add(nm.getDebugName(nid), path, i)
                    finally:
                        try:
                            f.close()
                        except Exception:
                            pass
            except Exception:
                continue
    _FONT_INDEX = idx
    return idx


def _resolve_font_file(font_hint, sample_text=""):
    """AI 字体名 -> (文件路径, ttc子序号)。精确→归一化→包含→关键词→CJK兜底。"""
    import re as _re

    idx = _build_font_index()
    hint = (font_hint or "").strip().lower()

    if hint in idx:
        return idx[hint]

    # 逐词精确：font_hint 是 fontName+family+style 拼接，fontName 常是 PostScript 名(如 HYZhuZiJiXieShi_J)
    for tok in hint.split():
        if tok in idx:
            return idx[tok]
        tn = _re.sub(r"[\s\-_,]", "", tok)
        if tn:
            for k, v in idx.items():
                if _re.sub(r"[\s\-_,]", "", k) == tn:
                    return v

    norm = _re.sub(r"[\s\-_,]", "", hint)
    if norm:
        for k, v in idx.items():
            if _re.sub(r"[\s\-_,]", "", k) == norm:
                return v
        for k, v in idx.items():
            if norm in _re.sub(r"[\s\-_,]", "", k):
                return v

    def find(*subs):
        subs = [s.replace(" ", "") for s in subs]
        for k, v in idx.items():
            kk = k.replace(" ", "")
            if any(s in kk for s in subs):
                return v
        return None

    if any(w in hint for w in ("思源", "source han", "sourcehansans", "notosans")):
        r = find("sourcehansanssc", "notosanssc", "pingfangsc") or find("pingfang", "heiti", "sourcehansans", "notosans")
        if r:
            return r
    if "楷" in hint or "kai" in hint:
        r = find("kaiti", "kai")
        if r:
            return r
    if "宋" in hint or "song" in hint or "serif" in hint or "ming" in hint:
        r = find("songti", "song", "serif")
        if r:
            return r
    if "黑" in hint or "hei" in hint or "gothic" in hint or "sans" in hint:
        r = find("pingfangsc", "notosanssc", "pingfang", "heiti", "notosans", "hei")
        if r:
            return r

    return find("notosanssc", "pingfangsc", "pingfang", "songti", "heiti", "stheiti", "notosans")


def _get_fitz_font(font_hint, sample_text=""):
    import fitz

    resolved = _resolve_font_file(font_hint, sample_text)
    key = resolved if resolved else "__cjk_default__"
    if key in _FITZ_FONT_CACHE:
        return _FITZ_FONT_CACHE[key]

    font = None
    if resolved:
        path, i = resolved
        try:
            if i == 0:
                font = fitz.Font(fontfile=path)
            else:
                from fontTools.ttLib import TTCollection
                from io import BytesIO

                buf = BytesIO()
                TTCollection(path, lazy=False).fonts[i].save(buf)
                font = fitz.Font(fontbuffer=buf.getvalue())
        except Exception:
            font = None
    if font is None:
        try:
            font = fitz.Font("china-s")  # fitz 内置简体中文兜底
        except Exception:
            font = fitz.Font()
    _FITZ_FONT_CACHE[key] = font
    return font


def render_data_merge_pdf(req: DataMergeRenderRequest) -> str:
    import fitz

    template = req.template
    background_path = template.get("backgroundPdf") or template.get("background_pdf")
    if not background_path or not os.path.exists(background_path):
        raise FileNotFoundError(f"Background PDF does not exist: {background_path}")
    foreground_path = template.get("foregroundPdf") or template.get("foreground_pdf")
    if foreground_path and not os.path.exists(foreground_path):
        foreground_path = None

    page = template.get("page") or {}
    W = float(page.get("width") or 0)
    H = float(page.get("height") or 0)

    bg = fitz.open(background_path)
    if W <= 0 or H <= 0:
        r = bg[0].rect
        W, H = r.width, r.height
    fg = fitz.open(foreground_path) if foreground_path else None

    fields = template.get("fields") or []
    header_index = {n: i for i, n in enumerate(req.headers)}
    csv_dir = req.csv_dir or ""
    out = fitz.open()

    for row in req.rows:
        pg = out.new_page(width=W, height=H)
        pg.show_pdf_page(pg.rect, bg, 0)  # 背景（AI 导出，完美还原）

        for field in fields:
            column = field.get("column", "")
            if not str(column).strip():
                continue
            ci = header_index.get(column)
            if ci is None or ci >= len(row):
                continue
            value = "" if row[ci] is None else str(row[ci])

            b = field.get("bounds") or {}
            left = float(b.get("left") or 0)
            top = float(b.get("top") or 0)
            right = float(b.get("right") or left)
            bottom = float(b.get("bottom") or top)

            if field.get("type") == "IMAGE":
                ip = value
                if ip and not os.path.exists(ip) and csv_dir:
                    ip = os.path.join(csv_dir, value)
                if ip and os.path.exists(ip):
                    try:
                        pg.insert_image(fitz.Rect(left, top, right, bottom), filename=ip, keep_proportion=True)
                    except Exception:
                        pass
                continue

            if not value:
                continue

            size = float(field.get("fontSize") or 12)
            color = _hex_rgb(field.get("color") or "#000000")
            rotation = float(field.get("rotation") or 0)
            hint = " ".join(str(field.get(k) or "") for k in ("fontName", "fontFamily", "fontStyle"))
            font = _get_fitz_font(hint, value)
            try:
                import tempfile as _tf
                with open(os.path.join(_tf.gettempdir(), "hopeflow-fontmatch.log"), "a", encoding="utf-8") as _lf:
                    _rf = _resolve_font_file(hint, value)
                    _lf.write("hint=%r -> %s\n" % (hint, (_rf[0] if _rf else None)))
            except Exception:
                pass
            tw = fitz.TextWriter(pg.rect, color=color)

            if rotation:
                # AI rotate 绕对象中心 → bounds 中心=旋转中心；居中绘制后绕中心旋转。
                cx = (left + right) / 2
                cy = (top + bottom) / 2
                tl = font.text_length(value, fontsize=size)
                tw.append(fitz.Point(cx - tl / 2, cy + size * 0.35), value, font=font, fontsize=size)
                tw.write_text(pg, morph=(fitz.Point(cx, cy), fitz.Matrix(rotation)))
            else:
                asc = font.ascender
                align = (field.get("alignment") or "left").lower()
                tl = font.text_length(value, fontsize=size)
                if align == "center":
                    x = (left + right) / 2 - tl / 2
                elif align == "right":
                    x = right - tl
                else:
                    x = left
                tw.append(fitz.Point(x, top + size * asc), value, font=font, fontsize=size)
                tw.write_text(pg)

        if fg:
            pg.show_pdf_page(pg.rect, fg, 0)  # 前景（盖在动态内容之上的静态元素）

    _ensure_parent(req.output)
    out.save(req.output, garbage=3, deflate=True)
    return req.output


def write_data_merge_debug(
    output_path: str,
    background_path: str,
    page_width: float,
    page_height: float,
    row_count: int,
    fields: List[Dict[str, Any]],
    template_debug: Dict[str, Any],
    foreground_path: Optional[str] = None,
) -> None:
    try:
        with open(f"{output_path}.debug.json", "w", encoding="utf-8") as fh:
            json.dump(
                {
                    "output": output_path,
                    "background": background_path,
                    "foreground": foreground_path or "",
                    "page": {"width": page_width, "height": page_height},
                    "rows": row_count,
                    "fields": fields,
                    "static_items": template_debug.get("staticItems") or [],
                    "min_dynamic_page_item_index": template_debug.get("minDynamicPageItemIndex"),
                    "foreground_count": template_debug.get("foregroundCount", 0),
                    "has_foreground": template_debug.get("hasForeground", False),
                    "notes": [
                        "Render order: background PDF → dynamic overlay → foreground PDF (if any).",
                        "Foreground items are static items with pageItems index < minDynamicPageItemIndex.",
                    ],
                },
                fh,
                ensure_ascii=False,
                indent=2,
            )
    except Exception:
        pass


def draw_aligned_text(c, value: str, font_name: str, font_size: float, left: float, right: float, y: float, alignment: str) -> None:
    alignment = (alignment or "left").lower()
    if alignment == "center":
        c.drawCentredString((left + right) / 2, y, value)
    elif alignment == "right":
        c.drawRightString(right, y, value)
    else:
        c.drawString(left, y, value)


def cleanup_background_pdf(background_path: str, foreground_path: Optional[str], output_path: str) -> None:
    try:
        bg = Path(background_path)
        out = Path(output_path)
        if bg.exists() and bg.resolve() != out.resolve() and bg.name.endswith("_background.pdf"):
            bg.unlink()
    except Exception:
        pass
    try:
        if foreground_path:
            fg = Path(foreground_path)
            if fg.exists() and fg.name.endswith("_foreground.pdf"):
                fg.unlink()
    except Exception:
        pass


def resolve_pdf_font(illustrator_font_name: str, sample_text: str = "") -> str:
    key = (illustrator_font_name or "") + "\n" + (sample_text or "")
    if key in _FONT_CACHE:
        return _FONT_CACHE[key]

    try:
        from reportlab.pdfbase import pdfmetrics
        from reportlab.pdfbase.cidfonts import UnicodeCIDFont
        from reportlab.pdfbase.ttfonts import TTFont
    except Exception:
        _FONT_CACHE[key] = "Helvetica"
        return "Helvetica"

    # illustrator_font_name 可能是纯 PostScript 名（如 "AlibabaPuHuiTiR"），
    # 也可能是用空格拼接的 hint（如 "AlibabaPuHuiTiR 阿里巴巴普惠体 Regular"）。
    # 拆分出纯英文 PostScript name 和完整 hint 分别尝试匹配。
    parts = illustrator_font_name.strip().split()
    # 第一个非空 token 通常是 PostScript name
    ps_name = parts[0] if parts else illustrator_font_name
    ps_normalized = normalize_font_name(ps_name)
    full_normalized = normalize_font_name(illustrator_font_name)

    needs_cjk = contains_cjk(sample_text) or contains_cjk(illustrator_font_name)
    font_dirs = get_font_dirs()

    # ① 思源黑体系列优先匹配
    is_sourcehan = any(token in full_normalized for token in (
        "sourcehan", "sourcehansans", "sourcehansanscn", "siyuan", "思源",
        "notosanscjk", "notosans"
    ))
    if is_sourcehan:
        sh_path = _find_sourcehan_font(full_normalized, font_dirs)
        if sh_path:
            registered_sh = register_pdf_font(sh_path)
            if registered_sh:
                _FONT_CACHE[key] = registered_sh
                return registered_sh

    # ② 用纯 PostScript name 做精确匹配（内部字体名表）
    exact_path = find_font_by_internal_names(ps_name)
    if exact_path:
        registered_exact = register_pdf_font(exact_path)
        if registered_exact:
            _FONT_CACHE[key] = registered_exact
            return registered_exact

    # ③ 用纯 PostScript name 做模糊匹配（文件名相似度）
    candidates = collect_font_files(font_dirs)
    best_path, best_score = find_best_font_path(ps_normalized, candidates)
    if best_path and best_score >= font_match_threshold(ps_normalized):
        if needs_cjk and not is_likely_cjk_font(best_path):
            pass  # 跳过非 CJK 字体
        else:
            registered_best = register_pdf_font(best_path)
            if registered_best:
                _FONT_CACHE[key] = registered_best
                return registered_best

    # ④ 如果 ps_name 没命中，用完整 hint 再试一次模糊匹配
    if full_normalized != ps_normalized:
        best_path2, best_score2 = find_best_font_path(full_normalized, candidates)
        if best_path2 and best_score2 >= font_match_threshold(full_normalized):
            if needs_cjk and not is_likely_cjk_font(best_path2):
                pass
            else:
                registered_best2 = register_pdf_font(best_path2)
                if registered_best2:
                    _FONT_CACHE[key] = registered_best2
                    return registered_best2

    # ⑤ 显式的 Windows CJK 字族 fallback
    if has_explicit_windows_cjk_family(full_normalized):
        preferred_names = preferred_windows_font_files(full_normalized)
        for font_dir in font_dirs:
            for preferred in preferred_names:
                preferred_path = font_dir / preferred
                if preferred_path.exists():
                    registered = register_pdf_font(preferred_path)
                    if registered:
                        _FONT_CACHE[key] = registered
                        return registered

    # ⑥ CJK 文本的通用 fallback
    if needs_cjk:
        preferred_names = preferred_windows_font_files(full_normalized)
        for font_dir in font_dirs:
            for preferred in preferred_names:
                preferred_path = font_dir / preferred
                if preferred_path.exists():
                    registered = register_pdf_font(preferred_path)
                    if registered:
                        _FONT_CACHE[key] = registered
                        return registered

    # ⑦ CID 字体 fallback
    for cid_font in ("STSong-Light", "HeiseiKakuGo-W5", "HeiseiMin-W3"):
        try:
            if cid_font not in pdfmetrics.getRegisteredFontNames():
                pdfmetrics.registerFont(UnicodeCIDFont(cid_font))
            _FONT_CACHE[key] = cid_font
            return cid_font
        except Exception:
            continue

    _FONT_CACHE[key] = "Helvetica"
    return "Helvetica"


def register_pdf_font(path: Path) -> Optional[str]:
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont

    pdf_name = "HF_" + re.sub(r"[^A-Za-z0-9_]", "_", path.stem)[:80]
    try:
        if pdf_name not in pdfmetrics.getRegisteredFontNames():
            pdfmetrics.registerFont(TTFont(pdf_name, str(path)))
        _FONT_FILE_CACHE[pdf_name] = str(path)
        return pdf_name
    except Exception:
        return None


def get_font_dirs() -> List[Path]:
    return [
        Path(os.environ.get("WINDIR", r"C:\Windows")) / "Fonts",
        Path.home() / "AppData" / "Local" / "Microsoft" / "Windows" / "Fonts",
    ]


def collect_font_files(font_dirs: List[Path]) -> List[Path]:
    candidates: List[Path] = []
    for font_dir in font_dirs:
        if not font_dir.exists():
            continue
        for ext in ("*.ttf", "*.otf", "*.ttc"):
            candidates.extend(font_dir.glob(ext))
    return candidates


def find_font_by_internal_names(illustrator_font_name: str) -> Optional[Path]:
    target = normalize_font_name(illustrator_font_name)
    if not target:
        return None

    font_index = get_system_font_index()

    # 第 1 级：精确匹配
    for font_info in font_index:
        if target in font_info["exact_names"]:
            return font_info["path"]

    # 第 2 级：去掉 "regular"/"normal" 后精确匹配
    compact_target = target.replace("regular", "").replace("normal", "")
    for font_info in font_index:
        if compact_target and compact_target in font_info["exact_names"]:
            return font_info["path"]

    # 第 3 级：展开 Illustrator 常用的单字母样式缩写
    # AlibabaPuHuiTiR → alibabapuhuitir → 尝试 alibabapuhuitiregular
    style_expansions = {
        "r": "regular", "b": "bold", "m": "medium",
        "l": "light", "h": "heavy", "t": "thin",
    }
    if len(target) > 4:
        last_char = target[-1]
        if last_char in style_expansions:
            expanded = target[:-1] + style_expansions[last_char]
            for font_info in font_index:
                if expanded in font_info["exact_names"]:
                    return font_info["path"]

    # 第 4 级：子串匹配（target 是某个内部名的子串，或反过来）
    # 取最长匹配，避免误命中
    best_match: Optional[Path] = None
    best_match_len = 0
    if len(target) >= 8:  # 足够长才做子串匹配，避免短名误命中
        for font_info in font_index:
            for name in font_info["exact_names"]:
                if target in name or name in target:
                    match_len = min(len(target), len(name))
                    if match_len > best_match_len:
                        best_match_len = match_len
                        best_match = font_info["path"]
        if best_match and best_match_len >= len(target) * 0.7:
            return best_match

    return None


def get_system_font_index() -> List[Dict[str, Any]]:
    global _SYSTEM_FONT_INDEX
    if _SYSTEM_FONT_INDEX is not None:
        return _SYSTEM_FONT_INDEX

    indexed: List[Dict[str, Any]] = []
    for path in collect_font_files(get_font_dirs()):
        names = read_font_internal_names(path)
        if not names:
            continue
        indexed.append({"path": path, "exact_names": set(names)})

    _SYSTEM_FONT_INDEX = indexed
    return indexed


def read_font_internal_names(path: Path) -> List[str]:
    try:
        from fontTools.ttLib import TTCollection, TTFont
    except Exception:
        return []

    names: List[str] = []
    try:
        if path.suffix.lower() == ".ttc":
            collection = TTCollection(str(path))
            for font in collection.fonts:
                names.extend(extract_name_table(font))
            return names

        font = TTFont(str(path), lazy=True)
        return extract_name_table(font)
    except Exception:
        return []


def extract_name_table(font) -> List[str]:
    result: List[str] = []
    for record in font["name"].names:
        if record.nameID not in (1, 2, 4, 6, 16, 17):
            continue
        try:
            value = record.toUnicode()
        except Exception:
            continue
        normalized = normalize_font_name(value)
        if normalized:
            result.append(normalized)
    return result


def normalize_font_name(value: str) -> str:
    return re.sub(r"[^a-z0-9\u4e00-\u9fff]", "", value.lower())


def contains_cjk(value: str) -> bool:
    return bool(re.search(r"[\u3400-\u9fff]", value or ""))


def find_best_font_path(target: str, candidates: List[Path]) -> tuple[Optional[Path], int]:
    best_path = None
    best_score = 0
    for path in candidates:
        name = normalize_font_name(path.stem)
        score = font_match_score(target, name)
        if score > best_score:
            best_score = score
            best_path = path
    return best_path, best_score


def font_match_threshold(target: str) -> int:
    if not target:
        return 999
    return max(6, min(14, len(target) // 2))


def is_likely_cjk_font(path: Path) -> bool:
    name = normalize_font_name(path.stem)
    cjk_tokens = (
        "yahei", "msyh", "simhei", "simsun", "song", "hei", "fangsong", "kai",
        "noto", "sourcehan", "siyuan", "alimama", "alibaba", "puhui", "hanyi", "fzz",
        "dengxian", "youyuan", "等线", "雅黑", "黑体", "宋体", "仿宋", "楷体", "思源"
    )
    return any(token in name for token in cjk_tokens)


def has_explicit_windows_cjk_family(normalized_hint: str) -> bool:
    tokens = ("yahei", "microsoftyahei", "msyh", "simhei", "simsun")
    return any(token in normalized_hint for token in tokens)


def _find_sourcehan_font(normalized_hint: str, font_dirs: List["Path"]) -> Optional["Path"]:
    """尝试在系统字体目录中找思源黑体/Source Han Sans/Noto Sans CJK 文件。"""
    style = normalized_hint
    if "extralight" in style or "ultralight" in style:
        candidates = ["SourceHanSansCN-ExtraLight.otf", "NotoSansCJKsc-Thin.otf"]
    elif "light" in style:
        candidates = ["SourceHanSansCN-Light.otf", "NotoSansCJKsc-Light.otf"]
    elif "medium" in style:
        candidates = ["SourceHanSansCN-Medium.otf", "NotoSansCJKsc-Medium.otf"]
    elif "bold" in style or "heavy" in style or "black" in style:
        candidates = ["SourceHanSansCN-Bold.otf", "SourceHanSansCN-Heavy.otf", "NotoSansCJKsc-Bold.otf"]
    else:
        candidates = ["SourceHanSansCN-Regular.otf", "NotoSansCJKsc-Regular.otf"]

    for font_dir in font_dirs:
        for name in candidates:
            p = font_dir / name
            if p.exists():
                return p
    return None


def preferred_windows_font_files(normalized_hint: str) -> List[str]:
    # 注意：“黑”在中文字体名中是分类名（无衬线体），不代表粗体。
    # 只有 "bold"/"black"/"heavy"/"demi"/"粗黑"这类明确粗体关键词才判断为粗体。
    is_bold = any(token in normalized_hint for token in ("bold", "black", "heavy", "demi", "粗"))
    # 思源黑体 / Source Han Sans / Noto Sans CJK 系列
    is_sourcehan = any(token in normalized_hint for token in (
        "sourcehan", "sourcehansans", "sourcehansanscn", "siyuan", "思源",
        "notosanscjk", "notosans"
    ))
    is_yahei = any(token in normalized_hint for token in ("yahei", "微软雅黑", "microsoftyahei"))
    is_hei = (
        # 字面包含 黑体/simhei 且不是思源黑体（避免误判）
        any(token in normalized_hint for token in ("黑体", "simhei"))
        and not is_sourcehan
    )
    is_song = any(token in normalized_hint for token in ("song", "宋体", "simsun"))

    if is_sourcehan:
        # 思源黑体安装目录下的常用文件名
        if is_bold:
            return [
                "SourceHanSansCN-Bold.otf", "SourceHanSansCN-Heavy.otf",
                "NotoSansCJKsc-Bold.otf", "msyhbd.ttc", "simhei.ttf",
            ]
        style = normalized_hint
        if "extralight" in style or "ultralight" in style:
            return ["SourceHanSansCN-ExtraLight.otf", "NotoSansCJKsc-Thin.otf", "msyh.ttc"]
        if "light" in style:
            return ["SourceHanSansCN-Light.otf", "NotoSansCJKsc-Light.otf", "msyh.ttc"]
        if "medium" in style:
            return ["SourceHanSansCN-Medium.otf", "NotoSansCJKsc-Medium.otf", "msyh.ttc"]
        if "regular" in style or "normal" in style:
            return ["SourceHanSansCN-Regular.otf", "NotoSansCJKsc-Regular.otf", "msyh.ttc"]
        return ["SourceHanSansCN-Regular.otf", "NotoSansCJKsc-Regular.otf", "msyh.ttc"]

    if is_bold:
        names = ["msyhbd.ttc", "simhei.ttf", "SourceHanSansCN-Bold.otf", "NotoSansCJKsc-Bold.otf"]
    elif is_yahei:
        names = ["msyh.ttc", "msyhbd.ttc"]
    elif is_hei:
        names = ["simhei.ttf", "msyh.ttc"]
    elif is_song:
        names = ["simsun.ttc", "simsunb.ttf"]
    else:
        names = ["msyh.ttc", "simsun.ttc", "simhei.ttf"]
    return names


def font_match_score(target: str, candidate: str) -> int:
    if not target or not candidate:
        return 0
    if target == candidate:
        return 100
    if target in candidate or candidate in target:
        return max(20, min(len(target), len(candidate)))
    score = 0
    for token in ("bold", "black", "heavy", "medium", "regular", "light", "song", "hei", "yahei", "simhei", "simsun", "noto", "sourcehan"):
        if token in target and token in candidate:
            score += 4
    target_chunks = [chunk for chunk in re.split(r"(bold|black|heavy|medium|regular|light|italic|oblique)", target) if len(chunk) >= 4]
    for chunk in target_chunks:
        if chunk in candidate:
            score += min(len(chunk), 16)
    return score


def _upscale_realesrgan(input_path: str, output_path: str, scale: int) -> dict:
    try:
        RRDBNet, RealESRGANer = _import_realesrgan()
    except Exception as exc:
        return {
            "success": False,
            "error": f"Real-ESRGAN is not installed or failed to load: {exc}",
            "missing_optional_engine": "realesrgan",
        }

    try:
        import torch

        model = RRDBNet(
            num_in_ch=3,
            num_out_ch=3,
            num_feat=64,
            num_block=23,
            num_grow_ch=32,
            scale=4,
        )
        model_path = _realesrgan_model_path()
        use_cuda = torch.cuda.is_available()
        upsampler = RealESRGANer(
            scale=4,
            model_path=str(model_path),
            model=model,
            tile=0,
            tile_pad=10,
            pre_pad=0,
            half=use_cuda,
            device="cuda" if use_cuda else "cpu",
        )

        image = cv2.imread(input_path, cv2.IMREAD_UNCHANGED)
        if image is None:
            raise FileNotFoundError(f"Input file does not exist or cannot be read: {input_path}")

        output, _ = upsampler.enhance(image, outscale=scale)
        _ensure_parent(output_path)
        cv2.imwrite(output_path, output)
        return _response(output_path)
    except Exception as exc:
        return {"success": False, "error": str(exc)}


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="127.0.0.1", port=18765, log_level="info")
