from __future__ import annotations

import json
import os
from pathlib import Path
from typing import List, NamedTuple, Optional
from urllib.parse import urlsplit


class AiImageConfigurationError(RuntimeError):
    pass


class AiImageRuntimeConfig(NamedTuple):
    api_key: str
    base_url: str


def _config_path() -> Path:
    overridden_path = os.environ.get("HOPEFLOW_AI_IMAGE_CONFIG", "").strip()
    return Path(overridden_path) if overridden_path else Path.home() / ".hopeflow" / "ai-engine" / "config.json"


def _read_payload() -> dict:
    config_path = _config_path()
    if not config_path.is_file():
        return {}
    try:
        payload = json.loads(config_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise AiImageConfigurationError(f"AI image config cannot be read: {exc}") from exc
    if not isinstance(payload, dict):
        raise AiImageConfigurationError("AI image config must contain a JSON object.")
    return payload


def _providers(payload: dict) -> List[dict]:
    raw = payload.get("ai_image_providers")
    return [item for item in raw if isinstance(item, dict)] if isinstance(raw, list) else []


def _clean(value: object) -> str:
    return value.strip() if isinstance(value, str) else ""


def _resolve_credentials(payload: dict, provider: Optional[str]) -> tuple[str, str]:
    """Resolve (api_key, base_url) for the requested provider.

    Multi-platform: pick the provider whose id/name matches `provider`, else the
    config's active provider, else the first one. Falls back to the legacy single
    `ai_image_api_key` / `ai_image_base_url` fields when no providers are defined.
    """
    providers = _providers(payload)
    if providers:
        wanted = provider or _clean(payload.get("ai_image_active"))
        chosen = None
        if wanted:
            chosen = next(
                (p for p in providers if _clean(p.get("id")) == wanted or _clean(p.get("name")) == wanted),
                None,
            )
        if chosen is None:
            chosen = providers[0]
        return _clean(chosen.get("api_key")), _clean(chosen.get("base_url"))

    return _clean(payload.get("ai_image_api_key")), _clean(payload.get("ai_image_base_url"))


def _validated_base_url(value: str) -> str:
    normalized = value.rstrip("/")
    parsed = urlsplit(normalized)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise AiImageConfigurationError("AI image base URL must use http:// or https://.")
    return normalized


def load_ai_image_runtime_config(default_base_url: str, provider: Optional[str] = None) -> AiImageRuntimeConfig:
    payload = _read_payload()
    configured_key, configured_url = _resolve_credentials(payload, provider)
    # The panel-managed config file is the source of truth. Environment variables
    # only act as a fallback when the file has no value, so a stale exported key
    # can never silently override what the user saved in the UI.
    api_key = configured_key or os.environ.get("HOPEFLOW_AI_IMAGE_API_KEY", "").strip()
    base_url = configured_url or os.environ.get("HOPEFLOW_AI_IMAGE_BASE_URL", "").strip() or default_base_url
    if not api_key:
        raise AiImageConfigurationError(
            "Missing AI image API key. Configure a platform in Settings → AI 绘图."
        )
    return AiImageRuntimeConfig(api_key=api_key, base_url=_validated_base_url(base_url))
