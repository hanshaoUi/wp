from fastapi import APIRouter

from large_pdf_raster import router as pdf_raster_router
from spot_pdf_tiff import router as spot_pdf_tiff_router
from spot_tiff import router as spot_tiff_router

router = APIRouter()
router.include_router(pdf_raster_router)
router.include_router(spot_pdf_tiff_router)
router.include_router(spot_tiff_router)
