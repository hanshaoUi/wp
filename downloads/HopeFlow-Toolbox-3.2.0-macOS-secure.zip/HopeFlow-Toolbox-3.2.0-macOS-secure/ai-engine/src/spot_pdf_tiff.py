from __future__ import annotations

import re
import sys
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Final, Literal

import numpy as np
import pymupdf
import tifffile
from fastapi import APIRouter
from pydantic import BaseModel, ConfigDict, Field
from pypdf import PdfWriter
from pypdf.errors import PdfReadError
from pypdf.generic import (
    ArrayObject,
    ContentStream,
    DictionaryObject,
    FloatObject,
    IndirectObject,
    NameObject,
    NumberObject,
    PdfObject,
)

from photoshop_spot_metadata import SpotCmyk, normalize_spot_cmyk
from photoshop_spot_pdf import SpotPdfWriteSpec, write_photoshop_spot_pdf
from spot_tiff_writer import TIFF_CHANNELS, SpotTiffWriteSpec, write_spot_tiff


RENDER_STRIP_HEIGHT: Final = 512
PDF_NAME_ESCAPE: Final = re.compile(r"#([0-9a-fA-F]{2})")

router = APIRouter()


class SpotPdfTiffRequest(BaseModel):
    model_config = ConfigDict(frozen=True, str_strip_whitespace=True)

    input: str = Field(min_length=1)
    output: str = Field(min_length=1)
    spot_name: str = Field(min_length=1, max_length=64)
    dpi: int = Field(gt=0, le=2400)
    page_index: int = Field(default=0, ge=0)
    output_format: Literal["TIFF", "PDF"] = "TIFF"


class SpotPdfTiffResponse(BaseModel):
    model_config = ConfigDict(frozen=True)

    success: bool
    output: str = ""
    width_px: int = 0
    height_px: int = 0
    spot_name: str = ""
    output_format: Literal["TIFF", "PDF"] = "TIFF"
    compression: Literal["none"] = "none"
    error: str = ""


class SpotPdfTiffError(Exception):
    __slots__ = ("reason", "detail")

    def __init__(
        self,
        reason: Literal[
            "missing-input",
            "empty-pdf",
            "page-out-of-range",
            "missing-separation",
            "render-size-mismatch",
        ],
        detail: str = "",
    ) -> None:
        self.reason = reason
        self.detail = detail
        super().__init__()

    def __str__(self) -> str:
        messages = {
            "missing-input": "找不到专色 PDF 中间文件",
            "empty-pdf": "专色 PDF 中没有可转换的页面",
            "page-out-of-range": "请求的专色 PDF 页面超出范围",
            "missing-separation": "PDF 中没有找到指定的专色色版",
            "render-size-mismatch": "PDF 分色渲染尺寸不一致",
        }
        suffix = f": {self.detail}" if self.detail else ""
        return f"{messages[self.reason]}{suffix}"


def _resolve(value: PdfObject | None) -> PdfObject | None:
    return value.get_object() if isinstance(value, IndirectObject) else value


def _dictionary(value: PdfObject | None) -> DictionaryObject | None:
    resolved = _resolve(value)
    return resolved if isinstance(resolved, DictionaryObject) else None


def _decode_pdf_name(value: PdfObject) -> str:
    raw_name = str(value).removeprefix("/")
    if "#" not in raw_name:
        return raw_name
    encoded = PDF_NAME_ESCAPE.sub(lambda match: chr(int(match.group(1), 16)), raw_name)
    return encoded.encode("latin-1").decode("utf-8", errors="replace")


def _tint_function(full_ink: tuple[int, int, int, int]) -> DictionaryObject:
    return DictionaryObject(
        {
            NameObject("/FunctionType"): NumberObject(2),
            NameObject("/Domain"): ArrayObject([FloatObject(0), FloatObject(1)]),
            NameObject("/C0"): ArrayObject([FloatObject(0) for _ in range(4)]),
            NameObject("/C1"): ArrayObject([FloatObject(value) for value in full_ink]),
            NameObject("/N"): FloatObject(1),
        }
    )


class SeparationRewriter:
    __slots__ = ("_full_ink", "_spot_name", "_spot_cmyk", "_visited")

    def __init__(self, spot_name: str, full_ink: tuple[int, int, int, int]) -> None:
        self._spot_name = spot_name
        self._full_ink = full_ink
        self._spot_cmyk: SpotCmyk | None = None
        self._visited: set[int] = set()

    @property
    def spot_cmyk(self) -> SpotCmyk | None:
        return self._spot_cmyk

    def rewrite_page(self, page: DictionaryObject) -> int:
        return self._rewrite_resources(page.get("/Resources"))

    def _rewrite_resources(self, value: PdfObject | None) -> int:
        resources = _dictionary(value)
        if resources is None or id(resources) in self._visited:
            return 0
        self._visited.add(id(resources))

        replacements = 0
        color_spaces = _dictionary(resources.get("/ColorSpace"))
        if color_spaces is not None:
            for color_space in color_spaces.values():
                replacements += self._rewrite_color_space(color_space)

        for resource_type in ("/XObject", "/Pattern"):
            children = _dictionary(resources.get(resource_type))
            if children is None:
                continue
            for child in children.values():
                child_dictionary = _dictionary(child)
                if child_dictionary is not None:
                    replacements += self._rewrite_resources(child_dictionary.get("/Resources"))
        return replacements

    def _rewrite_color_space(self, value: PdfObject) -> int:
        color_space = _resolve(value)
        if not isinstance(color_space, ArrayObject) or len(color_space) < 4:
            return 0
        if str(_resolve(color_space[0])) != "/Separation":
            return 0
        colorant = _resolve(color_space[1])
        if colorant is None or _decode_pdf_name(colorant) != self._spot_name:
            return 0
        if self._spot_cmyk is None and str(_resolve(color_space[2])) == "/DeviceCMYK":
            tint = _dictionary(color_space[3])
            c1 = _resolve(tint.get("/C1")) if tint is not None else None
            if isinstance(c1, ArrayObject) and len(c1) >= 4:
                try:
                    self._spot_cmyk = normalize_spot_cmyk(
                        tuple(float(_resolve(component)) for component in c1[:4])
                    )
                except (TypeError, ValueError):
                    self._spot_cmyk = None
        color_space[2] = NameObject("/DeviceCMYK")
        color_space[3] = _tint_function(self._full_ink)
        return 1


_FILL_PAINT: Final = frozenset((b"f", b"F", b"f*", b"b", b"b*", b"B", b"B*"))
_STROKE_PAINT: Final = frozenset((b"S", b"s", b"b", b"b*", b"B", b"B*"))
_CLOSING_PAINT: Final = frozenset((b"s", b"b", b"b*"))
_DEVICE_FILL: Final = frozenset((b"g", b"rg", b"k"))
_DEVICE_STROKE: Final = frozenset((b"G", b"RG", b"K"))


class SpotPaintSuppressor:
    """Rewrite content streams so objects painted in the target spot Separation
    do not mark the page. Painting always knocks out whatever lies beneath it —
    even at zero ink — so the only way to keep the underlying process colour (the
    red底) intact for the CMYK channels is to stop the spot object from painting
    at all. The path is still consumed (turned into ``n``) so clipping survives.
    """

    __slots__ = ("_spot_name", "_visited", "_changed")

    def __init__(self, spot_name: str) -> None:
        self._spot_name = spot_name
        self._visited: set[int] = set()
        self._changed = False

    @property
    def changed(self) -> bool:
        return self._changed

    def _target_names(self, resources: DictionaryObject | None) -> set[str]:
        names: set[str] = set()
        color_spaces = _dictionary(resources.get("/ColorSpace")) if resources is not None else None
        if color_spaces is None:
            return names
        for key, value in color_spaces.items():
            color_space = _resolve(value)
            if not isinstance(color_space, ArrayObject) or len(color_space) < 4:
                continue
            if str(_resolve(color_space[0])) != "/Separation":
                continue
            colorant = _resolve(color_space[1])
            if colorant is not None and _decode_pdf_name(colorant) == self._spot_name:
                names.add(str(key))
        return names

    @staticmethod
    def _neutralize(op: bytes, drop_fill: bool, drop_stroke: bool) -> list[tuple[list, bytes]]:
        fill_only = op in _FILL_PAINT and op not in _STROKE_PAINT
        stroke_only = op in _STROKE_PAINT and op not in _FILL_PAINT
        prefix: list[tuple[list, bytes]] = [([], b"h")] if op in _CLOSING_PAINT else []
        if fill_only:
            return [([], b"n")]
        if stroke_only:
            return prefix + [([], b"n" if drop_stroke else op)]
        # fill + stroke (B / B* / b / b*)
        if drop_fill and drop_stroke:
            return prefix + [([], b"n")]
        if drop_fill:
            return prefix + [([], b"S")]
        return [([], b"f*" if op in (b"B*", b"b*") else b"f")]

    def _suppress_stream(
        self,
        stream_obj: PdfObject,
        resources: DictionaryObject | None,
        reader: object,
    ) -> ContentStream | None:
        if stream_obj is None:
            return None
        names = self._target_names(resources)
        if not names:
            return None
        content = ContentStream(stream_obj, reader)
        fill_spot = False
        stroke_spot = False
        stack: list[tuple[bool, bool]] = []
        operations: list[tuple[list, bytes]] = []
        touched = False
        for operands, op in content.operations:
            if op == b"q":
                stack.append((fill_spot, stroke_spot))
            elif op == b"Q":
                if stack:
                    fill_spot, stroke_spot = stack.pop()
            elif op == b"cs":
                fill_spot = len(operands) == 1 and str(operands[0]) in names
            elif op == b"CS":
                stroke_spot = len(operands) == 1 and str(operands[0]) in names
            elif op in _DEVICE_FILL:
                fill_spot = False
            elif op in _DEVICE_STROKE:
                stroke_spot = False
            drop_fill = op in _FILL_PAINT and fill_spot
            drop_stroke = op in _STROKE_PAINT and stroke_spot
            if drop_fill or drop_stroke:
                operations.extend(self._neutralize(op, drop_fill, drop_stroke))
                touched = True
            else:
                operations.append((operands, op))
        if not touched:
            return None
        content.operations = operations
        self._changed = True
        return content

    def suppress_page(self, page: DictionaryObject, reader: object) -> None:
        resources = _dictionary(page.get("/Resources"))
        rewritten = self._suppress_stream(page.get_contents(), resources, reader)
        if rewritten is not None:
            page.replace_contents(rewritten)
        self._suppress_xobjects(resources, reader)

    def _suppress_xobjects(self, resources: DictionaryObject | None, reader: object) -> None:
        if resources is None or id(resources) in self._visited:
            return
        self._visited.add(id(resources))
        xobjects = _dictionary(resources.get("/XObject"))
        if xobjects is None:
            return
        for value in xobjects.values():
            xobject = _resolve(value)
            if not isinstance(xobject, DictionaryObject):
                continue
            child_resources = _dictionary(xobject.get("/Resources")) or resources
            if str(xobject.get("/Subtype")) == "/Form":
                rewritten = self._suppress_stream(xobject, child_resources, reader)
                if rewritten is not None:
                    xobject.set_data(rewritten.get_data())
            self._suppress_xobjects(child_resources, reader)


def _write_base_variant(
    source_path: Path,
    output_path: Path,
    request: SpotPdfTiffRequest,
) -> None:
    writer = PdfWriter(clone_from=source_path)
    if request.page_index >= len(writer.pages):
        raise SpotPdfTiffError("page-out-of-range")
    page = writer.pages[request.page_index]
    suppressor = SpotPaintSuppressor(request.spot_name)
    suppressor.suppress_page(page, writer)
    with output_path.open("wb") as stream:
        writer.write(stream)


def _write_variant(
    source_path: Path,
    output_path: Path,
    request: SpotPdfTiffRequest,
    full_ink: tuple[int, int, int, int],
) -> SpotCmyk | None:
    writer = PdfWriter(clone_from=source_path)
    if len(writer.pages) < 1:
        raise SpotPdfTiffError("empty-pdf")
    if request.page_index >= len(writer.pages):
        raise SpotPdfTiffError("page-out-of-range")
    page = writer.pages[request.page_index]
    rewriter = SeparationRewriter(request.spot_name, full_ink)
    replacements = rewriter.rewrite_page(page)
    if replacements < 1:
        raise SpotPdfTiffError("missing-separation", request.spot_name)
    with output_path.open("wb") as stream:
        writer.write(stream)
    return rewriter.spot_cmyk


def _render_cmyk_strip(
    page: pymupdf.Page,
    y_start: int,
    y_end: int,
    dpi: int,
    expected_width: int | None = None,
) -> np.ndarray:
    scale = dpi / 72
    clip = pymupdf.Rect(
        page.rect.x0,
        page.rect.y0 + y_start / scale,
        page.rect.x1,
        page.rect.y0 + y_end / scale,
    )
    pixmap = page.get_pixmap(
        matrix=pymupdf.Matrix(scale, scale),
        clip=clip,
        colorspace=pymupdf.csCMYK,
        alpha=False,
    )
    actual_shape = (pixmap.height, pixmap.width, pixmap.n)
    # Width comes from the actual pixmap, not round(rect.width*dpi/72): MuPDF
    # rounds a full-width clip's raster extent and can land 1px off the analytic
    # value. The first strip fixes the canonical width (expected_width=None) and
    # every later strip/separation must match it, so all bands stack cleanly.
    # For sizes where the two agree (the common case) this is byte-identical to
    # the old strict check.
    expected_shape = (
        y_end - y_start,
        pixmap.width if expected_width is None else expected_width,
        4,
    )
    if actual_shape != expected_shape:
        raise SpotPdfTiffError(
            "render-size-mismatch",
            f"expected {expected_shape}, received {actual_shape}",
        )
    return np.frombuffer(pixmap.samples_mv, dtype=np.uint8).reshape(actual_shape).copy()


def _render_separations(
    source_path: Path,
    base_path: Path,
    clear_path: Path,
    black_path: Path,
    memory_path: Path,
    composite_memory_path: Path | None,
    request: SpotPdfTiffRequest,
) -> tuple[np.memmap, np.memmap | None, int, int, float, float]:
    source_document = pymupdf.open(source_path) if composite_memory_path is not None else None
    try:
        with pymupdf.open(base_path) as base_document, pymupdf.open(
            clear_path
        ) as clear_document, pymupdf.open(black_path) as black_document:
            source_page = source_document[request.page_index] if source_document is not None else None
            base_page = base_document[request.page_index]
            clear_page = clear_document[request.page_index]
            black_page = black_document[request.page_index]
            height = round(base_page.rect.height * request.dpi / 72)
            if height < 1:
                raise SpotPdfTiffError("render-size-mismatch", f"0x{height}")
            # Width is taken from the first rendered strip (see _render_cmyk_strip)
            # so the memmaps are sized to MuPDF's actual raster width; the buffers
            # are therefore allocated lazily on the first band.
            canvas: np.memmap | None = None
            composite: np.memmap | None = None
            width = 0
            for y_start in range(0, height, RENDER_STRIP_HEIGHT):
                y_end = min(y_start + RENDER_STRIP_HEIGHT, height)
                base_strip = _render_cmyk_strip(
                    base_page, y_start, y_end, request.dpi, width or None
                )
                if canvas is None:
                    width = base_strip.shape[1]
                    if width < 1:
                        raise SpotPdfTiffError("render-size-mismatch", f"{width}x{height}")
                    canvas = np.memmap(
                        memory_path,
                        mode="w+",
                        dtype=np.uint8,
                        shape=(height, width, TIFF_CHANNELS),
                    )
                    composite = np.memmap(
                        composite_memory_path,
                        mode="w+",
                        dtype=np.uint8,
                        shape=(height, width, 4),
                    ) if composite_memory_path is not None else None
                clear_strip = _render_cmyk_strip(clear_page, y_start, y_end, request.dpi, width)
                separation_strip = _render_cmyk_strip(black_page, y_start, y_end, request.dpi, width)
                canvas[y_start:y_end, :, :4] = base_strip
                clear_black = clear_strip[:, :, 3].astype(np.int16)
                separation_black = separation_strip[:, :, 3].astype(np.int16)
                canvas[y_start:y_end, :, 4] = np.clip(
                    separation_black - clear_black,
                    0,
                    255,
                ).astype(np.uint8)
                if composite is not None and source_page is not None:
                    composite[y_start:y_end] = _render_cmyk_strip(
                        source_page,
                        y_start,
                        y_end,
                        request.dpi,
                        width,
                    )
            if canvas is None:
                raise SpotPdfTiffError("render-size-mismatch", f"0x{height}")
            canvas.flush()
            if composite is not None:
                composite.flush()
            return canvas, composite, width, height, base_page.rect.width, base_page.rect.height
    finally:
        if source_document is not None:
            source_document.close()


def _release_memmaps(*arrays: "np.memmap | None") -> None:
    """Windows keeps the backing file locked for the lifetime of a numpy memmap,
    so the TemporaryDirectory cleanup fails with WinError 32 on pixels.bin /
    composite.bin. Close the underlying mmap explicitly once rendering is done.
    Unix unlinks mapped files fine, so macOS keeps its original `del` path and
    stays byte-for-byte unchanged.
    """
    if sys.platform != "win32":
        return
    for array in arrays:
        if array is None:
            continue
        mm = getattr(array, "_mmap", None)
        if mm is not None:
            mm.close()


def render_spot_pdf_tiff(request: SpotPdfTiffRequest) -> SpotPdfTiffResponse:
    input_path = Path(request.input)
    if not input_path.is_file():
        return SpotPdfTiffResponse(success=False, error=str(SpotPdfTiffError("missing-input")))

    # On Windows, releasing the memmaps below normally lets cleanup succeed, but
    # ignore_cleanup_errors guards against a residual lock (e.g. AV scanning the
    # freshly written .bin) turning a completed export into a failure. The empty
    # kwargs keep the macOS call byte-identical.
    tempdir_kwargs = {"ignore_cleanup_errors": True} if sys.platform == "win32" else {}
    try:
        with TemporaryDirectory(prefix="hf-spot-pdf-tiff-", **tempdir_kwargs) as temporary_directory:
            temporary_path = Path(temporary_directory)
            base_path = temporary_path / "spot-base.pdf"
            clear_path = temporary_path / "spot-clear.pdf"
            black_path = temporary_path / "spot-black.pdf"
            spot_cmyk = _write_variant(input_path, clear_path, request, (0, 0, 0, 0))
            _write_variant(input_path, black_path, request, (0, 0, 0, 1))
            _write_base_variant(input_path, base_path, request)
            composite_memory_path = temporary_path / "composite.bin" if request.output_format == "PDF" else None
            canvas, composite, width, height, page_width_pt, page_height_pt = _render_separations(
                input_path,
                base_path,
                clear_path,
                black_path,
                temporary_path / "pixels.bin",
                composite_memory_path,
                request,
            )
            resolved_cmyk = spot_cmyk or (0.0, 0.0, 0.0, 1.0)
            if request.output_format == "PDF":
                write_photoshop_spot_pdf(
                    SpotPdfWriteSpec(
                        output=request.output,
                        spot_name=request.spot_name,
                        dpi=request.dpi,
                        width=width,
                        height=height,
                        page_width_pt=page_width_pt,
                        page_height_pt=page_height_pt,
                        spot_cmyk=resolved_cmyk,
                    ),
                    canvas,
                    composite,
                )
            else:
                write_spot_tiff(
                    SpotTiffWriteSpec(
                        output=request.output,
                        spot_name=request.spot_name,
                        dpi=request.dpi,
                        width=width,
                        height=height,
                        spot_cmyk=resolved_cmyk,
                    ),
                    canvas,
                )
            # Close the mmaps before the TemporaryDirectory cleanup deletes the
            # backing files (no-op on macOS; see _release_memmaps).
            _release_memmaps(canvas, composite)
            del canvas
            if composite is not None:
                del composite
        return SpotPdfTiffResponse(
            success=True,
            output=request.output,
            width_px=width,
            height_px=height,
            spot_name=request.spot_name,
            output_format=request.output_format,
        )
    except SpotPdfTiffError as error:
        return SpotPdfTiffResponse(success=False, error=str(error))
    except (MemoryError, OSError, RuntimeError, ValueError, PdfReadError, tifffile.TiffFileError) as error:
        return SpotPdfTiffResponse(success=False, error=f"PDF 专色文档写入失败: {error}")


@router.post("/spot_pdf_tiff")
def spot_pdf_tiff(request: SpotPdfTiffRequest) -> SpotPdfTiffResponse:
    return render_spot_pdf_tiff(request)
