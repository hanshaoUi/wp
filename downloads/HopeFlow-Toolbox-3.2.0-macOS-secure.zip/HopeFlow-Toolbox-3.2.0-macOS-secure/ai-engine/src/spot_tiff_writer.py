from __future__ import annotations

from pathlib import Path
from typing import Final, NamedTuple

import numpy as np
import tifffile
from numpy.typing import NDArray

from photoshop_spot_metadata import SpotCmyk, normalize_spot_cmyk, photoshop_tiff_image_resources


TIFF_CHANNELS: Final = 5
TIFF_CLASSIC_LIMIT: Final = 4_000_000_000
TIFF_HEADROOM: Final = 32 * 1024 * 1024
TIFF_ROWS_PER_STRIP: Final = 512
class SpotTiffWriteSpec(NamedTuple):
    output: str
    spot_name: str
    dpi: int
    width: int
    height: int
    spot_cmyk: SpotCmyk = (0.0, 0.0, 0.0, 1.0)


def write_spot_tiff(spec: SpotTiffWriteSpec, pixels: NDArray[np.uint8]) -> None:
    output_path = Path(spec.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    byte_size = spec.width * spec.height * TIFF_CHANNELS
    image_resources = photoshop_tiff_image_resources(
        spec.spot_name,
        normalize_spot_cmyk(spec.spot_cmyk),
    )
    # Photoshop reads the extra spot channel inverted relative to the CMYK inks
    # (0 = full spot ink). The canvas stores it as coverage (255 = full), so flip
    # channel 5 in place before writing; CMYK channels keep the ink convention.
    pixels[..., 4] = np.bitwise_not(pixels[..., 4])
    tifffile.imwrite(
        output_path,
        pixels,
        bigtiff=byte_size >= TIFF_CLASSIC_LIMIT - TIFF_HEADROOM,
        photometric="separated",
        planarconfig="contig",
        extrasamples="unspecified",
        compression=None,
        metadata=None,
        resolution=(spec.dpi, spec.dpi),
        resolutionunit="INCH",
        rowsperstrip=TIFF_ROWS_PER_STRIP,
        extratags=[
            (34377, "B", len(image_resources), image_resources, False),
        ],
    )
