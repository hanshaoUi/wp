from __future__ import annotations

import struct
import zlib
from collections import deque
from concurrent.futures import Future, ThreadPoolExecutor
from pathlib import Path
from typing import Final, Iterator, Literal, NamedTuple

import numpy
import pymupdf
import tifffile
from fastapi import APIRouter
from PIL import Image
from pydantic import BaseModel, ConfigDict, Field


JPEG_DIMENSION_LIMIT: Final = 65_535
JPEG_PIPELINE_PIXEL_LIMIT: Final = 16_000_000
JPEG_PIPELINE_WORKERS: Final = 2
# Strip-sequential rendering beats one full-page get_pixmap (smaller allocations,
# better cache locality) and lets PNG/TIFF encode overlap rendering while keeping
# memory at strip level. Strips are bit-identical to a single render.
RASTER_STRIP_HEIGHT: Final = 1_024
# zlib level 3 encodes ~2x faster than PIL's default 6 at nearly the same size.
PNG_COMPRESS_LEVEL: Final = 3


class RenderedPixels(NamedTuple):
    owner: pymupdf.Pixmap
    samples: memoryview
    width: int
    height: int


class PdfJpegTarget(BaseModel):
    model_config = ConfigDict(frozen=True)

    page_index: int = Field(ge=0)
    output: str = Field(min_length=1)


class PdfToJpegRequest(BaseModel):
    model_config = ConfigDict(frozen=True)

    input: str
    output: str = ""
    targets: tuple[PdfJpegTarget, ...] = ()
    dpi: float = Field(gt=0, le=2_400)
    scale: float = Field(default=1, gt=0, le=75_000)
    quality: int = Field(default=95, ge=1, le=100)
    format: Literal["JPEG", "PNG", "TIFF"] = "JPEG"


# Pixel layout per output format. PNG keeps alpha for transparent artboards;
# TIFF stays CMYK to match the print-oriented spot pipeline.
class _PixelLayout(NamedTuple):
    mode: str
    colorspace_name: str
    alpha: bool
    channels: int


_PIXEL_LAYOUTS: Final = {
    "JPEG": _PixelLayout("RGB", "rgb", False, 3),
    "PNG": _PixelLayout("RGBA", "rgb", True, 4),
    "TIFF": _PixelLayout("CMYK", "cmyk", False, 4),
}


def _layout_colorspace(layout: _PixelLayout) -> pymupdf.Colorspace:
    return pymupdf.csCMYK if layout.colorspace_name == "cmyk" else pymupdf.csRGB


class RasterizedJpeg(BaseModel):
    model_config = ConfigDict(frozen=True)

    page_index: int
    output: str
    width_px: int
    height_px: int


class PdfToJpegResponse(BaseModel):
    model_config = ConfigDict(frozen=True)

    success: bool
    output: str = ""
    width_px: int = 0
    height_px: int = 0
    pages: tuple[RasterizedJpeg, ...] = ()
    error: str = ""


router = APIRouter()


class PdfRasterError(Exception):
    __slots__ = ("reason",)

    def __init__(
        self,
        reason: Literal[
            "missing-input",
            "missing-output",
            "empty-pdf",
            "page-out-of-range",
            "jpeg-dimension-limit",
            "render-size-mismatch",
        ],
    ) -> None:
        self.reason = reason
        super().__init__()

    def __str__(self) -> str:
        messages = {
            "missing-input": "找不到 PDF 中间文件",
            "missing-output": "请指定 JPG 输出文件",
            "empty-pdf": "PDF 中没有可栅格化的页面",
            "page-out-of-range": "请求的画板页超出 PDF 页面范围",
            "jpeg-dimension-limit": "JPG 单边最大支持 65535px，请降低比例/DPI 或改用 TIFF、PNG、PDF",
            "render-size-mismatch": "PDF 分条渲染尺寸不一致",
        }
        return messages[self.reason]


def _targets_for(request: PdfToJpegRequest) -> tuple[PdfJpegTarget, ...]:
    if request.targets:
        return request.targets
    if request.output:
        return (PdfJpegTarget(page_index=0, output=request.output),)
    raise PdfRasterError("missing-output")


def _page_dimensions(page: pymupdf.Page, request: PdfToJpegRequest) -> tuple[int, int]:
    render_dpi = request.dpi * request.scale
    return (
        round(page.rect.width * render_dpi / 72),
        round(page.rect.height * render_dpi / 72),
    )


def _save_pixmap(
    pixels: RenderedPixels,
    target: PdfJpegTarget,
    request: PdfToJpegRequest,
) -> RasterizedJpeg:
    output_path = Path(target.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    image = Image.frombuffer("RGB", (pixels.width, pixels.height), pixels.samples, "raw", "RGB", 0, 1)
    try:
        image.save(
            output_path,
            format="JPEG",
            quality=request.quality,
            dpi=(request.dpi, request.dpi),
            progressive=False,
            optimize=False,
            subsampling=0,
        )
    finally:
        image.close()
    return RasterizedJpeg(
        page_index=target.page_index,
        output=str(output_path),
        width_px=pixels.width,
        height_px=pixels.height,
    )


def _render_pixels(page: pymupdf.Page, request: PdfToJpegRequest) -> RenderedPixels:
    render_scale = request.dpi * request.scale / 72
    pixmap = page.get_pixmap(
        matrix=pymupdf.Matrix(render_scale, render_scale),
        colorspace=pymupdf.csRGB,
        alpha=False,
    )
    return RenderedPixels(
        owner=pixmap,
        samples=pixmap.samples_mv,
        width=pixmap.width,
        height=pixmap.height,
    )


def _actual_raster_width(page: pymupdf.Page, request: PdfToJpegRequest) -> int:
    """MuPDF can round a full-width clip's raster extent 1px off the analytic
    round(rect.width*dpi/72). Probe the real width from a single-row render so
    the PNG/TIFF header and _render_strips' width check agree; otherwise a large
    export at a "divergent" size fails with render-size-mismatch. Mirrors the
    JPEG (_save_jpeg_via_strips) and spot (_render_cmyk_strip) paths. For sizes
    where the two agree — the common case — this returns the same value as
    _page_dimensions, so output stays byte-for-byte identical.
    """
    layout = _PIXEL_LAYOUTS[request.format]
    render_scale = request.dpi * request.scale / 72
    clip = pymupdf.Rect(
        page.rect.x0,
        page.rect.y0,
        page.rect.x1,
        page.rect.y0 + 1 / render_scale,
    )
    pixmap = page.get_pixmap(
        matrix=pymupdf.Matrix(render_scale, render_scale),
        clip=clip,
        colorspace=_layout_colorspace(layout),
        alpha=layout.alpha,
    )
    return pixmap.width


def _render_strips(
    page: pymupdf.Page,
    request: PdfToJpegRequest,
    width: int,
    height: int,
) -> Iterator[bytes]:
    """Yield raster rows in RASTER_STRIP_HEIGHT bands (bit-identical to one full render)."""
    layout = _PIXEL_LAYOUTS[request.format]
    colorspace = _layout_colorspace(layout)
    render_scale = request.dpi * request.scale / 72
    matrix = pymupdf.Matrix(render_scale, render_scale)
    for y_start in range(0, height, RASTER_STRIP_HEIGHT):
        y_end = min(y_start + RASTER_STRIP_HEIGHT, height)
        clip = pymupdf.Rect(
            page.rect.x0,
            page.rect.y0 + y_start / render_scale,
            page.rect.x1,
            page.rect.y0 + y_end / render_scale,
        )
        pixmap = page.get_pixmap(matrix=matrix, clip=clip, colorspace=colorspace, alpha=layout.alpha)
        if pixmap.width != width or pixmap.height != y_end - y_start:
            raise PdfRasterError("render-size-mismatch")
        yield bytes(pixmap.samples_mv)


def _png_chunk(tag: bytes, payload: bytes) -> bytes:
    return (
        struct.pack(">I", len(payload))
        + tag
        + payload
        + struct.pack(">I", zlib.crc32(tag + payload))
    )


def _stream_png(
    output_path: Path,
    strips: Iterator[bytes],
    width: int,
    height: int,
    dpi: float,
) -> None:
    """Stream an RGBA PNG strip by strip so encoding overlaps rendering and
    memory stays at strip level. Filter 0 rows + zlib level 3 encode ~2-3x
    faster than PIL's default whole-image save."""
    row_bytes = width * 4
    pixels_per_meter = round(dpi / 0.0254)
    header = struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0)
    compressor = zlib.compressobj(level=PNG_COMPRESS_LEVEL)
    with output_path.open("wb") as stream:
        stream.write(b"\x89PNG\r\n\x1a\n")
        stream.write(_png_chunk(b"IHDR", header))
        stream.write(_png_chunk(b"pHYs", struct.pack(">IIB", pixels_per_meter, pixels_per_meter, 1)))
        for strip in strips:
            rows = len(strip) // row_bytes
            # Prepend the filter byte to every row in one vectorized pass.
            filtered = numpy.empty((rows, 1 + row_bytes), dtype=numpy.uint8)
            filtered[:, 0] = 0
            filtered[:, 1:] = numpy.frombuffer(strip, dtype=numpy.uint8).reshape(rows, row_bytes)
            encoded = compressor.compress(filtered.tobytes())
            if encoded:
                stream.write(_png_chunk(b"IDAT", encoded))
        stream.write(_png_chunk(b"IDAT", compressor.flush()))
        stream.write(_png_chunk(b"IEND", b""))


def _stream_tiff(
    output_path: Path,
    strips: Iterator[bytes],
    width: int,
    height: int,
    dpi: float,
) -> None:
    """Stream an uncompressed CMYK TIFF strip by strip via tifffile."""
    def strip_arrays() -> Iterator[numpy.ndarray]:
        for strip in strips:
            rows = len(strip) // (width * 4)
            yield numpy.frombuffer(strip, dtype=numpy.uint8).reshape(rows, width, 4)

    tifffile.imwrite(
        output_path,
        strip_arrays(),
        shape=(height, width, 4),
        dtype="uint8",
        bigtiff=width * height * 4 >= 4_000_000_000 - 32 * 1024 * 1024,
        photometric="separated",
        planarconfig="contig",
        compression=None,
        metadata=None,
        resolution=(dpi, dpi),
        resolutionunit="INCH",
        rowsperstrip=RASTER_STRIP_HEIGHT,
    )


def _stream_image(
    document: pymupdf.Document,
    target: PdfJpegTarget,
    request: PdfToJpegRequest,
) -> RasterizedJpeg:
    page = document[target.page_index]
    _, height = _page_dimensions(page, request)
    width = _actual_raster_width(page, request)
    output_path = Path(target.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    strips = _render_strips(page, request, width, height)
    if request.format == "PNG":
        _stream_png(output_path, strips, width, height, request.dpi)
    else:
        _stream_tiff(output_path, strips, width, height, request.dpi)
    return RasterizedJpeg(
        page_index=target.page_index,
        output=str(output_path),
        width_px=width,
        height_px=height,
    )


def _save_jpeg_via_strips(
    document: pymupdf.Document,
    target: PdfJpegTarget,
    request: PdfToJpegRequest,
) -> RasterizedJpeg:
    """JPEG fallback for pages whose full-size pixmap exceeds MuPDF's max image
    limit (FzErrorLimit "Overly large image"). Renders in RASTER_STRIP_HEIGHT
    bands (each well under the per-pixmap limit) and assembles one RGB buffer,
    then encodes as baseline JPEG.

    Uses its own tolerant band loop rather than _render_strips: clipped-band
    pixmaps can round to a width 1px off the analytic _page_dimensions value, so
    the buffer is sized from the actual pixmap width and later bands are clamped
    to it. (_render_strips keeps its strict guard untouched for PNG/TIFF.)
    """
    page = document[target.page_index]
    _, height = _page_dimensions(page, request)
    render_scale = request.dpi * request.scale / 72
    matrix = pymupdf.Matrix(render_scale, render_scale)
    output_path = Path(target.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    buffer: numpy.ndarray | None = None
    width = 0
    y = 0
    for y_start in range(0, height, RASTER_STRIP_HEIGHT):
        y_end = min(y_start + RASTER_STRIP_HEIGHT, height)
        clip = pymupdf.Rect(
            page.rect.x0,
            page.rect.y0 + y_start / render_scale,
            page.rect.x1,
            page.rect.y0 + y_end / render_scale,
        )
        pixmap = page.get_pixmap(matrix=matrix, clip=clip, colorspace=pymupdf.csRGB, alpha=False)
        if buffer is None:
            width = pixmap.width
            buffer = numpy.empty((height, width, 3), dtype=numpy.uint8)
        rows = min(pixmap.height, height - y)
        cols = min(pixmap.width, width)
        band = numpy.frombuffer(pixmap.samples_mv, dtype=numpy.uint8).reshape(pixmap.height, pixmap.width, 3)
        buffer[y:y + rows, :cols] = band[:rows, :cols]
        y += rows
    if buffer is None:
        raise PdfRasterError("empty-pdf")
    if y != height:
        buffer = buffer[:y]
    image = Image.frombuffer("RGB", (width, buffer.shape[0]), buffer, "raw", "RGB", 0, 1)
    try:
        image.save(
            output_path,
            format="JPEG",
            quality=request.quality,
            dpi=(request.dpi, request.dpi),
            progressive=False,
            optimize=False,
            subsampling=0,
        )
    finally:
        image.close()
    return RasterizedJpeg(
        page_index=target.page_index,
        output=str(output_path),
        width_px=width,
        height_px=buffer.shape[0],
    )


def _render_jpeg_target(
    document: pymupdf.Document,
    target: PdfJpegTarget,
    request: PdfToJpegRequest,
) -> RasterizedJpeg:
    try:
        return _save_pixmap(_render_pixels(document[target.page_index], request), target, request)
    except pymupdf.mupdf.FzErrorLimit:
        # Whole-page pixmap exceeds MuPDF's max image size (e.g. very large
        # artboards at high scale/DPI). Fall back to strip assembly, which keeps
        # each intermediate pixmap small. Verified (normal-size) exports never
        # reach here, so their fast path stays byte-for-byte unchanged.
        return _save_jpeg_via_strips(document, target, request)


def _render_pages(
    document: pymupdf.Document,
    targets: tuple[PdfJpegTarget, ...],
    request: PdfToJpegRequest,
) -> tuple[RasterizedJpeg, ...]:
    pixel_counts: list[int] = []
    for target in targets:
        if target.page_index >= document.page_count:
            raise PdfRasterError("page-out-of-range")
        width_px, height_px = _page_dimensions(document[target.page_index], request)
        if request.format == "JPEG" and (width_px > JPEG_DIMENSION_LIMIT or height_px > JPEG_DIMENSION_LIMIT):
            raise PdfRasterError("jpeg-dimension-limit")
        pixel_counts.append(width_px * height_px)

    if request.format != "JPEG":
        return tuple(_stream_image(document, target, request) for target in targets)

    if len(targets) < 2 or max(pixel_counts) > JPEG_PIPELINE_PIXEL_LIMIT:
        return tuple(
            _render_jpeg_target(document, target, request)
            for target in targets
        )

    pages: list[RasterizedJpeg] = []
    pending: deque[tuple[Future[RasterizedJpeg], RenderedPixels]] = deque()
    with ThreadPoolExecutor(max_workers=JPEG_PIPELINE_WORKERS, thread_name_prefix="hf-jpeg") as executor:
        for target in targets:
            pixels = _render_pixels(document[target.page_index], request)
            pending.append((executor.submit(_save_pixmap, pixels, target, request), pixels))
            if len(pending) >= JPEG_PIPELINE_WORKERS:
                future, retained_pixels = pending.popleft()
                pages.append(future.result())
                del retained_pixels
        while pending:
            future, retained_pixels = pending.popleft()
            pages.append(future.result())
            del retained_pixels
    return tuple(pages)


def render_pdf_to_jpeg(request: PdfToJpegRequest) -> PdfToJpegResponse:
    input_path = Path(request.input)
    if not input_path.is_file():
        return PdfToJpegResponse(success=False, error=str(PdfRasterError("missing-input")))

    try:
        with pymupdf.open(input_path) as document:
            if document.page_count < 1:
                raise PdfRasterError("empty-pdf")
            pages = _render_pages(document, _targets_for(request), request)
            first = pages[0]
            return PdfToJpegResponse(
                success=True,
                output=first.output,
                width_px=first.width_px,
                height_px=first.height_px,
                pages=pages,
            )
    except PdfRasterError as error:
        return PdfToJpegResponse(success=False, error=str(error))
    except (MemoryError, OSError, RuntimeError, ValueError, zlib.error, tifffile.TiffFileError,
            pymupdf.mupdf.FzErrorBase) as error:
        # FzErrorBase (MuPDF) does not derive from RuntimeError, so without it a
        # MuPDF failure escapes as an unhandled 500 that the panel surfaces as
        # the opaque "engine returned an invalid result".
        return PdfToJpegResponse(success=False, error=f"PDF 栅格化失败: {error}")


@router.post("/pdf_to_jpeg")
def pdf_to_jpeg(request: PdfToJpegRequest) -> PdfToJpegResponse:
    return render_pdf_to_jpeg(request)
