from __future__ import annotations

import base64
import json
import os
import sys
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from io import BytesIO
from pathlib import Path

from fastapi import FastAPI
from fastapi.testclient import TestClient
from PIL import Image


ENGINE_SRC = Path(__file__).resolve().parents[1] / "src"
sys.path.insert(0, str(ENGINE_SRC))

import ai_image_router  # noqa: E402
from ai_image_router import router  # noqa: E402


def _png_bytes(color: tuple[int, int, int]) -> bytes:
    buffer = BytesIO()
    Image.new("RGB", (3, 2), color).save(buffer, "PNG")
    return buffer.getvalue()


class _UpstreamHandler(BaseHTTPRequestHandler):
    requests: list[tuple[str, str, bytes]] = []
    response_image = _png_bytes((25, 80, 140))

    def do_POST(self) -> None:  # noqa: N802
        length = int(self.headers.get("Content-Length", "0"))
        body = self.rfile.read(length)
        self.__class__.requests.append((self.path, self.headers.get("Content-Type", ""), body))
        payload = {"data": [{"b64_json": base64.b64encode(self.response_image).decode("ascii")}]}
        encoded = json.dumps(payload).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)

    def log_message(self, format: str, *args: str) -> None:
        return


class TestAiImageRoute(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), _UpstreamHandler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base_url = f"http://127.0.0.1:{cls.server.server_port}/v1"

    @classmethod
    def tearDownClass(cls) -> None:
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=2)

    def setUp(self) -> None:
        _UpstreamHandler.requests.clear()
        self.original_key = os.environ.get("HOPEFLOW_AI_IMAGE_API_KEY")
        self.original_base = os.environ.get("HOPEFLOW_AI_IMAGE_BASE_URL")
        self.original_config = os.environ.get("HOPEFLOW_AI_IMAGE_CONFIG")
        os.environ["HOPEFLOW_AI_IMAGE_API_KEY"] = "server-only-test-key"
        os.environ["HOPEFLOW_AI_IMAGE_BASE_URL"] = self.base_url
        app = FastAPI()
        app.include_router(router)
        self.client = TestClient(app)

    def tearDown(self) -> None:
        self.client.close()
        if self.original_key is None:
            os.environ.pop("HOPEFLOW_AI_IMAGE_API_KEY", None)
        else:
            os.environ["HOPEFLOW_AI_IMAGE_API_KEY"] = self.original_key
        if self.original_base is None:
            os.environ.pop("HOPEFLOW_AI_IMAGE_BASE_URL", None)
        else:
            os.environ["HOPEFLOW_AI_IMAGE_BASE_URL"] = self.original_base
        if self.original_config is None:
            os.environ.pop("HOPEFLOW_AI_IMAGE_CONFIG", None)
        else:
            os.environ["HOPEFLOW_AI_IMAGE_CONFIG"] = self.original_config

    def test_generation_writes_upstream_base64_as_png(self) -> None:
        response = self.client.post(
            "/ai_image",
            json={
                "prompt": "blue packaging mockup",
                "size": "1024x1024",
                "grant": "signed-grant",
                "feature": "ai-image",
                "site_base_url": "https://license.example",
            },
        )

        payload = response.json()
        self.assertTrue(payload["success"])
        self.assertTrue(Path(payload["output"]).is_file())
        with Image.open(payload["output"]) as image:
            self.assertEqual(image.format, "PNG")
        request_path, content_type, request_body = _UpstreamHandler.requests[0]
        self.assertEqual(request_path, "/v1/images/generations")
        self.assertEqual(content_type, "application/json")
        upstream_payload = json.loads(request_body)
        self.assertEqual(upstream_payload["model"], "gpt-image-2")
        self.assertEqual(upstream_payload["prompt"], "blue packaging mockup")

    def test_reference_image_uses_edit_endpoint_and_multipart_upload(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            reference = Path(directory) / "reference.png"
            reference.write_bytes(_png_bytes((200, 30, 90)))

            response = self.client.post(
                "/ai_image",
                json={
                    "prompt": "keep the layout and change the palette",
                    "size": "1024x1536",
                    "reference_image": str(reference),
                },
            )

        payload = response.json()
        self.assertTrue(payload["success"])
        request_path, content_type, request_body = _UpstreamHandler.requests[0]
        self.assertEqual(request_path, "/v1/images/edits")
        self.assertIn("multipart/form-data; boundary=", content_type)
        self.assertIn(b'name="model"', request_body)
        self.assertIn(b"gpt-image-2", request_body)
        self.assertIn(b'name="image"; filename="reference.png"', request_body)

    def test_missing_server_key_fails_without_contacting_upstream(self) -> None:
        os.environ.pop("HOPEFLOW_AI_IMAGE_API_KEY", None)

        response = self.client.post("/ai_image", json={"prompt": "test"})

        payload = response.json()
        self.assertFalse(payload["success"])
        self.assertIn("HOPEFLOW_AI_IMAGE_API_KEY", payload["error"])
        self.assertEqual(_UpstreamHandler.requests, [])

    def test_local_config_provides_key_and_upstream_url(self) -> None:
        os.environ.pop("HOPEFLOW_AI_IMAGE_API_KEY", None)
        os.environ.pop("HOPEFLOW_AI_IMAGE_BASE_URL", None)
        original_default = ai_image_router.DEFAULT_BASE_URL
        ai_image_router.DEFAULT_BASE_URL = "http://127.0.0.1:1/v1"
        try:
            with tempfile.TemporaryDirectory() as directory:
                config_path = Path(directory) / "config.json"
                config_path.write_text(
                    json.dumps(
                        {
                            "ai_image_api_key": "config-only-key",
                            "ai_image_base_url": self.base_url,
                        }
                    ),
                    encoding="utf-8",
                )
                os.environ["HOPEFLOW_AI_IMAGE_CONFIG"] = str(config_path)

                response = self.client.post("/ai_image", json={"prompt": "configured upstream"})
        finally:
            ai_image_router.DEFAULT_BASE_URL = original_default

        payload = response.json()
        self.assertTrue(payload["success"])
        self.assertEqual(_UpstreamHandler.requests[0][0], "/v1/images/generations")


if __name__ == "__main__":
    unittest.main()
