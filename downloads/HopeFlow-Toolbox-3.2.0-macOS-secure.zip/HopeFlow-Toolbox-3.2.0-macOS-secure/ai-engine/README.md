# HopeFlow AI Engine

## AI image credentials

`POST /ai_image` proxies the OpenAI-compatible image endpoints without exposing the upstream credential to the CEP panel.

Set the key in the environment before starting the engine:

```sh
export HOPEFLOW_AI_IMAGE_API_KEY="replace-with-runtime-key"
python3 ai-engine/src/server.py
```

Alternatively, use **HopeFlow 设置 → AI 绘图**. The panel writes the credential only to
`~/.hopeflow/ai-engine/config.json` with user-only file permissions; image-generation requests from the
panel never contain the upstream key. The equivalent file format is:

```json
{
  "ai_image_api_key": "replace-with-runtime-key",
  "ai_image_base_url": "https://toloveu.asia/v1"
}
```

The upstream defaults to `https://toloveu.asia/v1`. Environment variables override the local settings file,
which is useful for deployment and testing. Never put a live key in this repository.
