#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
EXTENSION_ID="com.hopeflow.toolbox"
CEP_TARGET="$HOME/Library/Application Support/Adobe/CEP/extensions/$EXTENSION_ID"
AIP_NAME="HopeFlow.aip"
LOCAL_CODESIGN_CN="HopeFlow Local Code Signing"
MACOS_CODESIGN_IDENTITY="${MACOS_CODESIGN_IDENTITY:-}"
CEP_DEBUG_MIN_VERSION=12
CEP_DEBUG_MAX_VERSION=16
DEV_MODE=0
CHECK_ONLY=0
UNINSTALL=0
BUILD_AIP=0
ALL_AIP=0

usage() {
  cat <<'EOF'
用法 / Usage:
  ./install.sh [options]

默认行为：安装已构建的 CEP 面板和可用的 macOS 智能编组 AIP。
（若缺少 dist/ 且本机有 npm，会自动先构建。）

Options:
  --dev          Build the CEP panel with npm before installing.
  --build-aip    Build the macOS AIP before installing. Use with --year or --all-aip.
  --all-aip      Build all detected macOS SDK years before installing.
  --year YYYY    Select/build the AIP matching one Illustrator SDK year.
  --check        Print install status only.
  --uninstall    Remove the CEP panel and installed HopeFlow smart-group AIPs.
  -h, --help     Show this help.
EOF
}

YEAR="${ILLUSTRATOR_SDK_YEAR:-}"

while [ "$#" -gt 0 ]; do
  case "$1" in
    --dev)
      DEV_MODE=1
      shift
      ;;
    --build-aip)
      BUILD_AIP=1
      shift
      ;;
    --all-aip)
      ALL_AIP=1
      shift
      ;;
    --year)
      YEAR="${2:-}"
      shift 2
      ;;
    --year=*)
      YEAR="${1#--year=}"
      shift
      ;;
    --check)
      CHECK_ONLY=1
      shift
      ;;
    --uninstall)
      UNINSTALL=1
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unknown option: $1" >&2
      usage >&2
      exit 2
      ;;
  esac
done

run_copy() {
  local src="$1"
  local dst="$2"
  rm -rf "$dst" 2>/dev/null || sudo rm -rf "$dst"
  mkdir -p "$(dirname "$dst")" 2>/dev/null || sudo mkdir -p "$(dirname "$dst")"
  if [ -w "$(dirname "$dst")" ]; then
    cp -R "$src" "$dst" || return 1
  else
    sudo cp -R "$src" "$dst" || return 1
  fi
}

build_graphic_relief_native() {
  local source_dir="$SCRIPT_DIR/tools/graphic-relief-native"
  local build_dir="$source_dir/build"
  if [ ! -f "$source_dir/CMakeLists.txt" ]; then
    echo "Missing graphic relief native source: $source_dir/CMakeLists.txt" >&2
    return 1
  fi
  if ! command -v cmake >/dev/null 2>&1; then
    echo "cmake is required to build graphic relief native helper on macOS." >&2
    return 1
  fi

  cmake -S "$source_dir" -B "$build_dir" -DCMAKE_BUILD_TYPE=Release >/dev/null
  cmake --build "$build_dir" --config Release >/dev/null
}

install_graphic_relief_native() {
  local source_dir="$SCRIPT_DIR/tools/graphic-relief-native"
  local target_dir="$CEP_TARGET/tools/graphic-relief-native/build"
  local helper_name="graphic_relief_native"
  local helper_candidates=(
    "$source_dir/build/$helper_name"
    "$source_dir/build/Release/$helper_name"
  )
  local helper_source=""
  local helper_candidate

  for helper_candidate in "${helper_candidates[@]}"; do
    if [ -f "$helper_candidate" ]; then
      helper_source="$helper_candidate"
      break
    fi
  done

  if [ -z "$helper_source" ]; then
    echo "Building graphic relief native helper for macOS..."
    build_graphic_relief_native
    for helper_candidate in "${helper_candidates[@]}"; do
      if [ -f "$helper_candidate" ]; then
        helper_source="$helper_candidate"
        break
      fi
    done
  fi

  if [ ! -f "$helper_source" ]; then
    echo "Graphic relief native helper build did not produce $helper_name" >&2
    return 1
  fi

  mkdir -p "$target_dir"
  cp "$helper_source" "$target_dir/$helper_name"
  chmod +x "$target_dir/$helper_name"
  xattr -cr "$target_dir/$helper_name" >/dev/null 2>&1 || true
  echo "Graphic relief native helper installed: $target_dir/$helper_name"
}

find_local_codesign_identity() {
  if [ -n "$MACOS_CODESIGN_IDENTITY" ]; then
    printf '%s\n' "$MACOS_CODESIGN_IDENTITY"
    return 0
  fi

  security find-identity -p codesigning -v 2>/dev/null \
    | awk -F '"' '/Apple Development|Developer ID Application/ { print $2; exit }'
  if [ "${PIPESTATUS[0]}" -ne 0 ]; then
    return 0
  fi

  security find-identity -p codesigning -v 2>/dev/null \
    | awk -F '"' -v cn="$LOCAL_CODESIGN_CN" '$0 ~ cn { print $2; exit }'
}

export_local_codesign_certificate() {
  local output="$1"
  security find-certificate -c "$LOCAL_CODESIGN_CN" -p "$HOME/Library/Keychains/login.keychain-db" > "$output" 2>/dev/null \
    || security find-certificate -c "$LOCAL_CODESIGN_CN" -p /Library/Keychains/System.keychain > "$output" 2>/dev/null
  [ -s "$output" ]
}

system_trusts_local_codesign_certificate() {
  security dump-trust-settings -d 2>/dev/null \
    | awk -v cn="$LOCAL_CODESIGN_CN" '
      $0 ~ "Cert [0-9]+: " cn { in_cert = 1; next }
      in_cert && /Cert [0-9]+:/ { in_cert = 0 }
      in_cert && /Policy OID[[:space:]]*: Code Signing/ { found = 1 }
      END { exit(found ? 0 : 1) }
    '
}

trust_local_codesign_certificate() {
  local identity="$1"
  [ -n "$identity" ] || return 0
  if [ "$identity" != "$LOCAL_CODESIGN_CN" ]; then
    return 0
  fi

  if system_trusts_local_codesign_certificate; then
    return 0
  fi

  local cert_file
  cert_file="$(mktemp "${TMPDIR:-/tmp}/hopeflow-code-signing.XXXXXX.cer")"
  if ! export_local_codesign_certificate "$cert_file"; then
    rm -f "$cert_file"
    echo "Code signing identity '$LOCAL_CODESIGN_CN' was found, but its certificate could not be exported." >&2
    return 1
  fi

  echo "Trusting local HopeFlow code-signing certificate for AMFI plugin loading..."
  sudo security add-trusted-cert -d -r trustRoot -p codeSign -k /Library/Keychains/System.keychain "$cert_file" || {
    rm -f "$cert_file"
    return 1
  }
  rm -f "$cert_file"

  if ! system_trusts_local_codesign_certificate; then
    echo "The certificate was added, but macOS did not record system Code Signing trust." >&2
    echo "Run this from Terminal and enter your administrator password when prompted:" >&2
    echo "  sudo security add-trusted-cert -d -r trustRoot -p codeSign -k /Library/Keychains/System.keychain <exported-cert.cer>" >&2
    return 1
  fi
}

sign_aip_source_if_possible() {
  local aip="$1"
  local identity="$2"
  [ -n "$identity" ] || return 0
  xattr -cr "$aip" >/dev/null 2>&1 || true
  codesign --force --deep --sign "$identity" "$aip" || return 1
}

enable_cep_debug_mode() {
  local version domain
  for ((version=CEP_DEBUG_MIN_VERSION; version<=CEP_DEBUG_MAX_VERSION; version++)); do
    domain="com.adobe.CSXS.$version"
    defaults write "$domain" PlayerDebugMode 1 >/dev/null
  done
  echo "CEP debug mode enabled for CSXS.$CEP_DEBUG_MIN_VERSION-CSXS.$CEP_DEBUG_MAX_VERSION."
}

detect_illustrator_year() {
  local app base
  for app in /Applications/Adobe\ Illustrator\ */Adobe\ Illustrator.app; do
    [ -e "$app" ] || continue
    base="$(basename "$(dirname "$app")")"
    if [[ "$base" =~ ([0-9]{4}) ]]; then
      printf '%s\n' "${BASH_REMATCH[1]}"
      return 0
    fi
  done
  return 1
}

find_macos_aip() {
  local requested_year="$1"
  local candidate
  if [ -n "$requested_year" ]; then
    candidate="$SCRIPT_DIR/tools/illustrator-aip/macos/$requested_year/$AIP_NAME"
    [ -d "$candidate" ] && printf '%s\n' "$candidate" && return 0
  fi

  local detected_year
  detected_year="$(detect_illustrator_year || true)"
  if [ -n "$detected_year" ]; then
    candidate="$SCRIPT_DIR/tools/illustrator-aip/macos/$detected_year/$AIP_NAME"
    [ -d "$candidate" ] && printf '%s\n' "$candidate" && return 0
  fi

  candidate="$SCRIPT_DIR/tools/illustrator-aip/macos/$AIP_NAME"
  [ -d "$candidate" ] && printf '%s\n' "$candidate" && return 0

  find "$SCRIPT_DIR/tools/illustrator-aip/macos" -path "*/$AIP_NAME" -type d 2>/dev/null | sort | tail -n 1
}

find_aip_targets() {
  local app app_dir plug_dir
  for app in /Applications/Adobe\ Illustrator\ */Adobe\ Illustrator.app; do
    [ -e "$app" ] || continue
    app_dir="$(dirname "$app")"
    for plug_dir in "$app_dir/Plug-ins" "$app_dir/Plug-ins.localized" "$app_dir/增效工具"; do
      if [ -d "$plug_dir" ]; then
        printf '%s\n' "$plug_dir"
      fi
    done
  done
}

print_status() {
  echo "CEP panel: $CEP_TARGET"
  if [ -d "$CEP_TARGET" ]; then
    echo "  installed"
  else
    echo "  not installed"
  fi

  local target
  while IFS= read -r target; do
    [ -n "$target" ] || continue
    if [ -d "$target/$AIP_NAME" ]; then
      echo "AIP installed: $target/$AIP_NAME"
    else
      echo "AIP target: $target"
    fi
  done < <(find_aip_targets)
}

if [ "$CHECK_ONLY" = "1" ]; then
  print_status
  exit 0
fi

if [ "$UNINSTALL" = "1" ]; then
  rm -rf "$CEP_TARGET"
  while IFS= read -r target; do
    [ -n "$target" ] || continue
    rm -rf "$target/$AIP_NAME" 2>/dev/null || sudo rm -rf "$target/$AIP_NAME"
  done < <(find_aip_targets)
  echo "HopeFlow CEP panel and smart-group AIP removed."
  exit 0
fi

if [ "$DEV_MODE" = "1" ]; then
  if [ -f "$SCRIPT_DIR/package-lock.json" ]; then
    (cd "$SCRIPT_DIR" && npm ci)
  else
    (cd "$SCRIPT_DIR" && npm install)
  fi
  (cd "$SCRIPT_DIR" && npm run build)
fi

if [ "$BUILD_AIP" = "1" ]; then
  if [ "$ALL_AIP" = "1" ]; then
    "$SCRIPT_DIR/tools/illustrator-aip/build-macos-aip.sh" --all
  elif [ -n "$YEAR" ]; then
    "$SCRIPT_DIR/tools/illustrator-aip/build-macos-aip.sh" --year "$YEAR"
  else
    "$SCRIPT_DIR/tools/illustrator-aip/build-macos-aip.sh"
  fi
fi

if [ ! -d "$SCRIPT_DIR/dist" ]; then
  # 发布包应自带 dist/；源码目录下若装有 npm 则自动构建，对普通用户零门槛
  if [ -f "$SCRIPT_DIR/package.json" ] && command -v npm >/dev/null 2>&1; then
    echo "未找到 dist/，检测到源码目录，正在自动构建面板（首次约需几分钟）..."
    if [ -f "$SCRIPT_DIR/package-lock.json" ] && [ ! -d "$SCRIPT_DIR/node_modules" ]; then
      (cd "$SCRIPT_DIR" && npm ci)
    elif [ ! -d "$SCRIPT_DIR/node_modules" ]; then
      (cd "$SCRIPT_DIR" && npm install)
    fi
    (cd "$SCRIPT_DIR" && npm run build)
  fi
fi

if [ ! -d "$SCRIPT_DIR/dist" ]; then
  echo "错误：缺少 dist/ 目录。" >&2
  echo "请使用完整的发布包安装；或在源码目录安装 Node.js 后重试（会自动构建）。" >&2
  exit 1
fi

enable_cep_debug_mode

rm -rf "$CEP_TARGET"
mkdir -p "$CEP_TARGET"
rsync -a --delete \
  --exclude ".git/" \
  --exclude ".claude/" \
  --exclude ".vscode/" \
  --exclude "node_modules/" \
  --exclude "release/" \
  --exclude "hopeflow-docs/" \
  --exclude "tools/illustrator-aip/sdk/" \
  --exclude "tools/illustrator-aip/build-aip-work/" \
  --exclude "tools/illustrator-aip/build-check/" \
  --exclude "tools/nesting-native/build/" \
  --exclude "tools/nesting-native/build-macos/CMakeFiles/" \
  --exclude "tools/nesting-native/build-macos/CMakeCache.txt" \
  --exclude "tools/nesting-native/build-macos/Makefile" \
  --exclude "tools/nesting-native/build-macos/*.cmake" \
  --exclude "tools/nesting-native/build-macos/CTestTestfile.cmake" \
  --exclude "tools/graphic-relief-native/build/" \
  "$SCRIPT_DIR/" "$CEP_TARGET/"
xattr -cr "$CEP_TARGET" >/dev/null 2>&1 || true
# 确保 mac 排料加速器可执行
chmod +x "$CEP_TARGET/tools/nesting-native/build-macos/nesting_native" 2>/dev/null || true
echo "CEP panel installed: $CEP_TARGET"

install_graphic_relief_native

aip_source="$(find_macos_aip "$YEAR" || true)"
if [ -n "$aip_source" ] && [ -d "$aip_source" ]; then
  codesign_identity="$(find_local_codesign_identity || true)"
  if [ -n "$codesign_identity" ]; then
    if ! trust_local_codesign_certificate "$codesign_identity"; then
      echo "Warning: failed to trust local code-signing certificate automatically."
      echo "The CEP panel and graphic relief native helper are installed; the smart-group AIP may still require manual trust/signing."
    fi
    if ! sign_aip_source_if_possible "$aip_source" "$codesign_identity"; then
      echo "Warning: failed to sign macOS smart-group AIP with '$codesign_identity'."
      echo "The CEP panel and graphic relief native helper are installed; the smart-group AIP may need manual signing."
    fi
  else
    # 没有可用签名身份时退回临时签名（ad-hoc）：多数本机场景可以加载，
    # 绝不做 Gatekeeper 全局禁用之类的系统级改动。
    echo "未找到可用的代码签名身份，对智能编组 AIP 使用临时签名（ad-hoc）..."
    xattr -cr "$aip_source" >/dev/null 2>&1 || true
    if ! codesign --force --deep --sign - "$aip_source" 2>/dev/null; then
      echo "警告：临时签名失败。CEP 面板不受影响；若智能编组功能不可用，"
      echo "请参考 tools/illustrator-aip/README.md 配置本地签名证书。"
    fi
  fi

  installed_any=0
  target_count=0
  while IFS= read -r target; do
    [ -n "$target" ] || continue
    target_count=$((target_count + 1))
    if run_copy "$aip_source" "$target/$AIP_NAME"; then
      xattr -cr "$target/$AIP_NAME" >/dev/null 2>&1 || true
      echo "Smart-group AIP installed: $target/$AIP_NAME"
      installed_any=1
    else
      echo "Warning: failed to install smart-group AIP to $target/$AIP_NAME"
      echo "The CEP panel and graphic relief native helper are installed; copy this AIP manually if needed: $aip_source"
    fi
  done < <(find_aip_targets)
  if [ "$installed_any" = "0" ] && [ "$target_count" = "0" ]; then
    echo "No Illustrator Plug-ins directory found under /Applications. CEP panel was installed; install $aip_source manually after Illustrator is installed."
  elif [ "$installed_any" = "0" ]; then
    echo "No writable Illustrator Plug-ins directory was updated automatically."
    echo "The CEP panel and graphic relief native helper are installed; install $aip_source manually if the smart-group AIP is required."
  fi
else
  echo "No macOS smart-group AIP found. Build it with: tools/illustrator-aip/build-macos-aip.sh --all"
fi

echo
# --- 数据合并「高速」引擎：装完即用（自动重启引擎 + 补齐 Illustrator 中文字体）---
echo
echo "配置数据合并高速引擎..."
if pgrep -f "ai-engine/src/server.py" >/dev/null 2>&1; then
  pkill -f "ai-engine/src/server.py" 2>/dev/null || true
  echo "  已停止旧引擎（下次导出会自动用最新代码启动）"
fi
_hf_user_fonts="$HOME/Library/Fonts"
mkdir -p "$_hf_user_fonts" 2>/dev/null || true
_hf_copied=0
for _hf_fdir in /Applications/Adobe\ Illustrator\ */Adobe\ Illustrator.app/Contents/Required/Fonts; do
  [ -d "$_hf_fdir" ] || continue
  for _hf_font in "$_hf_fdir"/AdobeSong* "$_hf_fdir"/AdobeHeiti* "$_hf_fdir"/AdobeFangsong* "$_hf_fdir"/AdobeKaiti* "$_hf_fdir"/AdobeMing* "$_hf_fdir"/AdobeGothic* "$_hf_fdir"/AdobeMyungjo* "$_hf_fdir"/SourceHanSans* "$_hf_fdir"/SourceHanSerif* "$_hf_fdir"/Kozuka* "$_hf_fdir"/Kozmin*; do
    [ -f "$_hf_font" ] || continue
    _hf_base="$(basename "$_hf_font")"
    if [ ! -f "$_hf_user_fonts/$_hf_base" ]; then
      if cp "$_hf_font" "$_hf_user_fonts/$_hf_base" 2>/dev/null; then
        _hf_copied=$((_hf_copied + 1))
      fi
    fi
  done
done
if [ "$_hf_copied" -gt 0 ]; then
  echo "  已补齐 $_hf_copied 个 Illustrator 中文字体供高速引擎使用"
fi

echo "=============================================="
echo " ✅ HopeFlow 工具箱安装完成"
echo
echo " 下一步："
echo "  1. 重启 Adobe Illustrator（若正在运行请完全退出后再打开）"
echo "  2. 菜单：窗口 > 扩展 (Extensions)"
echo "  3. 打开「HopeFlow 工具箱」主面板"
echo "     （画板/对象/收藏/脚本子面板也在同一菜单中）"
echo
echo " 遇到问题：./install.sh --check 查看安装状态"
echo "=============================================="
